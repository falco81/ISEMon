#!/usr/bin/python3 -I
"""isemon_web.py - the parts of the web server and the firewall that need
root, put in place by root (isemon 1.10.222; after otp's otp_web.py).

The things Settings may ask for that the daemon - which runs as `isemon`
and may not write a byte of /etc - cannot do itself:

  * who may reach which page: the dashboard, the published ban list
    (banfeed.php) and the health check (healthz.php), each as its own list
    of addresses and networks in /etc/nginx/conf.d/isemon.conf;
  * TLS: the certificate (with its chain, and the root it is checked
    against), the protocols, the ciphers, the DH parameters and HSTS;
  * the machine's firewall: a chain of isemon's own, ISEMON-IN, first in
    INPUT, for IPv4 and IPv6 - what isemon needs let in by itself, and the
    rules of the site's own;
  * this machine's network (1.10.228): its address, gateway, DNS, IPv6 and
    host name in NetworkManager and /etc/hosts, and a restart or a power-off
    (asked in net.ask, answered in net.json).

The daemon lays a request down in /var/lib/isemon/web/request.json and
systemd (isemon-web.path) starts this as root (isemon-web.service). Nothing
in the request is trusted: every value is checked against the one shape it
may have before it goes into a file, certificates and keys are read by
openssl and the key must be the certificate's own, nginx is asked (nginx -t)
before it is reloaded and every file is put back as it was when it says no,
a firewall file is checked with iptables-restore --test first, and the
folder is used through one descriptor, never a path the isemon account
could swap for a link.

What is there now - the certificate nginx answers with, the lists, the
firewall's own lines, the ports rsyslog listens on - is written to
look.json when the daemon asks with look.ask; nothing is changed for it.

The clock (1.10.228): asked in ntp.ask, answered in ntp.json - how chrony
sees it, a step to the right time now, and the time servers and time zone
put into /etc/chrony.conf when isemon is to set them (see ntp_part).

Root's SSH keys (1.10.239): asked in sshkeys.ask, answered in sshkeys.json -
the keys in /root/.ssh/authorized_keys, one added or taken away, and what
sshd makes of root (see sshkeys_part).

The updates of the operating system (1.10.239): asked in osup.ask, answered
in osup.ans - a look for updates or the update itself, started as a unit of
its own (isemon_web.py --os-job ID check|upgrade) that writes how far it is
into osup.json (see osup_part). dnf and apt through Settings → Proxy
(1.10.268): the proxy handed over in osup.ask, kept for the work in
/run/isemon-osup-proxy.json (root's, 0600), read into the work's own
environment and taken away - never on a command line.

  isemon_web.py            serve request.json, look.ask, net.ask, ntp.ask, sshkeys.ask, logfix.ask,
                           osup.ask, otptls.ask, acmetls.ask, selinux.ask and osroots.ask
                           (as root, from systemd)
The otp logs over TLS (1.10.245): asked in otptls.ask, answered in
otptls.json - rsyslog's encrypted input for otp's nodes, its certificate and
key in /etc/pki/rsyslog/otp/ and /etc/rsyslog.d/10-otp-tls.conf, beside the
plain input, which is never touched (see otptls_part).

  isemon_web.py --os-job ID check|upgrade
                           a look for updates or the update (started by osup.ask)
  isemon_web.py --status   what is in place here (JSON)
"""
import ipaddress
import json
import math
import os
import re
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
import time

STATE_DIR = os.environ.get('ISEMON_STATE', '/var/lib/isemon')
NGINX_MAIN = os.environ.get('ISEMON_NGINX_CONF', '/etc/nginx/conf.d/isemon.conf')
CERT_DIR = os.environ.get('ISEMON_CERT_DIR', '/etc/nginx/certs')
RSYSLOG_FILES = os.environ.get('ISEMON_RSYSLOG', '/etc/rsyslog.conf:/etc/rsyslog.d')
NO_SERVICES = bool(os.environ.get('ISEMON_WEB_NO_SERVICES'))     # tests: no systemctl, nginx -t
SERVICE_GROUP = os.environ.get('ISEMON_GROUP', 'isemon')
LOOK_ASK = 'look.ask'
LOOK_FILE = 'look.json'

ADDR_RE = re.compile(r'^[0-9A-Fa-f:.]+(/[0-9]{1,3})?$')


class Refused(Exception):
    pass


def plain(text, how):
    """An address or a network - and nothing else: ipaddress keeps an IPv6
    scope id (fe80::1%eth0) with any character in it, newlines and braces
    included, and so into the nginx and iptables files root writes."""
    text = str(text or '').strip()
    if not ADDR_RE.match(text):
        raise ValueError('not a plain address')
    got = {'address': ipaddress.ip_address,
           'network': lambda t: ipaddress.ip_network(t, strict=False)}[how](text)
    if '%' in str(got):
        raise ValueError('a scope id is not taken')
    return got


# ---- the folder the isemon account owns: one descriptor, never a path ------------
FD = [None]


def web_fd():
    if FD[0] is None:
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
        top = os.open(STATE_DIR, flags)
        try:
            FD[0] = os.open('web', flags, dir_fd=top)
        finally:
            os.close(top)
    return FD[0]


def read_req(name, most=1048576):
    fd = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=web_fd())
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise Refused('%s is not a file' % name)
        data = os.read(fd, most + 1)
    finally:
        os.close(fd)
    if len(data) > most:
        raise Refused('the request is far bigger than anything it may hold')
    return data


def write_here(name, text):
    """A file in the isemon account's folder: made beside and renamed over,
    so a link put there in its place is replaced, never followed."""
    d = web_fd()
    tmp = '.%s.%d' % (name, os.getpid())
    try:
        os.unlink(tmp, dir_fd=d)
    except OSError:
        pass
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o640, dir_fd=d)
    with os.fdopen(fd, 'w') as f:
        f.write(text)
        try:
            import grp
            os.fchown(f.fileno(), 0, grp.getgrnam(SERVICE_GROUP).gr_gid)
        except (KeyError, OSError):
            pass
    os.replace(tmp, name, src_dir_fd=d, dst_dir_fd=d)


def write_root(path, text, mode):
    """A file of root's, replaced whole."""
    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.isemon-', dir=folder)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8', errors='surrogateescape') as f:
            f.write(text)
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    if shutil.which('restorecon') and not NO_SERVICES:
        subprocess.run(['restorecon', path], capture_output=True)


# ---- what a request may hold ------------------------------------------------------
CERT_RE = re.compile(r'^(\s*-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+-----END CERTIFICATE-----)+\s*$')
KEY_RE = re.compile(r'^\s*-----BEGIN (RSA |EC )?PRIVATE KEY-----[A-Za-z0-9+/=\s:,-]+'
                    r'-----END (RSA |EC )?PRIVATE KEY-----\s*$')
PROTOCOLS = ('TLSv1.2', 'TLSv1.3')
DH_CHOICES = ('none', 'ffdhe2048', 'ffdhe3072', 'ffdhe4096', 'gen2048', 'gen3072', 'gen4096')


def openssl(args, what, data=None):
    got = subprocess.run(['openssl'] + args, capture_output=True, text=True, input=data)
    if got.returncode != 0:
        raise Refused('%s: %s' % (what, ((got.stderr or got.stdout).strip().splitlines()[-1:]
                                         or ['openssl said no'])[0]))
    return got.stdout


def pem_set(cert, key, chain='', root=''):
    """A certificate, its key, the certificates between it and the root, and
    the root - each read by openssl, the key the certificate's own."""
    cert, key = str(cert or '').strip(), str(key or '').strip()
    chain, root = str(chain or '').strip(), str(root or '').strip()
    if not cert and not key:
        return None
    if not cert or not key:
        raise Refused('a certificate needs its key, and a key its certificate')
    for what, text in (('the certificate', cert), ('the chain', chain), ('the root', root)):
        if text and not CERT_RE.match(text):
            raise Refused('%s is not PEM (-----BEGIN CERTIFICATE-----)' % what)
    if not KEY_RE.match(key):
        raise Refused('the key is not a PEM private key without a passphrase')
    with tempfile.TemporaryDirectory(prefix='isemon-web-') as t:
        cf, kf = os.path.join(t, 'c.pem'), os.path.join(t, 'k.pem')
        with open(cf, 'w') as f:
            f.write(cert + '\n')
        with open(kf, 'w') as f:
            f.write(key + '\n')
        os.chmod(kf, 0o600)
        a = openssl(['x509', '-in', cf, '-noout', '-pubkey'], 'the certificate')
        b = openssl(['pkey', '-in', kf, '-pubout'], 'the key')
        if a.strip() != b.strip():
            raise Refused('the key is not the one of this certificate')
    return {'cert': cert + '\n', 'key': key + '\n', 'chain': (chain + '\n') if chain else '',
            'root': (root + '\n') if root else ''}


def key_kind(cert):
    """'rsa' or 'ec' - the key of a certificate, as openssl reads it."""
    text = openssl(['x509', '-noout', '-text'], 'the certificate', cert)
    if 'id-ecPublicKey' in text:
        return 'ec'
    if 'rsaEncryption' in text:
        return 'rsa'
    return ''


def tls_checked(t):
    if t is None:
        return None
    if not isinstance(t, dict):
        raise Refused('the TLS is not an object')
    out = {'pem': pem_set(t.get('cert'), t.get('key'), t.get('chain'), t.get('root'))}
    # The ECDSA certificate beside the RSA one (dual-cert, 1.10.261): checked
    # as the first is - the key the certificate's own - and ECDSA, beside an
    # RSA one: nginx keeps one certificate of each kind, so a second of the
    # same kind would take the first one's place.
    out['pem2'] = pem_set(t.get('cert2'), t.get('key2'), t.get('chain2'))
    if out['pem2']:
        if not out['pem']:
            raise Refused('an ECDSA certificate beside it needs the first certificate')
        if key_kind(out['pem2']['cert']) != 'ec':
            raise Refused('the second certificate is ECDSA, beside an RSA one - this one is not')
        if key_kind(out['pem']['cert']) != 'rsa':
            raise Refused('a second certificate goes beside an RSA one - the first is not RSA')
    prot = t.get('protocols') or list(PROTOCOLS)
    if not isinstance(prot, list) or not prot or any(p not in PROTOCOLS for p in prot):
        raise Refused('the protocols are TLSv1.2 and/or TLSv1.3')
    out['protocols'] = [p for p in PROTOCOLS if p in prot]
    ciphers = str(t.get('ciphers') or '').strip()
    if ciphers:
        # Never starting with a dash: it goes to `openssl ciphers` as an
        # argument, and must not be read as an option.
        if not re.match(r'^[A-Za-z0-9_+!@][A-Za-z0-9_+!@=:.-]{0,1999}$', ciphers):
            raise Refused('the ciphers are an OpenSSL cipher list: letters, digits, : + ! - =')
        openssl(['ciphers', ciphers], 'OpenSSL does not know that cipher list')
    out['ciphers'] = ciphers
    out['prefer'] = bool(t.get('prefer'))
    dh = str(t.get('dh') or 'none')
    if dh not in DH_CHOICES:
        raise Refused('the DH parameters are one of %s' % ', '.join(DH_CHOICES))
    out['dh'] = dh
    try:
        out['hsts'] = int(t.get('hsts') or 0)
    except (TypeError, ValueError):
        raise Refused('HSTS is a number of seconds')
    if not 0 <= out['hsts'] <= 63072000:
        raise Refused('HSTS is 0 to 63072000 seconds')
    return out


def checked(r):
    """The request, every value in the one shape it may have."""
    if not isinstance(r, dict):
        raise Refused('the request is not an object')
    out = {'id': re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:32],
           'hash': re.sub(r'[^0-9a-f]', '', str(r.get('hash') or ''))[:64]}
    out['tls'] = tls_checked(r.get('tls'))
    fw = r.get('fw')
    if isinstance(fw, dict):
        rules = fw.get('rules') or []
        if not isinstance(rules, list) or len(rules) > 2000:
            raise Refused('the firewall rules are a list, 2000 at most')
        out['fw'] = {'on': bool(fw.get('on')), 'rules': [fw_rule_checked(x) for x in rules]}
    else:
        out['fw'] = None
    out['access'] = access_checked(r.get('access'))
    # Automatic certificates by HTTP-01 (1.10.251): the names port 80
    # answers the ACME CA for - DNS names and nothing else, for they go into
    # server_name.
    names = r.get('acme')
    if names is None:
        out['acme'] = None
    else:
        if not isinstance(names, list) or len(names) > 10 or \
                not all(isinstance(n, str) and ACME_NAME_RE.match(n) for n in names):
            raise Refused('the names of the ACME certificate are DNS names, 10 at most')
        out['acme'] = [n.lower() for n in names]
    return out


ACME_NAME_RE = re.compile(r'^(?=.{1,253}\Z)([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+'
                          r'[A-Za-z]{2,63}\Z')


# ---- nginx: finding things in a file somebody else may have written ------------
def server_block(text):
    """(start, end) of the HTTPS server { } of an nginx file."""
    i = 0
    while True:
        m = re.search(r'(?m)^[ \t]*server[ \t]*\{', text[i:])
        if not m:
            return None
        start = i + m.start()
        depth, j = 0, i + m.end() - 1
        while j < len(text):
            if text[j] == '{':
                depth += 1
            elif text[j] == '}':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        block = text[start:j + 1]
        if re.search(r'(?m)^\s*listen\s+[^;]*443[^;]*ssl', block) or \
                re.search(r'(?m)^\s*ssl_certificate\s', block):
            return start, j + 1
        i = j + 1


def set_directive(block, name, value):
    """`name value;` in a server { } - replaced where it is, put in after
    server_name where it is not, taken out for None. Only the server's own
    lines: a location { } inside is left alone."""
    lines = block.split('\n')
    depth, at, insert_at = 0, [], None
    for n, line in enumerate(lines):
        if depth == 1 and re.match(r'^\s*%s\s' % re.escape(name), line):
            at.append(n)
        if depth == 1 and insert_at is None and re.match(r'^\s*server_name\s', line):
            insert_at = n + 1
        depth += line.count('{') - line.count('}')
    if value is None:
        for n in reversed(at):
            del lines[n]
        return '\n'.join(lines)
    text = '    %-25s %s;' % (name, value)
    if at:
        lines[at[0]] = text
        for n in reversed(at[1:]):
            del lines[n]
    else:
        lines.insert(insert_at if insert_at is not None else 1, text)
    return '\n'.join(lines)


def set_pairs(block, pairs):
    """The server's ssl_certificate / ssl_certificate_key lines, one pair for
    each of `pairs`, each certificate followed by its key - where the first
    was, the others taken out (set_directive keeps one line of a name)."""
    lines = block.split('\n')
    depth, at = 0, []
    for n, line in enumerate(lines):
        if depth == 1 and re.match(r'^\s*ssl_certificate(_key)?\s', line):
            at.append(n)
        depth += line.count('{') - line.count('}')
    if not at:
        # None there yet: put in where set_directive puts a line (after
        # server_name), and written over below.
        lines = set_directive(block, 'ssl_certificate', pairs[0][0]).split('\n')
        depth = 0
        for n, line in enumerate(lines):
            if depth == 1 and re.match(r'^\s*ssl_certificate\s', line):
                at.append(n)
            depth += line.count('{') - line.count('}')
    first = at[0]
    for n in reversed(at):
        del lines[n]
    new = []
    for cert, key in pairs:
        new.append('    %-25s %s;' % ('ssl_certificate', cert))
        new.append('    %-25s %s;' % ('ssl_certificate_key', key))
    lines[first:first] = new
    return '\n'.join(lines)


def directive_all(block, name):
    """Every value of `name` among the server's own lines."""
    depth, out = 0, []
    for line in block.split('\n'):
        if depth == 1:
            m = re.match(r'^\s*%s\s+([^;]*);' % re.escape(name), line)
            if m:
                out.append(m.group(1).strip())
        depth += line.count('{') - line.count('}')
    return out


def directive_now(block, name):
    """The value of `name` among the server's own lines, or ''."""
    depth = 0
    for line in block.split('\n'):
        if depth == 1:
            m = re.match(r'^\s*%s\s+([^;]*);' % re.escape(name), line)
            if m:
                return m.group(1).strip()
        depth += line.count('{') - line.count('}')
    return ''


CIPHERS_DEFAULT = ('ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:'
                   'ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:'
                   'ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305')

PROGRESS = {'step': 0, 'total': 5, 'id': ''}
DH_EXPECT_S = {'gen2048': 15, 'gen3072': 120, 'gen4096': 600}


def progress(words, step=None, expect=None):
    if step is not None:
        PROGRESS['step'] = step
    try:
        write_here('progress.json', json.dumps({
            'id': PROGRESS['id'], 'step': PROGRESS['step'], 'total': PROGRESS['total'],
            'words': words, 'at': time.time(), 'expect_s': expect}))
    except OSError:
        pass


TLS_FILES = {'cert': os.path.join(CERT_DIR, 'isemon.pem'),
             'key': os.path.join(CERT_DIR, 'isemon.key'),
             'cert2': os.path.join(CERT_DIR, 'isemon-ecdsa.pem'),
             'key2': os.path.join(CERT_DIR, 'isemon-ecdsa.key'),
             'root': os.path.join(CERT_DIR, 'isemon-ca.pem'),
             'dh': os.path.join(CERT_DIR, 'isemon-dh.pem')}


def dh_file(choice, path, had):
    """The DH parameters for `choice` in `path`: a group of RFC 7919, or made
    here (which takes a while - 4096 bits minutes). Made ones are made once."""
    if choice == 'none':
        return None
    # What is in the file is said by a file of root's beside it, not by
    # status.json, which lies in the isemon account's folder.
    try:
        with open(path + '.choice') as f:
            had = f.read().strip()
    except OSError:
        had = ''
    if choice == had and os.path.exists(path):
        return path
    if choice.startswith('ffdhe'):
        pem = openssl(['genpkey', '-genparam', '-algorithm', 'DH', '-pkeyopt',
                       'group:%s' % choice], 'the DH group %s' % choice)
    else:
        progress('making DH parameters of %s bits' % choice[3:], 2, DH_EXPECT_S.get(choice))
        pem = openssl(['dhparam', choice[3:]], 'making DH parameters of %s bits' % choice[3:])
    write_root(path, pem, 0o644)
    write_root(path + '.choice', choice + '\n', 0o644)
    return path


def tls_into(block, t, dh_path):
    """The server { } with the TLS of `t`: its files written, its lines set."""
    said = []
    progress('writing the certificate and the TLS settings', 3)
    if t['pem']:
        # The pair install.sh made (or the site put there) kept once, beside,
        # the first time this replaces it: there is always a way back.
        for k in ('cert', 'key'):
            keep = TLS_FILES[k] + '.before-isemon'
            if os.path.exists(TLS_FILES[k]) and not os.path.exists(keep):
                shutil.copy2(TLS_FILES[k], keep)
        write_root(TLS_FILES['cert'], t['pem']['cert'] + t['pem']['chain'], 0o644)
        write_root(TLS_FILES['key'], t['pem']['key'], 0o600)
        pairs = [(TLS_FILES['cert'], TLS_FILES['key'])]
        two = t.get('pem2')
        if two:
            # Dual-cert (1.10.261): the ECDSA pair after the RSA one; nginx
            # answers with it the clients whose ciphers allow ECDSA.
            write_root(TLS_FILES['cert2'], two['cert'] + two['chain'], 0o644)
            write_root(TLS_FILES['key2'], two['key'], 0o600)
            pairs.append((TLS_FILES['cert2'], TLS_FILES['key2']))
        else:
            # None asked for: one left from before goes, with its key.
            for k in ('cert2', 'key2'):
                try:
                    os.unlink(TLS_FILES[k])
                except FileNotFoundError:
                    pass
        block = set_pairs(block, pairs)
        if t['pem']['root']:
            write_root(TLS_FILES['root'], t['pem']['root'] + t['pem']['chain'], 0o644)
            block = set_directive(block, 'ssl_trusted_certificate', TLS_FILES['root'])
        else:
            block = set_directive(block, 'ssl_trusted_certificate', None)
        subj = openssl(['x509', '-noout', '-subject', '-enddate'], 'the certificate',
                       t['pem']['cert']).strip().replace('\n', ', ')
        said.append('certificate: %s' % subj)
        if two:
            said.append('and the second one (ECDSA) beside it')
            # Of no use where TLS 1.2 has no ECDSA suite to offer (TLS 1.3
            # needs none): said, not refused - the RSA one still answers.
            if 'TLSv1.2' in t['protocols'] and t['ciphers'] and \
                    'Au=ECDSA' not in openssl(['ciphers', '-v', t['ciphers']], 'the ciphers'):
                said.append('the cipher list has no ECDHE-ECDSA suite: TLS 1.2 clients get the '
                            'RSA certificate alone')
    block = set_directive(block, 'ssl_protocols', ' '.join(t['protocols']))
    block = set_directive(block, 'ssl_ciphers', t['ciphers'] or CIPHERS_DEFAULT)
    block = set_directive(block, 'ssl_prefer_server_ciphers', 'on' if t['prefer'] else 'off')
    block = set_directive(block, 'ssl_dhparam', dh_path)
    if t['hsts']:
        block = set_directive(block, 'add_header Strict-Transport-Security',
                              '"max-age=%d" always' % t['hsts'])
    else:
        block = set_directive(block, 'add_header Strict-Transport-Security', None)
    said.append('%s; %s; DH %s%s' % (' '.join(t['protocols']),
                                     'ciphers as set' if t['ciphers'] else 'the usual ciphers',
                                     t['dh'], '; HSTS %d s' % t['hsts'] if t['hsts'] else ''))
    return block, said


def snapshot(paths):
    got = {}
    for p in paths:
        try:
            with open(p, 'rb') as f:
                got[p] = (f.read(), os.stat(p).st_mode & 0o777)
        except FileNotFoundError:
            got[p] = None
    return got


def put_back(snap):
    # Each file on its own (1.10.294): one that cannot be written back no
    # longer stops the others from being.
    failed = []
    for p, was in snap.items():
        if was is None:
            try:
                os.unlink(p)
            except OSError:
                pass
            continue
        try:
            fd, tmp = tempfile.mkstemp(dir=os.path.dirname(p))
            with os.fdopen(fd, 'wb') as f:
                f.write(was[0])
            os.chmod(tmp, was[1])
            os.replace(tmp, p)
            if shutil.which('restorecon') and not NO_SERVICES:
                subprocess.run(['restorecon', p], capture_output=True)
        except OSError:
            failed.append(p)
    if failed:
        print('isemon_web.py: not put back: %s' % ', '.join(failed), file=sys.stderr)


# ---- who may reach which page ---------------------------------------------------
# The dashboard's list is the HTTPS server's own allow lines; the ban feed
# and the health check each get a location of their own, with a list of its
# own, only when they are set to something other than "as the dashboard".
# Every list is between marks of isemon's, so it is found again after a
# hand edit; the machine itself (127.0.0.1, ::1) is always let in.
ALWAYS = ('127.0.0.1', '::1')
PAGES = (('banfeed', 'BANFEED', '/banfeed.php'), ('health', 'HEALTH', '/healthz.php'))


def nets_checked(one, what):
    nets = []
    for x in (one.get('from') or [])[:400]:
        try:
            net = plain(x, 'network')
        except ValueError:
            raise Refused('%r is not an address or a network' % str(x)[:60])
        # One address is written as the address, not as a network of one -
        # a /32 of IPv4 or a /128 of IPv6, never an IPv6 /32.
        nets.append(str(net.network_address) if net.prefixlen == net.max_prefixlen else str(net))
    return list(dict.fromkeys(n for n in nets if n not in ALWAYS))


def access_checked(a):
    if not isinstance(a, dict):
        return None
    out = {}
    d = a.get('dashboard')
    if not isinstance(d, dict):
        raise Refused('who may reach the dashboard is not given')
    nets = nets_checked(d, 'the dashboard')
    if not d.get('any') and not nets:
        raise Refused('the dashboard would be for this machine alone: give a network or '
                      'everybody')
    out['dashboard'] = {'any': bool(d.get('any')), 'from': nets}
    for k, _mark, _loc in PAGES:
        one = a.get(k)
        if not isinstance(one, dict):
            one = {'same': True}
        if one.get('same'):
            out[k] = {'same': True}
            continue
        nets = nets_checked(one, k)
        if not one.get('any') and not nets:
            raise Refused('the %s page would be for this machine alone: give a network, '
                          'everybody, or "as the dashboard"' % k)
        out[k] = {'same': False, 'any': bool(one.get('any')), 'from': nets}
    return out


def access_lines(one, pad):
    if one.get('any'):
        return pad + 'allow all;                    # everybody (Settings - Firewall and access)'
    return '\n'.join('%sallow %s;' % (pad, n) for n in one['from'])


def dashboard_into(block, one):
    """The HTTPS server's own allow lines as asked: the marked list, then the
    machine itself, then deny all. The allow and deny lines that were there
    (install.sh's, or somebody's) are what the marks replace."""
    lines = block.split('\n')
    begin = [n for n, l in enumerate(lines) if l.strip() == '# DASHBOARD-ALLOW-BEGIN']
    end = [n for n, l in enumerate(lines) if l.strip() == '# DASHBOARD-ALLOW-END']
    want = ['    # DASHBOARD-ALLOW-BEGIN'] + access_lines(one, '    ').split('\n') + \
        ['    # DASHBOARD-ALLOW-END']
    if begin and end and begin[0] < end[0]:
        return '\n'.join(lines[:begin[0]] + want + lines[end[0] + 1:])
    # The server's own run of allow / deny lines (comments after them kept
    # out): replaced by the marked list and the three that always follow it.
    depth, run_at = 0, []
    for n, l in enumerate(lines):
        if depth == 1 and re.match(r'^\s*(allow|deny)\s+[^;]+;', l):
            if run_at and n != run_at[-1] + 1:
                break
            run_at.append(n)
        elif run_at and depth == 1 and l.strip() and not l.strip().startswith('#'):
            break
        depth += l.count('{') - l.count('}')
    tail = ['    allow 127.0.0.1;', '    allow ::1;', '    deny  all;']
    if run_at:
        return '\n'.join(lines[:run_at[0]] + want + tail + lines[run_at[-1] + 1:])
    at = next((n + 1 for n, l in enumerate(lines) if re.match(r'^\s*server_name\s', l)), 1)
    return '\n'.join(lines[:at] + want + tail + lines[at:])


def dashboard_now(block):
    """What the dashboard's list says now: (any, nets, marked)."""
    m = re.search(r'# DASHBOARD-ALLOW-BEGIN\n(.*?)\n[ \t]*# DASHBOARD-ALLOW-END', block, re.S)
    if m:
        nets = re.findall(r'(?m)^\s*allow\s+([^;\s]+);', m.group(1))
        return 'all' in nets, [n for n in nets if n != 'all'], True
    depth, nets, deny_all = 0, [], False
    for l in block.split('\n'):
        if depth == 1:
            a = re.match(r'^\s*allow\s+([^;\s]+);', l)
            if a:
                nets.append(a.group(1))
            if re.match(r'^\s*deny\s+all\s*;', l):
                deny_all = True
        depth += l.count('{') - l.count('}')
    rest = [n for n in nets if n not in ALWAYS and n != 'all']
    return ('all' in nets) or not deny_all, rest, False


def php_lines(block):
    """The lines a location of its own needs to hand its file to PHP: those
    of the server's `location ~ \\.php$`, as the site wrote them."""
    m = re.search(r'(?ms)^[ \t]*location\s+~\*?\s+\\\.php\$\s*\{(.*?)^[ \t]*\}', block)
    if not m:
        m = re.search(r'(?ms)^[ \t]*location\s+=\s+/index\.php\s*\{(.*?)^[ \t]*\}', block)
    if not m:
        raise Refused('no location handing .php to PHP was found in %s' % NGINX_MAIN)
    keep = []
    for l in m.group(1).split('\n'):
        s = l.strip()
        if re.match(r'^(fastcgi_|include\s)', s):
            s = re.sub(r'\$document_root/index\.php', '$document_root$fastcgi_script_name', s)
            keep.append('        ' + s)
    if not any('fastcgi_pass' in l for l in keep):
        raise Refused('the .php location in %s has no fastcgi_pass' % NGINX_MAIN)
    return keep


def page_into(block, key, mark, loc, one):
    """A location of its own for the ban feed or the health check, with a
    list of its own - or none (as the dashboard)."""
    begin, end = '    # isemon-%s-begin' % key, '    # isemon-%s-end' % key
    # Taken out whole, with the blank line put in after it, wherever it is.
    rx = re.compile(r'(?ms)^[ \t]*# isemon-%s-begin[^\n]*\n.*?^[ \t]*# isemon-%s-end[^\n]*\n'
                    r'(?:[ \t]*\n)?' % (key, key))
    block = rx.sub('', block)
    if one.get('same'):
        return block
    body = ([begin + ' (Settings - Firewall and access: who may reach %s)' % loc,
             '    location = %s {' % loc,
             '        # %s-ALLOW-BEGIN' % mark] + access_lines(one, '        ').split('\n') +
            ['        # %s-ALLOW-END' % mark, '        allow 127.0.0.1;', '        allow ::1;',
             '        deny  all;'] + php_lines(block) + ['    }', end])
    # Before the catch-all .php location, or at the end of the server.
    m = re.search(r'(?m)^[ \t]*location\s+~\*?\s+\\\.php\$', block)
    at = m.start() if m else block.rstrip().rfind('}')
    return block[:at] + '\n'.join(body) + '\n\n' + block[at:]


def page_now(block, key, mark):
    m = re.search(r'# isemon-%s-begin.*?# %s-ALLOW-BEGIN\n(.*?)\n[ \t]*# %s-ALLOW-END'
                  % (key, mark, mark), block, re.S)
    if not m:
        return {'same': True}
    nets = re.findall(r'(?m)^\s*allow\s+([^;\s]+);', m.group(1))
    return {'same': False, 'any': 'all' in nets, 'from': [n for n in nets if n != 'all']}


def access_now():
    try:
        with open(NGINX_MAIN) as f:
            text = f.read()
    except OSError:
        return {}
    where = server_block(text)
    if not where:
        return {}
    block = text[where[0]:where[1]]
    anyone, nets, marked = dashboard_now(block)
    out = {'dashboard': {'any': anyone, 'from': nets, 'marked': marked}}
    for k, mark, _loc in PAGES:
        out[k] = page_now(block, k, mark)
    return out


def cert_now():
    """The certificate nginx answers with now, read off its file."""
    try:
        with open(NGINX_MAIN) as f:
            text = f.read()
    except OSError as e:
        return {'said': 'the vhost cannot be read: %s' % e}
    where = server_block(text)
    if not where:
        return {'said': 'no HTTPS server { } in %s' % NGINX_MAIN}
    block = text[where[0]:where[1]]
    out = {'path': directive_now(block, 'ssl_certificate'),
           'key_path': directive_now(block, 'ssl_certificate_key'),
           'protocols': directive_now(block, 'ssl_protocols'),
           'ciphers': directive_now(block, 'ssl_ciphers'),
           'dhparam': directive_now(block, 'ssl_dhparam'),
           'hsts': directive_now(block, 'add_header Strict-Transport-Security')}
    # A second pair (dual-cert, 1.10.261): its file named, its key never read.
    more = directive_all(block, 'ssl_certificate')[1:]
    if more:
        out['path2'] = more[0]
    if out['path']:
        try:
            with open(out['path']) as f:
                pem = f.read(400000)
            # The certificates only: a site whose file holds the key as
            # well must not see it copied into the isemon account's folder.
            out['pem'] = ''.join(m.group(0) + '\n' for m in re.finditer(
                r'-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+?-----END CERTIFICATE-----', pem))
        except OSError as e:
            out['said'] = 'the certificate file cannot be read: %s' % e
    return out


# ---- port 80 for the ACME CA (1.10.251; after otp_web.py 1.0.169) -------------------
# The port-80 server sends /.well-known/acme-challenge/ to acme.php, which asks
# the daemon for the answer kept in the database; everything else goes on to
# HTTPS as before. The location is let in for everybody - the CA asks from
# wherever it is - and the names the certificate is ordered for go into its
# server_name. Between marks of isemon's, so it is found again; the
# redirect of the server itself is moved into `location /`, for a `return`
# of the server's own is done before any location is looked at.
ACME_BEGIN = '    # isemon-acme-begin (Settings - Automatic certificates)'
ACME_END = '    # isemon-acme-end'


def http_block(text):
    """(start, end) of the port-80 server { } of an nginx file."""
    for m in re.finditer(r'(?m)^[ \t]*server[ \t]*\{', text):
        depth, j = 0, m.end() - 1
        while j < len(text):
            if text[j] == '{':
                depth += 1
            elif text[j] == '}':
                depth -= 1
                if depth == 0:
                    break
            j += 1
        block = text[m.start():j + 1]
        if re.search(r'(?m)^\s*listen\s+(\[::\]:)?80\b', block) and \
                not re.search(r'(?m)^\s*listen\s+[^;]*\bssl\b', block):
            return m.start(), j + 1
    return None


def acme_location(https_block, main):
    """The location, its PHP as the HTTPS server's own .php location hands
    files to PHP (the socket the site uses), the file under its root."""
    root = directive_now(https_block, 'root') or '/var/www/isemon'
    if not re.match(r'^/[A-Za-z0-9._/-]{1,200}$', root):
        raise Refused('the root of the HTTPS server is not a plain path: %r' % root[:80])
    php = [l for l in php_lines(https_block)
           if not re.match(r'^\s*fastcgi_param\s+(SCRIPT_FILENAME|HTTPS)\s', l)
           and not re.match(r'^\s*fastcgi_(index|read_timeout|send_timeout)\s', l)]
    lines = [ACME_BEGIN,
             '    # The CA\'s HTTP-01 question, answered by acme.php from what the daemon',
             '    # keeps; for everybody - whoever else the pages are for.',
             '    location ^~ /.well-known/acme-challenge/ {',
             '        allow all;']
    if 'zone=isemon_all:' in main:
        lines.append('        limit_req zone=isemon_all burst=20 nodelay;')
    lines += php
    lines += ['        fastcgi_param  SCRIPT_FILENAME %s/acme.php;' % root.rstrip('/'),
              '        fastcgi_read_timeout 10s;', '    }', ACME_END]
    return lines


def acme_into(main, names):
    """The port-80 server given the location for the CA and the names in its
    server_name. The file as it was when there is no port-80 server."""
    where = http_block(main)
    https = server_block(main)
    if not where or not https:
        return main, 'nginx: no port-80 server { } in %s - the CA cannot be answered on port ' \
                     '80 (put one in, or use DNS-01)' % NGINX_MAIN
    block = main[where[0]:where[1]]
    lines = block.split('\n')
    # What was put in before, taken out whole.
    begin = [n for n, l in enumerate(lines) if l.strip().startswith('# isemon-acme-begin')]
    end = [n for n, l in enumerate(lines) if l.strip() == '# isemon-acme-end']
    if begin and end and begin[0] < end[-1]:
        del lines[begin[0]:end[-1] + 1]
    # A `return` of the server's own (the redirect to HTTPS) into location /.
    depth, out = 0, []
    for l in lines:
        if depth == 1 and re.match(r'^\s*return\s+[^;]+;\s*(#.*)?$', l):
            out += ['    location / {', '    ' + l.rstrip(), '    }']
        else:
            out.append(l)
        depth += l.count('{') - l.count('}')
    lines = out
    # The location after server_name (or after the first line).
    at = next((n + 1 for n, l in enumerate(lines) if re.match(r'^\s*server_name\s', l)), 1)
    lines[at:at] = acme_location(main[https[0]:https[1]], main)
    new = '\n'.join(lines)
    m = re.search(r'(?m)^(\s*server_name\s+)([^;#]*);', new)
    if m and names:
        have = m.group(2).split()
        want = have + [n for n in names if n not in have]
        if want != have:
            new = new[:m.start()] + m.group(1) + ' '.join(want) + ';' + new[m.end():]
    if new == block:
        return main, ''
    return main[:where[0]] + new + main[where[1]:], \
        'nginx: port 80 answers the ACME CA (%s)' % (', '.join(names) or 'no name yet')


def nginx_part(r, last):
    """The server's TLS and lists, as asked. Returns (words, dh made)."""
    said, dh = [], (last.get('dh') or 'none')
    t = r['tls']
    dh_path = None
    # The DH files as they were, so that a change refused below puts them
    # back too, and so that new parameters are known to be new (1.10.227):
    # the file keeps its name, so nginx's lines did not change, nothing was
    # reloaded, and nginx went on with the old group until something else
    # reloaded it.
    dh_snap = snapshot([TLS_FILES['dh'], TLS_FILES['dh'] + '.choice'])
    if t:
        # DH parameters made first: it can take minutes, and nginx's file is
        # read only after it, so nothing changed in it meanwhile is written
        # over with an older copy.
        dh_path = dh_file(t['dh'], TLS_FILES['dh'], last.get('dh'))
        dh = t['dh']
    dh_new = snapshot(list(dh_snap)) != dh_snap
    paths = [NGINX_MAIN] + list(TLS_FILES.values())
    snap = snapshot(paths)
    snap.update(dh_snap)
    changed = False
    try:
        try:
            with open(NGINX_MAIN) as f:
                main = f.read()
        except OSError as e:
            raise Refused('the dashboard\'s nginx file cannot be read (%s): %s' % (NGINX_MAIN, e))
        if r.get('acme') is not None:
            new_main, words = acme_into(main, r['acme'])
            if words:
                said.append(words)
            if new_main != main:
                write_root(NGINX_MAIN, new_main, 0o644)
                main, changed = new_main, True
        where = server_block(main)
        if not where:
            raise Refused('no HTTPS server { } was found in %s' % NGINX_MAIN)
        block = main[where[0]:where[1]]
        new = block
        if r.get('access'):
            a = r['access']
            new = dashboard_into(new, a['dashboard'])
            for k, mark, loc in PAGES:
                new = page_into(new, k, mark, loc, a[k])
            if new != block:
                said.append('nginx: who may reach the dashboard, the ban feed and the health '
                            'check set')
        if t:
            new, words = tls_into(new, t, dh_path)
            said += words
        if new != block:
            write_root(NGINX_MAIN, main[:where[0]] + new + main[where[1]:], 0o644)
            changed = True
        elif t and (t['pem'] or (dh_new and dh_path)):
            changed = True          # the same lines, new files: nginx reads them again
        if changed and not NO_SERVICES:
            progress('asking nginx, and reloading it', 4)
            got = subprocess.run(['nginx', '-t'], capture_output=True, text=True)
            if got.returncode != 0:
                raise Refused('nginx does not take it, so it is as it was: %s'
                              % ((got.stderr or '').strip().splitlines() or ['?'])[-1][:300])
            got = subprocess.run(['systemctl', 'reload', 'nginx'], capture_output=True,
                                 text=True)
            if got.returncode != 0:
                # Said, not claimed (1.10.234): a reload that failed left
                # nginx answering with what it had, and the page said reloaded.
                raise Refused('nginx took it, but did not reload: %s'
                              % ((got.stderr or '').strip().splitlines() or ['?'])[-1][:300])
            said.append('nginx reloaded')
    except BaseException:
        put_back(snap)
        raise
    return said, dh


# ---- the machine's firewall ------------------------------------------------------
# Everything isemon opens is in a chain of its own, ISEMON-IN, jumped to first
# from INPUT - for IPv4 (iptables) and IPv6 (ip6tables). The rules already on
# the machine are left exactly as they are: isemon's chain only adds to them.
# With iptables-services the chain is also written into /etc/sysconfig/iptables
# and ip6tables (between marks of its own, the rest of the file untouched,
# its comments kept), so it is there after a reboot.
FW_CHAIN = 'ISEMON-IN'
FW_FILES = {4: os.environ.get('ISEMON_FW_FILE4', '/etc/sysconfig/iptables'),
            6: os.environ.get('ISEMON_FW_FILE6', '/etc/sysconfig/ip6tables')}
FW_TOOLS = {4: ('iptables', 'iptables-restore', 'iptables-save'),
            6: ('ip6tables', 'ip6tables-restore', 'ip6tables-save')}
FW_PROTOS = ('tcp', 'udp', 'icmp', 'any')
FW_MARK = '# isemon:'


def fw_backend():
    if not NO_SERVICES and shutil.which('firewall-cmd') and \
            subprocess.run(['firewall-cmd', '--state'], capture_output=True).returncode == 0:
        return 'firewalld'
    if shutil.which('iptables'):
        return 'iptables'
    return ''


def fw_rule_checked(x):
    if not isinstance(x, dict):
        raise Refused('a firewall rule is not an object')
    try:
        fam = int(x.get('family') or 0)
    except (TypeError, ValueError):
        fam = 0
    if fam not in (4, 6):
        raise Refused('a firewall rule is for IPv4 or IPv6')
    proto = str(x.get('proto') or 'any')
    if proto not in FW_PROTOS:
        raise Refused('the protocol is one of %s' % ', '.join(FW_PROTOS))
    port = str(x.get('port') or '').replace(' ', '')
    if port:
        if proto not in ('tcp', 'udp'):
            raise Refused('a port is for TCP or UDP')
        parts = port.split(',')
        # A range counts as two, as iptables counts it; matched whole.
        if sum(2 if '-' in p else 1 for p in parts) > 15 or \
                not all(re.fullmatch(r'[0-9]{1,5}(-[0-9]{1,5})?', p) for p in parts):
            raise Refused('the ports are numbers or ranges, by commas: 80,443 or 6514-6515')
        for p in parts:
            a, _, b = p.partition('-')
            if not 1 <= int(a) <= 65535 or (b and not int(a) <= int(b) <= 65535):
                raise Refused('%s is not a port or a range of them' % p)
    src = str(x.get('source') or '').strip()
    if src:
        try:
            net = plain(src, 'network')
        except ValueError:
            raise Refused('%r is not an address or a network' % src[:60])
        if net.version != fam:
            raise Refused('%s is not an IPv%d address' % (src, fam))
        src = str(net)
    action = str(x.get('action') or 'accept')
    if action not in ('accept', 'drop', 'reject'):
        raise Refused('a rule accepts, drops or rejects')
    note = re.sub(r'[^A-Za-z0-9 ._:/@()+,-]', '', str(x.get('note') or ''))[:120]
    return {'family': fam, 'proto': proto, 'port': port, 'source': src, 'action': action,
            'note': note}


def fw_args(r):
    a = ['-A', FW_CHAIN]
    if r['source']:
        a += ['-s', r['source']]
    if r['proto'] != 'any':
        proto = 'ipv6-icmp' if (r['proto'] == 'icmp' and r['family'] == 6) else r['proto']
        a += ['-p', proto]
    if r['port']:
        if ',' in r['port']:
            a += ['-m', 'multiport', '--dports', r['port'].replace('-', ':')]
        else:
            a += ['--dport', r['port'].replace('-', ':')]
    a += ['-m', 'comment', '--comment', '"isemon: %s"' % (r['note'] or r['proto'])]
    a += ['-j', r['action'].upper()]
    return ' '.join(a)


def fw_strip(text):
    """A saved ruleset without anything isemon put in it."""
    out = []
    for line in text.split('\n'):
        # iptables-save -c puts the counters first: [12:3456] -A INPUT ...
        k = re.sub(r'^\[\d+:\d+\]\s+', '', line.strip())
        if k.startswith(FW_MARK) or re.match(r'^:%s - \[\d+:\d+\]$' % FW_CHAIN, k) or \
                k == '-A INPUT -j %s' % FW_CHAIN or k.startswith('-A %s ' % FW_CHAIN):
            continue
        out.append(line)
    return '\n'.join(out)


def fw_into(text, lines, on):
    """isemon's chain into a saved ruleset (iptables-services' file), in the
    *filter table: its name, the jump from INPUT first, its rules last."""
    text = fw_strip(text)
    if not on:
        return text
    rows = text.split('\n')
    try:
        start = next(i for i, l in enumerate(rows) if l.strip() == '*filter')
    except StopIteration:
        rows += ['*filter', ':INPUT ACCEPT [0:0]', ':FORWARD ACCEPT [0:0]',
                 ':OUTPUT ACCEPT [0:0]', 'COMMIT']
        start = len(rows) - 5
    end = next((i for i in range(start + 1, len(rows)) if rows[i].strip() == 'COMMIT'), None)
    if end is None:
        raise Refused('the saved firewall has a *filter table without COMMIT')
    first_input = next((i for i in range(start, end) if rows[i].startswith('-A INPUT')), end)
    # The last declaration BEFORE the first rule of INPUT (1.10.238): one of
    # a hand-written file that came after it had the rows between written
    # twice.
    last_decl = max([i for i in range(start, first_input) if rows[i].startswith(':')] or [start])
    block = ['%s isemon opens what its functions need here (Settings - Firewall and access); '
             'changed only there' % FW_MARK] + lines + ['%s end' % FW_MARK]
    rows = (rows[:last_decl + 1] + [':%s - [0:0]' % FW_CHAIN] +
            rows[last_decl + 1:first_input] +
            ['%s every rule isemon makes is in %s' % (FW_MARK, FW_CHAIN),
             '-A INPUT -j %s' % FW_CHAIN] +
            rows[first_input:end] + block + rows[end:])
    return '\n'.join(rows)


def fw_now(fam):
    """What the machine's INPUT holds now, isemon's chain apart - shown on
    the page as what else is in the firewall."""
    tool = FW_TOOLS[fam][2]
    if not shutil.which(tool) or NO_SERVICES:
        return []
    got = subprocess.run([tool, '-t', 'filter'], capture_output=True, text=True)
    out = []
    for line in got.stdout.split('\n'):
        # The jump to isemon's chain shown too (1.10.223): where it stands
        # in INPUT is the one thing about INPUT isemon decides.
        if line.startswith(':INPUT ') or line.startswith('-A INPUT'):
            out.append(line.strip())
    return out[:200]


def fw_chain_now(fam):
    """isemon's own chain, as the kernel holds it now."""
    tool = FW_TOOLS[fam][0]
    if not shutil.which(tool) or NO_SERVICES:
        return []
    got = subprocess.run([tool, '-S', FW_CHAIN], capture_output=True, text=True)
    return [l.strip() for l in got.stdout.split('\n') if l.strip()][:400] \
        if got.returncode == 0 else []


def fw_base(fam):
    """What the chain lets through before anybody's rule: the machine's own
    loopback, the answers to what it asked itself (the router, the directory,
    DNS, the public lists), and on IPv6 the neighbour discovery it cannot
    live without. Ahead of the rules, so a DROP of somebody's cannot shut
    any of them out."""
    out = ['-A %s -i lo -m comment --comment "isemon: loopback" -j ACCEPT' % FW_CHAIN,
           '-A %s -m conntrack --ctstate ESTABLISHED,RELATED -m comment --comment '
           '"isemon: answers" -j ACCEPT' % FW_CHAIN]
    if fam == 6:
        out += ['-A %s -p ipv6-icmp -m icmp6 --icmpv6-type %d -m comment --comment '
                '"isemon: neighbour discovery" -j ACCEPT' % (FW_CHAIN, t)
                for t in (133, 134, 135, 136)]
    return out


def fw_said(stderr):
    """What iptables said, without its last line: that is always the hint
    to read its help."""
    lines = [x.strip() for x in (stderr or '').strip().splitlines()
             if x.strip() and not x.strip().startswith('Try `')]
    return '; '.join(lines[-3:]) or '?'


def fw_apply(f, said):
    for fam in (4, 6):
        tool, restore, _save = FW_TOOLS[fam]
        lines = fw_base(fam) + [fw_args(r) for r in f['rules'] if r['family'] == fam]
        if not shutil.which(tool):
            continue
        if f['on']:
            snippet = '*filter\n:%s - [0:0]\n%s\nCOMMIT\n' % (FW_CHAIN, '\n'.join(lines))
            got = subprocess.run([restore, '--noflush'], input=snippet, capture_output=True,
                                 text=True)
            if got.returncode != 0:
                raise Refused('%s does not take the rules: %s' % (restore, fw_said(got.stderr)))
            if subprocess.run([tool, '-C', 'INPUT', '-j', FW_CHAIN],
                              capture_output=True).returncode != 0:
                subprocess.run([tool, '-I', 'INPUT', '1', '-j', FW_CHAIN], capture_output=True)
            said.append('IPv%d: %d rule(s) in %s' % (fam, len(lines), FW_CHAIN))
        else:
            while subprocess.run([tool, '-D', 'INPUT', '-j', FW_CHAIN],
                                 capture_output=True).returncode == 0:
                pass
            subprocess.run([tool, '-F', FW_CHAIN], capture_output=True)
            subprocess.run([tool, '-X', FW_CHAIN], capture_output=True)
        # Kept over a reboot, where iptables-services keeps the rules.
        path = FW_FILES[fam]
        if os.path.exists(path):
            with open(path) as fh:
                old = fh.read()
            new = fw_into(old, lines, f['on'])
            if new != old:
                fd, tmp = tempfile.mkstemp(prefix='.isemon-fw-', dir=os.path.dirname(path))
                with os.fdopen(fd, 'w') as fh:
                    fh.write(new if new.endswith('\n') else new + '\n')
                test = subprocess.run([restore, '--test', tmp], capture_output=True, text=True)
                if test.returncode != 0:
                    os.unlink(tmp)
                    raise Refused('%s would not take the file, so it was left as it was: %s' % (
                        restore, fw_said(test.stderr)))
                os.chmod(tmp, os.stat(path).st_mode & 0o777)
                os.replace(tmp, path)
                if shutil.which('restorecon') and not NO_SERVICES:
                    subprocess.run(['restorecon', path], capture_output=True)
                said.append('%s: kept over a reboot' % path)
        elif f['on']:
            said.append('IPv%d: not kept over a reboot - %s is not there (dnf install '
                        'iptables-services)' % (fam, path))


def fw_can(f):
    """Refused before anything is touched when the firewall asked for cannot
    be done here at all (1.10.227). Found out only after nginx had been
    changed and reloaded, the whole request was said to have failed while
    the new certificate and lists were already in force - and the same
    request was never asked again."""
    if f is None or not f['on']:
        return
    fw_part_check(fw_backend())


def fw_part_check(backend):
    if backend == 'firewalld':
        raise Refused('firewalld manages this machine\'s firewall: isemon leaves it to it. '
                      'To manage it here, use iptables (dnf install iptables-services; '
                      'systemctl disable --now firewalld; systemctl enable --now iptables '
                      'ip6tables)')
    if not backend:
        raise Refused('there is no iptables on this machine')


def fw_part(f):
    """The firewall as asked: (words, report)."""
    said = []
    backend = fw_backend()
    report = {'backend': backend}
    if f is None:
        return said, report
    if backend == 'firewalld':
        if f['on']:
            raise Refused('firewalld manages this machine\'s firewall: isemon leaves it to it. '
                          'To manage it here, use iptables (dnf install iptables-services; '
                          'systemctl disable --now firewalld; systemctl enable --now iptables '
                          'ip6tables)')
        return said, report
    if not backend:
        if f['on']:
            raise Refused('there is no iptables on this machine')
        return said, report
    progress('the firewall', 4)
    # As it was, live and in the files, to go back to when anything fails
    # half way - never a machine left half done.
    was_live, was_file = {}, {}
    for fam in (4, 6):
        if shutil.which(FW_TOOLS[fam][2]):
            was_live[fam] = subprocess.run([FW_TOOLS[fam][2]], capture_output=True,
                                           text=True).stdout
        if os.path.exists(FW_FILES[fam]):
            was_file[fam] = snapshot([FW_FILES[fam]])
    try:
        fw_apply(f, said)
    except BaseException:
        for fam, text in was_live.items():
            if text.strip():
                subprocess.run([FW_TOOLS[fam][1]], input=text, capture_output=True, text=True)
            else:
                tool = FW_TOOLS[fam][0]
                while subprocess.run([tool, '-D', 'INPUT', '-j', FW_CHAIN],
                                     capture_output=True).returncode == 0:
                    pass
                subprocess.run([tool, '-F', FW_CHAIN], capture_output=True)
                subprocess.run([tool, '-X', FW_CHAIN], capture_output=True)
        for snap in was_file.values():
            put_back(snap)
        raise
    if not f['on']:
        said.append('the firewall: isemon\'s rules taken away; the rest is as it was')
    return said, report


# ---- the ports the logs arrive on -------------------------------------------------
def rsyslog_ports():
    """What rsyslog on this machine listens on, read off its own files:
    [{'proto': 'udp'|'tcp', 'port': '514'}]. RELP and TLS are TCP."""
    files = []
    for one in RSYSLOG_FILES.split(':'):
        if os.path.isdir(one):
            files += sorted(os.path.join(one, n) for n in os.listdir(one) if n.endswith('.conf'))
        elif os.path.isfile(one):
            files.append(one)
    found = []
    for path in files:
        try:
            with open(path, encoding='utf-8', errors='replace') as f:
                text = f.read(1 << 20)
        except OSError:
            continue
        text = '\n'.join(l for l in text.split('\n') if not l.strip().startswith('#'))
        for m in re.finditer(r'input\s*\(([^)]*)\)', text, re.S):
            body = m.group(1)
            kind = re.search(r'type\s*=\s*"(im[a-z]+)"', body)
            port = re.search(r'port\s*=\s*"([0-9]{1,5})"', body)
            if kind and kind.group(1) in ('imudp', 'imtcp', 'imptcp', 'imrelp'):
                found.append({'proto': 'udp' if kind.group(1) == 'imudp' else 'tcp',
                              'port': port.group(1) if port else '514',
                              'file': os.path.basename(path)})
        for m in re.finditer(r'(?m)^\s*\$(UDPServerRun|InputTCPServerRun|InputRELPServerRun|'
                             r'InputPTCPServerRun)\s+([0-9]{1,5})', text):
            found.append({'proto': 'udp' if m.group(1) == 'UDPServerRun' else 'tcp',
                          'port': m.group(2), 'file': os.path.basename(path)})
    seen, out = set(), []
    for one in found:
        k = (one['proto'], one['port'])
        if k not in seen and 1 <= int(one['port']) <= 65535:
            seen.add(k)
            out.append(one)
    return out


def ssh_ports():
    """The ports sshd listens on, from its own file (22 when it does not say)."""
    ports = []
    for path in ['/etc/ssh/sshd_config'] + sorted(
            os.path.join('/etc/ssh/sshd_config.d', n)
            for n in (os.listdir('/etc/ssh/sshd_config.d')
                      if os.path.isdir('/etc/ssh/sshd_config.d') else [])
            if n.endswith('.conf')):
        try:
            with open(path, encoding='utf-8', errors='replace') as f:
                for line in f:
                    m = re.match(r'^\s*Port\s+([0-9]{1,5})\s*$', line, re.I)
                    if m:
                        ports.append(m.group(1))
        except OSError:
            pass
    return list(dict.fromkeys(ports)) or ['22']


def look():
    """Everything the page shows of how things are here, changing nothing."""
    out = {'at': time.time(), 'cert': cert_now(), 'access': access_now(),
           'backend': fw_backend(), 'rsyslog': rsyslog_ports(), 'ssh': ssh_ports(),
           'nginx_conf': NGINX_MAIN, 'files': {
               str(f): os.path.exists(p) for f, p in FW_FILES.items()}}
    if out['backend'] == 'iptables':
        out['now'] = {4: fw_now(4), 6: fw_now(6)}
        out['chain'] = {4: fw_chain_now(4), 6: fw_chain_now(6)}
    return out


def drop_entry(name):
    """An entry of the request folder taken away, whatever the isemon account
    made of it (1.10.238): a file, a link, an empty folder - or a folder with
    something in it, moved aside and never read. True when one was there."""
    d = web_fd()
    try:
        os.unlink(name, dir_fd=d)
        return True
    except FileNotFoundError:
        return False
    except OSError:
        pass
    try:
        os.rmdir(name, dir_fd=d)
        return True
    except OSError:
        pass
    try:
        os.rename(name, '.refused-%s-%d' % (name, int(time.time())), src_dir_fd=d, dst_dir_fd=d)
    except OSError:
        pass
    return True


def look_part():
    if not drop_entry(LOOK_ASK):
        return
    try:
        out = look()
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out = {'at': time.time(), 'said': 'it could not be read: %s' % str(e)[:200]}
    write_here(LOOK_FILE, json.dumps(out))


# ---- the clock: chrony (1.10.228; after otp's otp_web.py 1.0.120) ----------------
# Asked in ntp.ask: how the clock is (read), chrony's servers set (apply), a
# step to the right time now (sync); answered in ntp.json. /etc/chrony.conf
# keeps everything of its own: when isemon sets the servers, the file's own
# server/pool/makestep/allow lines are commented out (#isemon# ) and isemon's
# block goes between two marks at the end - and they are put back as they
# were when isemon stops setting them. Nothing is changed for a read.
NTP_ASK = 'ntp.ask'
NTP_FILE = 'ntp.json'
CHRONYC = os.environ.get('ISEMON_CHRONYC', 'chronyc')
TIMEDATECTL = os.environ.get('ISEMON_TIMEDATECTL', 'timedatectl')
CHRONY_CONF = os.environ.get('ISEMON_CHRONY_CONF', '/etc/chrony.conf')
NTP_NO_SERVICE = bool(os.environ.get('ISEMON_NTP_NO_SERVICE'))  # tests: no systemctl, set-ntp
NTP_BEGIN = '# ---- isemon: the time servers, set on its pages (Settings - Time) ----'
NTP_END = '# ---- isemon: end ----'
NTP_OFF = '#isemon# '
NTP_KEYS = ('server', 'pool', 'peer', 'makestep', 'allow', 'minsources', 'maxdistance',
            'sourcedir')
NTP_NAME_RE = re.compile(r'^(?=.{1,253}\Z)[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?'
                         r'(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*\Z')
TZ_RE = re.compile(r'^[A-Za-z][A-Za-z0-9_+-]{0,39}(/[A-Za-z0-9_+-]{1,40}){0,3}\Z')


def ntp_run(cmd, what, ok=(0,), timeout=60):
    try:
        got = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as e:
        raise Refused('%s: %s' % (what, str(e)[:200]))
    if got.returncode not in ok:
        raise Refused('%s: %s' % (what, (got.stderr or got.stdout).strip()[-300:] or
                                  'ended with %d' % got.returncode))
    return got.stdout


def ntp_read():
    """How the clock is, as timedatectl and chrony say it - nothing changed."""
    out = {'chrony': bool(shutil.which(CHRONYC)), 'tracking': {}, 'sources': []}
    try:
        t = ntp_run([TIMEDATECTL, 'show'], 'timedatectl', ok=(0, 1))
        for line in t.splitlines():
            if '=' in line:
                k, v = line.split('=', 1)
                if k in ('Timezone', 'NTP', 'NTPSynchronized', 'LocalRTC', 'CanNTP'):
                    out[k.lower()] = v[:80]
    except (Refused, OSError):
        pass
    out['time'] = time.time()
    if not out['chrony']:
        return out
    try:
        f = ntp_run([CHRONYC, '-n', '-c', 'tracking'], 'chronyc tracking').strip().split(',')
        if len(f) >= 14:
            out['tracking'] = {'ref_id': f[0][:40], 'ref': f[1][:120], 'stratum': int(f[2] or 0),
                               'ref_time': float(f[3] or 0), 'offset': float(f[4] or 0),
                               'last_offset': float(f[5] or 0), 'rms': float(f[6] or 0),
                               'freq': float(f[7] or 0), 'skew': float(f[9] or 0),
                               'root_delay': float(f[10] or 0), 'root_disp': float(f[11] or 0),
                               'interval': float(f[12] or 0), 'leap': f[13][:40]}
    except (Refused, ValueError, OSError) as e:
        out['said'] = str(e)[:200]
        # chrony there, chronyd not running (1.10.237): said as such, and
        # Step it now starts it.
        if '506' in str(e) or 'Cannot talk to daemon' in str(e):
            out['down'] = True
    try:
        for line in ntp_run([CHRONYC, '-n', '-c', 'sources'], 'chronyc sources').splitlines()[:40]:
            f = line.split(',')
            if len(f) < 10:
                continue
            try:
                out['sources'].append({'mode': f[0][:1], 'state': f[1][:1], 'name': f[2][:120],
                                       'stratum': int(f[3] or 0), 'poll': int(f[4] or 0),
                                       'reach': int(f[5] or 0, 8) if f[5] else 0,
                                       'last_rx': int(f[6]) if f[6].lstrip('-').isdigit() else None,
                                       'offset': float(f[7] or 0), 'measured': float(f[8] or 0),
                                       'error': float(f[9] or 0)})
            except ValueError:
                continue
    except (Refused, OSError):
        pass
    try:
        text = chrony_read()
        out['managed'] = NTP_BEGIN in text
        out['own'] = [l.strip()[:200] for l in text.split('\n')
                      if (l.split() or [''])[0].lower() in ('server', 'pool', 'peer')][:20]
    except OSError:
        out['managed'] = False
    out['conf'] = CHRONY_CONF
    return out


def ntp_checked(r):
    """What the daemon asks for, checked again: every value has one shape."""
    out = {'manage': bool(r.get('manage')), 'servers': [], 'allow': [],
           'makestep': [1.0, 3], 'minsources': 1, 'timezone': ''}
    servers = r.get('servers') or []
    if not isinstance(servers, list):
        raise Refused('the servers are a list')
    for x in servers[:12]:
        if not isinstance(x, dict):
            raise Refused('a server is an object')
        host = str(x.get('host') or '').strip().lower().rstrip('.')
        if re.search(r'[\s\x00-\x1f\x7f]', host):
            raise Refused('%r is not a host name or an address' % host[:80])
        try:
            host = str(plain(host, 'address'))
        except ValueError:
            if not NTP_NAME_RE.match(host):
                raise Refused('%r is not a host name or an address' % host[:80])
        out['servers'].append({'host': host, 'pool': bool(x.get('pool')),
                               'iburst': bool(x.get('iburst', True)),
                               'prefer': bool(x.get('prefer')), 'nts': bool(x.get('nts'))})
    allow = r.get('allow') or []
    if not isinstance(allow, list):
        raise Refused('the networks served are a list')
    for a in allow[:20]:
        try:
            out['allow'].append(str(plain(a, 'network')))
        except ValueError:
            raise Refused('%r is not a network (192.0.2.0/24)' % str(a)[:60])
    try:
        th = float((r.get('makestep') or [1.0, 3])[0])
        lim = int((r.get('makestep') or [1.0, 3])[1])
    except (TypeError, ValueError, IndexError, KeyError, OverflowError):
        raise Refused('makestep is a threshold in seconds and a number of updates')
    if not (0.001 <= th <= 3600) or not (-1 <= lim <= 1000):
        raise Refused('makestep: 0.001 - 3600 s, and -1 (always) to 1000 updates')
    out['makestep'] = [th, lim]
    try:
        out['minsources'] = max(1, min(10, int(r.get('minsources') or 1)))
    except (TypeError, ValueError, OverflowError):
        out['minsources'] = 1
    tz = str(r.get('timezone') or '').strip()
    if tz and not TZ_RE.match(tz):
        raise Refused('%r is not a time zone' % tz[:60])
    out['timezone'] = tz
    if out['manage'] and not out['servers']:
        raise Refused('at least one time server')
    return out


def chrony_read():
    """chrony.conf as it is, whatever its letters (1.10.238): a comment in
    Latin-2 stopped every reading of the clock."""
    with open(CHRONY_CONF, encoding='utf-8', errors='surrogateescape') as f:
        return f.read()


def ntp_conf_text(text, n):
    """chrony.conf with isemon's block (or without it, put back as it was)."""
    # Not set by isemon, and not to be: the file exactly as it is - never
    # rewritten for a final newline (1.10.238).
    if not n['manage'] and NTP_BEGIN not in text and NTP_OFF not in text:
        return text
    lines = text.split('\n')
    if NTP_BEGIN in [l.strip() for l in lines] and NTP_END not in [l.strip() for l in lines]:
        raise Refused('%s has isemon\'s beginning mark and not its end: put it right by hand '
                      '(nothing after the mark is taken away)' % CHRONY_CONF)
    out, inside = [], False
    for l in lines:
        if l.strip() == NTP_BEGIN:
            inside = True
            continue
        if l.strip() == NTP_END:
            inside = False
            continue
        if inside:
            continue
        if l.startswith(NTP_OFF):
            l = l[len(NTP_OFF):]              # the file's own line, put back first
        out.append(l)
    if not n['manage']:
        return '\n'.join(out).rstrip('\n') + '\n'
    kept = [NTP_OFF + l if (l.split() or [''])[0].lower() in NTP_KEYS else l for l in out]
    block = [NTP_BEGIN]
    for x in n['servers']:
        opts = [o for o, on in (('iburst', x['iburst']), ('prefer', x['prefer']),
                                ('nts', x['nts'])) if on]
        block.append(('%s %s %s' % ('pool' if x['pool'] else 'server', x['host'],
                                    ' '.join(opts))).rstrip())
    for a in n['allow']:
        block.append('allow %s' % a)
    block.append('makestep %s %d' % (('%g' % n['makestep'][0]), n['makestep'][1]))
    if n['minsources'] > 1:
        block.append('minsources %d' % n['minsources'])
    block.append(NTP_END)
    if any('\n' in l or '\r' in l for l in block):
        raise Refused('a line of the time servers is not one line')
    return '\n'.join([l.rstrip() for l in kept]).rstrip('\n') + '\n\n' + '\n'.join(block) + '\n'


def ntp_apply(n):
    said = []
    if n['manage'] and not shutil.which(CHRONYC) and not NO_SERVICES:
        if shutil.which('dnf'):
            ntp_run(['dnf', '-y', 'install', 'chrony'], 'dnf install chrony', timeout=240)
            said.append('chrony installed')
        else:
            raise Refused('chrony is not on this machine')
    try:
        had = chrony_read()
    except FileNotFoundError:
        had = 'driftfile /var/lib/chrony/drift\nrtcsync\nlogdir /var/log/chrony\n'
    new = ntp_conf_text(had, n)
    if new != had:
        live = not NO_SERVICES and not NTP_NO_SERVICE
        # chronyd's own word on the file before it is put in (1.10.238): one
        # it refuses stops chronyd, and nothing keeps the clock.
        chronyd = shutil.which('chronyd') if live else None
        if chronyd:
            fd, tmp = tempfile.mkstemp(prefix='.isemon-chrony-', dir=os.path.dirname(CHRONY_CONF))
            try:
                with os.fdopen(fd, 'w', encoding='utf-8', errors='surrogateescape') as f:
                    f.write(new)
                ntp_run([chronyd, '-p', '-f', tmp], 'chronyd -p (the new chrony.conf)')
            finally:
                try:
                    os.unlink(tmp)
                except OSError:
                    pass
        if NTP_BEGIN not in had:
            try:
                write_root(CHRONY_CONF + '.isemon-before', had, 0o644)
            except OSError:
                pass
        write_root(CHRONY_CONF, new, 0o644)
        said.append('%s: %s' % (CHRONY_CONF, ', '.join(x['host'] for x in n['servers'])
                                if n['manage'] else 'its own servers again'))
        if live:
            try:
                ntp_run(['systemctl', 'enable', '--now', 'chronyd'], 'systemctl enable chronyd')
                ntp_run(['systemctl', 'restart', 'chronyd'], 'systemctl restart chronyd')
            except Refused as e:
                # Put back as it was, and chronyd started with that.
                write_root(CHRONY_CONF, had, 0o644)
                try:
                    ntp_run(['systemctl', 'restart', 'chronyd'], 'systemctl restart chronyd')
                except Refused:
                    pass
                raise Refused('%s - chrony.conf put back as it was' % e)
            said.append('chronyd restarted')
    if n['timezone']:
        try:
            cur = ntp_run([TIMEDATECTL, 'show', '-p', 'Timezone', '--value'],
                          'timedatectl').strip()
        except Refused:
            cur = ''
        if cur != n['timezone']:
            # Said on its own (1.10.238): the time servers were set all the same.
            try:
                ntp_run([TIMEDATECTL, 'set-timezone', n['timezone']], 'timedatectl set-timezone')
                said.append('time zone: %s' % n['timezone'])
            except Refused as e:
                said.append('the time zone was NOT set: %s' % e)
    if n['manage'] and not NO_SERVICES and not NTP_NO_SERVICE and shutil.which(TIMEDATECTL):
        ntp_run([TIMEDATECTL, 'set-ntp', 'true'], 'timedatectl set-ntp', ok=(0, 1))
    return {'said': said}


def ntp_drop(d):
    """The asking file taken away, whatever the isemon account made of it - a
    folder in its place is removed too, or the path unit would start this
    again and again."""
    try:
        os.unlink(NTP_ASK, dir_fd=d)
    except FileNotFoundError:
        pass
    except OSError:
        try:
            os.rmdir(NTP_ASK, dir_fd=d)
        except OSError:
            # A folder with something in it (1.10.238): moved aside, never
            # read, so the path unit is not started again and again.
            try:
                os.rename(NTP_ASK, '.refused-%s-%d' % (NTP_ASK, int(time.time())),
                          src_dir_fd=d, dst_dir_fd=d)
            except OSError:
                pass


def ntp_part():
    d = web_fd()
    try:
        raw = read_req(NTP_ASK, 65536)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        ntp_drop(d)
        return
    ntp_drop(d)
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        try:
            r = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise Refused('the request does not read')
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        what = r.get('do')
        if what != 'read' and ask_stale(r):
            raise Refused('that was asked too long ago - ask again on the page if it is still '
                          'wanted')
        if what == 'read':
            out['data'] = ntp_read()
            if r.get('zones'):
                try:
                    out['data']['zones'] = [z for z in ntp_run(
                        [TIMEDATECTL, 'list-timezones'], 'timedatectl').split()
                        if TZ_RE.match(z)][:700]
                except Refused:
                    pass
        elif what == 'apply':
            out['data'] = ntp_apply(ntp_checked(r))
        elif what == 'sync':
            words = []
            # chronyd not running - installed, never started: started first
            # (1.10.237), or there is nothing to step the clock with.
            if not NO_SERVICES and not NTP_NO_SERVICE and subprocess.run(
                    ['systemctl', 'is-active', '--quiet', 'chronyd'], timeout=30).returncode != 0:
                ntp_run(['systemctl', 'enable', '--now', 'chronyd'], 'systemctl enable chronyd')
                words.append('chronyd started')
                time.sleep(3)
            said = ntp_run([CHRONYC, 'makestep'], 'chronyc makestep').strip()
            ntp_run([CHRONYC, 'burst', '4/4'], 'chronyc burst', ok=(0, 1))
            out['data'] = {'said': words + [said[:200] or 'stepped']}
        else:
            raise Refused('read, apply or sync')
        out['ok'] = True
    except Refused as e:
        out['said'] = str(e)[:400]
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    write_here(NTP_FILE, json.dumps(out))


# ---- the SSH keys root signs in with (1.10.239; after otp's otp_web.py 1.0.158) ----
# Asked in sshkeys.ask: the keys there now (list), one more (add), one taken
# away (drop); answered in sshkeys.json with what is there after it and what
# sshd makes of root. Only /root/.ssh/authorized_keys is ever written, whole:
# a new file of root's, 0600, made beside it and renamed over it, in a folder
# that is not a link (made 0700 when it is not there); the file itself never
# read or written through a link. Every line it does not understand - a
# comment, a key with options before it - is kept as it was. A key is added
# only as one plain public key line (Ed25519, ECDSA, RSA of 3072 bits and
# more), and the last key root signs in with goes only when said again.
SSHKEYS_ASK = 'sshkeys.ask'
SSHKEYS_FILE = 'sshkeys.json'
ROOT_AUTH = os.environ.get('ISEMON_ROOT_AUTHKEYS', '/root/.ssh/authorized_keys')
SSH_KEYGEN = os.environ.get('ISEMON_SSH_KEYGEN', 'ssh-keygen')
SSHD = os.environ.get('ISEMON_SSHD', 'sshd')
SSHKEYS_FRESH_S = 600              # an add or a drop asked longer ago is not done
ASK_FRESH_S = 300                  # a change of the network, the clock or a restart (1.10.305)


def ask_stale(r):
    """Whether a request says it was asked longer ago than ASK_FRESH_S: one
    the daemon gave up on and that lay here - a busy run, the path unit
    stopped - is never done minutes or a boot later. One that says nothing
    of when (an older daemon) is taken as it is."""
    if 'at' not in r:
        return False
    try:
        at = float(r.get('at'))
    except (TypeError, ValueError):
        return True
    return not math.isfinite(at) or abs(time.time() - at) > ASK_FRESH_S
KEY_TYPES = ('ssh-ed25519', 'ecdsa-sha2-nistp256', 'ecdsa-sha2-nistp384', 'ecdsa-sha2-nistp521',
             'ssh-rsa', 'sk-ssh-ed25519@openssh.com', 'sk-ecdsa-sha2-nistp256@openssh.com')
KEY_LINE_RE = re.compile(r'^(?P<type>[a-z0-9@.-]+) (?P<blob>[A-Za-z0-9+/]{40,16000}={0,3})'
                         r'(?: (?P<comment>[^\x00-\x1f\x7f]{0,200}))?\Z')


def key_facts(line):
    """(bits, SHA256:..., type) of one public key line, read by ssh-keygen;
    None when it does not read it."""
    if not shutil.which(SSH_KEYGEN):
        return None
    got = subprocess.run([SSH_KEYGEN, '-l', '-E', 'sha256', '-f', '-'], input=line + '\n',
                         capture_output=True, text=True, timeout=20)
    m = re.match(r'^(\d+) (SHA256:[A-Za-z0-9+/=]+) .*\((\w+)\)\s*$', got.stdout.strip())
    if got.returncode != 0 or not m:
        return None
    return int(m.group(1)), m.group(2), m.group(3)


def auth_lines():
    """The lines of root's authorized_keys - none where it is not there.
    Never through a link."""
    try:
        fd = os.open(ROOT_AUTH, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        return []
    except OSError as e:
        raise Refused('%s cannot be read: %s' % (ROOT_AUTH, e))
    with os.fdopen(fd, 'r', encoding='utf-8', errors='surrogateescape') as f:
        if not stat.S_ISREG(os.fstat(f.fileno()).st_mode):
            raise Refused('%s is not a plain file' % ROOT_AUTH)
        return f.read(1 << 20).split('\n')


def auth_keys(lines):
    out = []
    for i, ln in enumerate(lines):
        t = ln.strip()
        if not t or t.startswith('#'):
            continue
        facts = key_facts(t)
        m = KEY_LINE_RE.match(t)
        out.append({'line': i, 'fp': facts[1] if facts else '', 'bits': facts[0] if facts else 0,
                    'type': facts[2] if facts else '?',
                    'comment': (m.group('comment') or '') if m else '',
                    'options': not bool(m), 'readable': bool(facts),
                    # The line itself, for the page's export: public halves only.
                    'text': t[:16500].encode('utf-8', 'replace').decode('utf-8', 'replace')})
    return out


def auth_write(lines):
    """root's authorized_keys written whole: its folder made 0700 when it is
    not there, refused when it is a link; a new file of root's, 0600, renamed
    in."""
    folder = os.path.dirname(ROOT_AUTH)
    try:
        st = os.lstat(folder)
        if stat.S_ISLNK(st.st_mode) or not stat.S_ISDIR(st.st_mode):
            raise Refused('%s is not a plain folder' % folder)
    except FileNotFoundError:
        os.makedirs(folder, mode=0o700)
        os.chmod(folder, 0o700)
    try:
        if not stat.S_ISREG(os.lstat(ROOT_AUTH).st_mode):
            raise Refused('%s is a link or not a plain file - put the file itself there'
                          % ROOT_AUTH)
    except FileNotFoundError:
        pass
    text = '\n'.join(lines).rstrip('\n') + '\n'
    fd, tmp = tempfile.mkstemp(prefix='.authorized_keys.', dir=folder)
    try:
        os.fchmod(fd, 0o600)
        if os.geteuid() == 0:
            os.fchown(fd, 0, 0)
        with os.fdopen(fd, 'w', encoding='utf-8', errors='surrogateescape') as f:
            fd = None
            f.write(text)
        os.replace(tmp, ROOT_AUTH)
    except BaseException:
        if fd is not None:
            os.close(fd)
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    if shutil.which('restorecon') and not NO_SERVICES:
        subprocess.run(['restorecon', '-R', folder], capture_output=True)


def sshd_says():
    """What sshd makes of root and of keys: a key is no use where it does not
    let root in with one."""
    sshd = shutil.which(SSHD) or ('/usr/sbin/sshd' if os.path.exists('/usr/sbin/sshd') else '')
    if not sshd:
        return {'there': False}
    try:
        got = subprocess.run([sshd, '-T'], capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.SubprocessError):
        return {'there': False}
    said = {}
    for ln in got.stdout.splitlines():
        k, _, v = ln.partition(' ')
        if k in ('permitrootlogin', 'pubkeyauthentication', 'passwordauthentication', 'port'):
            said.setdefault(k, re.sub(r'[^A-Za-z0-9-]', '', v.strip())[:40])
    return {'there': True, 'permit_root': said.get('permitrootlogin', ''),
            'pubkey': said.get('pubkeyauthentication', ''),
            'password': said.get('passwordauthentication', ''), 'port': said.get('port', '')}


def sshkeys_do(r):
    do = r.get('do')
    if do in ('add', 'drop'):
        # One left lying from before (an older helper, a run that never
        # came): never done long after it was asked.
        try:
            at = float(r.get('at') or 0)
        except (TypeError, ValueError):
            at = 0.0
        if not math.isfinite(at) or abs(time.time() - at) > SSHKEYS_FRESH_S:
            raise Refused('that was asked too long ago - ask again on the page if it is still '
                          'wanted')
    lines = auth_lines()
    if do == 'add':
        line = str(r.get('line') or '').strip()
        m = KEY_LINE_RE.match(line)
        if not m or m.group('type') not in KEY_TYPES:
            raise Refused('that is not one public key line (ssh-ed25519 AAAA... comment) - '
                          'options before the key are not taken here')
        facts = key_facts(line)
        if not facts:
            raise Refused('ssh-keygen does not read that key')
        bits, fp, kind = facts
        if kind == 'RSA' and bits < 3072:
            raise Refused('an RSA key of %d bits is too weak: 3072 at least, or ed25519' % bits)
        if kind == 'DSA':
            raise Refused('DSA keys are not taken')
        # There already is no fault: a key of root's handed over again.
        if not any(k['fp'] == fp for k in auth_keys(lines)):
            auth_write([ln for ln in lines if ln.strip()] + [line])
    elif do == 'drop':
        fp = str(r.get('fp') or '')
        keys = auth_keys(lines)
        hit = [k for k in keys if k['fp'] and k['fp'] == fp]
        if not hit:
            raise Refused('no key %s is there' % fp[:80])
        if len(keys) == len(hit) and r.get('last_ok') is not True:
            raise Refused('that is the last key root signs in with here - said again to take it '
                          'away anyway')
        gone = {k['line'] for k in hit}
        auth_write([ln for i, ln in enumerate(lines) if i not in gone])
    elif do != 'list':
        raise Refused('list, add or drop')
    return {'keys': [dict((k, v) for k, v in x.items() if k != 'line')
                     for x in auth_keys(auth_lines())],
            'file': ROOT_AUTH, 'sshd': sshd_says()}


def sshkeys_part():
    try:
        raw = read_req(SSHKEYS_ASK, 65536)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        # A link or a folder in its place: taken away, never followed.
        drop_entry(SSHKEYS_ASK)
        return
    drop_entry(SSHKEYS_ASK)
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        try:
            r = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise Refused('the request does not read')
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        out['data'] = sshkeys_do(r)
        out['ok'] = True
    except Refused as e:
        out['said'] = str(e)[:400]
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    write_here(SSHKEYS_FILE, json.dumps(out))


# ---- logrotate for the logs nothing rotates, and packing old copies (1.10.310) --
# Asked in logfix.ask from Settings - Disk and logs; answered in logfix.json.
# `cover`: the folders under /var/log/remote that no logrotate file takes go
# into /etc/logrotate.d/remote-isemon - a file of isemon's own, written whole
# HERE from the folder names alone: nothing the page sends is ever written as
# it was sent. A name is one folder straight under the logs' root, a real
# folder and not a link. logrotate is asked about the whole of its
# configuration before and after (`logrotate -d`); anything it says is wrong
# after that it did not say before - two files taking one log, which stops
# every rotation there is - and the file is put back as it was. Then, where
# asked, the folders are rotated once at once (`logrotate -f` of that file
# alone: a rename, quick however big). `pack`: the copies older than three
# days that were never compressed, in the folders named, gzipped - behind,
# at the lowest priority, in a unit of its own where systemd is there.
LOGFIX_ASK = 'logfix.ask'
LOGFIX_FILE = 'logfix.json'
REMOTE_LOGS = os.environ.get('ISEMON_REMOTE_LOGS', '/var/log/remote')
LOGROTATE_D = os.environ.get('ISEMON_LOGROTATE_D', '/etc/logrotate.d')
LOGROTATE_CONF = os.environ.get('ISEMON_LOGROTATE_CONF', '/etc/logrotate.conf')
LOGROTATE = os.environ.get('ISEMON_LOGROTATE', 'logrotate')
LOGFIX_NAME = 'remote-isemon'
LOGFIX_MARK = '# Written by isemon (Settings - Disk and logs).'
LOGFIX_FOLDER_RE = re.compile(r'^[A-Za-z0-9._%@=+-]{1,120}\Z')
LOGFIX_RAW_RE = re.compile(r'(\.\d{1,4}|-\d{8}([-_.]?\d{1,12})?)\Z')
LOGFIX_MOST_FILES = 5000


def logfix_folders(names):
    """The folders asked for, each one checked: one name straight under the
    logs' root, a real folder there - never a link, never a path."""
    if not isinstance(names, list) or not names or len(names) > 200:
        raise Refused('which folders?')
    out = []
    for n in names:
        n = str(n or '')
        if not LOGFIX_FOLDER_RE.match(n) or n in ('.', '..'):
            raise Refused('%s is not the name of a folder of logs' % n[:60])
        path = os.path.join(REMOTE_LOGS, n)
        try:
            st = os.lstat(path)
        except OSError:
            raise Refused('there is no folder %s' % path[:160])
        if not stat.S_ISDIR(st.st_mode):
            raise Refused('%s is not a folder' % path[:160])
        if n not in out:
            out.append(n)
    return out


LOGFIX_TABOO = re.compile(r'(~|\.(rpm\w*|dpkg-\w+|bak|orig|disabled|swp))$')
LOGFIX_PACKED = re.compile(r'\.(gz|xz|bz2|zst|lz4)\Z')


def logfix_confs():
    """Every logrotate file logrotate is run with - the main one, the other
    /etc/logrotate*.conf beside it (a timer of a site's own may run one) and
    everything any of them includes - as {path: text}. Read here, by root,
    rather than taken from the daemon."""
    asked = [LOGROTATE_CONF]
    try:
        top = os.path.dirname(LOGROTATE_CONF) or '/'
        asked += sorted(os.path.join(top, x) for x in os.listdir(top)
                        if re.match(r'^logrotate.*\.conf\Z', x))
    except OSError:
        pass
    asked.append(LOGROTATE_D)
    out, seen = {}, set()
    while asked:
        p = asked.pop(0)
        if p in seen:
            continue
        seen.add(p)
        if os.path.isdir(p):
            try:
                names = sorted(x for x in os.listdir(p)
                               if not x.startswith('.') and not LOGFIX_TABOO.search(x))
            except OSError:
                continue
            asked[:0] = [os.path.join(p, x) for x in names if os.path.isfile(os.path.join(p, x))]
            continue
        try:
            with open(p, encoding='utf-8', errors='replace') as f:
                text = f.read(1048576)
        except OSError:
            continue
        out[p] = text
        asked += re.findall(r'^\s*include\s+(\S+)', text, re.M)
    return out


def logfix_patterns(text):
    """The log patterns of one logrotate file: the words before each brace,
    its scripts skipped."""
    pats, pending, inside, script = [], [], False, False
    for raw in text.splitlines():
        line = raw.strip() if script else raw.split('#', 1)[0].strip()
        if not line:
            continue
        if script:
            if line.split()[0] == 'endscript':
                script = False
            continue
        if line.split()[0] in ('postrotate', 'prerotate', 'firstaction', 'lastaction',
                               'preremove'):
            script = True
            continue
        if not inside:
            if '{' in line:
                pending += line.split('{', 1)[0].split()
                pats += [x.strip('"') for x in pending]
                pending, inside = [], '}' not in line.split('{', 1)[1]
            elif line.startswith('/') or line.startswith('"'):
                pending += line.split()
            continue
        if line.startswith('}'):
            inside = False
    return pats


def logfix_glob(pattern, path):
    """glob(3) as logrotate has it: within one part of the path, and a name
    that begins with a dot only by a pattern that does too."""
    import fnmatch
    pp, fp = pattern.split('/'), path.split('/')
    return len(pp) == len(fp) and all(
        fnmatch.fnmatchcase(f, q) and (not f.startswith('.') or q.startswith('.'))
        for q, f in zip(pp, fp))


def logfix_live(folder):
    """The live logs of one folder: its files that are not copies."""
    out = []
    path = os.path.join(REMOTE_LOGS, folder)
    for name in sorted(os.listdir(path)):
        p = os.path.join(path, name)
        try:
            st = os.lstat(p)
        except OSError:
            continue
        if not stat.S_ISREG(st.st_mode) or LOGFIX_RAW_RE.search(name) or LOGFIX_PACKED.search(name):
            continue
        out.append(p)
    return out


def logfix_takers(paths, confs, skip=None):
    """{file: [the logrotate files that take it]}, isemon's own left out
    where asked."""
    pats = [(f, p) for f, text in confs.items() if f != skip for p in logfix_patterns(text)]
    return {x: sorted(set(f for f, p in pats if logfix_glob(p, x))) for x in paths}


def logfix_check():
    """What logrotate says is wrong with its whole configuration, as a set of
    lines: the errors, and the logs two files take."""
    got = subprocess.run([LOGROTATE, '-d', LOGROTATE_CONF], capture_output=True, text=True,
                         timeout=120)
    said = set()
    for ln in (got.stdout + '\n' + got.stderr).splitlines():
        low = ln.lower()
        if 'error' in low or 'duplicate' in low:
            said.add(re.sub(r'\s+', ' ', ln.strip())[:300])
    return said


def logfix_text(folders, keep):
    lines = ['# /etc/logrotate.d/%s' % LOGFIX_NAME, LOGFIX_MARK,
             '#',
             '# The folders under %s that no other logrotate file took. A file' % REMOTE_LOGS,
             '# of its own, beside the others: logrotate refuses two stanzas that take',
             '# the same log, and refuses the whole run over it. isemon adds to it',
             '# when it is asked to; a line taken away by hand stays away.', '']
    for n in folders:
        lines.append('%s/%s/*.log' % (REMOTE_LOGS, n))
        # `*.log` does not take a name that begins with a dot: each one there
        # named on a line of its own.
        try:
            hidden = sorted(x for x in os.listdir(os.path.join(REMOTE_LOGS, n))
                            if x.startswith('.') and x.endswith('.log')
                            and LOGFIX_FOLDER_RE.match(x)
                            and os.path.isfile(os.path.join(REMOTE_LOGS, n, x)))
        except OSError:
            hidden = []
        lines += ['%s/%s/%s' % (REMOTE_LOGS, n, x) for x in hidden]
    lines += ['{', '    daily', '    dateext', '    rotate %d' % keep, '    compress',
              '    delaycompress', '    missingok', '    notifempty',
              '    create 0640 root %s' % SERVICE_GROUP, '', '    sharedscripts',
              '    postrotate',
              '        /usr/bin/systemctl reload rsyslog > /dev/null 2>&1 || \\',
              '            /usr/bin/systemctl kill -s HUP --kill-who=main rsyslog.service'
              ' > /dev/null 2>&1 || true',
              '    endscript', '}']
    return '\n'.join(lines) + '\n'


def logfix_ours():
    """isemon's own logrotate file as it is: (its text or None, the folders
    in it). One there that isemon did not write is never touched."""
    path = os.path.join(LOGROTATE_D, LOGFIX_NAME)
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return None, []
    if not stat.S_ISREG(st.st_mode):
        raise Refused('%s is not a plain file - not touched' % path)
    with open(path, encoding='utf-8', errors='replace') as f:
        text = f.read(262144)
    if LOGFIX_MARK not in text:
        raise Refused('%s is there and was not written by isemon - not touched' % path)
    pre = re.escape(REMOTE_LOGS.rstrip('/') + '/')
    had = re.findall(r'^%s([A-Za-z0-9._%%@=+-]{1,120})/\*\.log\s*$' % pre, text, re.M)
    return text, had


def logfix_refuse_taken(folders, mine):
    """Root's own look, whatever the daemon said: a folder any other
    logrotate file - in any configuration logrotate is run with - takes a
    live file of, or a name *.log would be, is not put in; nor one with
    anything in it *.log does not take (a folder below, a file named
    otherwise), which stays a step for root by hand."""
    confs = logfix_confs()
    for n in folders:
        base = os.path.join(REMOTE_LOGS, n)
        if any(os.path.isdir(os.path.join(base, x)) for x in os.listdir(base)):
            raise Refused('%s has folders in it: not put in from here' % n)
        live = logfix_live(n)
        odd = [os.path.basename(x) for x in live if not x.endswith('.log')]
        if odd:
            raise Refused('%s has logs not named *.log (%s): not put in from here'
                          % (n, ', '.join(odd[:3])))
        taken = logfix_takers(live + [os.path.join(base, 'isemon-probe.log')], confs, skip=mine)
        who = sorted(set(f for v in taken.values() for f in v))
        if who:
            raise Refused('%s is taken by %s already - two files taking one log stop every '
                          'rotation there is' % (n, ', '.join(who)))


def logfix_verify(folders, mine):
    """After: every live log of the folders taken by isemon's file, and by
    nothing else."""
    confs = logfix_confs()
    bad = []
    for n in folders:
        for x, by in logfix_takers(logfix_live(n), confs).items():
            if by != [mine]:
                bad.append('%s: %s' % (x, ', '.join(by) or 'nothing'))
    return bad


def logfix_write(text):
    path = os.path.join(LOGROTATE_D, LOGFIX_NAME)
    tmp = os.path.join(LOGROTATE_D, '.%s.%d' % (LOGFIX_NAME, os.getpid()))
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    try:
        os.write(fd, text.encode('utf-8'))
        os.fchmod(fd, 0o644)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.rename(tmp, path)


def logfix_gzip(files):
    """gzip these, at the lowest priority: behind, in a unit of its own,
    where systemd is there (True), else here and now (False)."""
    argv = ['gzip', '-6', '--'] + files
    if shutil.which('nice'):
        argv = ['nice', '-n', '19'] + argv
    if shutil.which('systemd-run') and not NO_SERVICES and os.path.isdir('/run/systemd/system'):
        got = subprocess.run(['systemd-run', '--unit', 'isemon-pack-%d' % int(time.time() * 1000),
                              '--collect', '--quiet', '--property', 'IOSchedulingClass=idle',
                              '--property', 'Nice=19'] + argv,
                             capture_output=True, text=True, timeout=30)
        if got.returncode != 0:
            raise Refused('systemd-run: %s' % (got.stderr or got.stdout).strip()[-200:])
        return True
    got = subprocess.run(argv, capture_output=True, text=True, timeout=1500)
    if got.returncode not in (0, 2):
        raise Refused('gzip: %s' % (got.stderr or got.stdout).strip()[-300:])
    return False


def logfix_do(r):
    if ask_stale(r):
        raise Refused('that was asked too long ago - ask again on the page if it is still wanted')
    do = r.get('do')
    if do == 'cover':
        folders = logfix_folders(r.get('folders'))
        try:
            keep = int(r.get('keep') or 30)
        except (TypeError, ValueError):
            keep = 30
        keep = max(1, min(90, keep))
        was, had = logfix_ours()
        mine = os.path.join(LOGROTATE_D, LOGFIX_NAME)
        logfix_refuse_taken([n for n in folders if n not in had], mine)
        want = had + [n for n in folders if n not in had]
        before = logfix_check()
        logfix_write(logfix_text(want, keep))
        after = logfix_check()
        new = sorted(after - before)
        new += ['not taken as it should be: %s' % x for x in logfix_verify(want, mine)][:8]
        if new:
            path = os.path.join(LOGROTATE_D, LOGFIX_NAME)
            if was is None:
                os.unlink(path)
            else:
                logfix_write(was)
            raise Refused('logrotate said this was wrong, so the file was put back as it was: '
                          + ' | '.join(new)[:600])
        out = {'file': os.path.join(LOGROTATE_D, LOGFIX_NAME), 'folders': want,
               'added': [n for n in folders if n not in had], 'keep': keep, 'rotated': False}
        if r.get('rotate_now'):
            got = subprocess.run([LOGROTATE, '-f', os.path.join(LOGROTATE_D, LOGFIX_NAME)],
                                 capture_output=True, text=True, timeout=600)
            out['rotated'] = got.returncode == 0
            out['rotate_said'] = (got.stderr or got.stdout).strip()[-400:]
        return out
    if do == 'pack':
        folders = logfix_folders(r.get('folders'))
        cut = time.time() - 3 * 86400
        files, room = [], 0
        for n in folders:
            for top, dirs, names in os.walk(os.path.join(REMOTE_LOGS, n), followlinks=False):
                for name in names:
                    if not LOGFIX_RAW_RE.search(name):
                        continue
                    p = os.path.join(top, name)
                    try:
                        st = os.lstat(p)
                    except OSError:
                        continue
                    if stat.S_ISREG(st.st_mode) and st.st_mtime < cut and len(files) < LOGFIX_MOST_FILES:
                        files.append(p)
                        room += st.st_size
        if not files:
            return {'files': 0, 'bytes': 0, 'behind': False}
        return {'files': len(files), 'bytes': room, 'behind': logfix_gzip(files)}
    if do == 'age':
        # A folder of logs written a file a day (1.10.311): the copies older
        # than the days asked for let go of, the others older than three
        # days packed. Copies only - a name that ends as logrotate's do -
        # straight in the folder, never through a link.
        folders = logfix_folders(r.get('folders'))
        try:
            keep = int(r.get('keep') or 30)
        except (TypeError, ValueError):
            keep = 30
        if keep < 7 or keep > 3650:
            raise Refused('kept for 7 days at the least')
        now = time.time()
        gone, room, pack = 0, 0, []
        for n in folders:
            base = os.path.join(REMOTE_LOGS, n)
            for name in sorted(os.listdir(base)):
                p = os.path.join(base, name)
                try:
                    st = os.lstat(p)
                except OSError:
                    continue
                if not stat.S_ISREG(st.st_mode):
                    continue
                plain = LOGFIX_PACKED.sub('', name)
                if not LOGFIX_RAW_RE.search(plain):
                    continue
                if st.st_mtime < now - keep * 86400:
                    os.unlink(p)
                    gone += 1
                    room += st.st_size
                elif name == plain and st.st_mtime < now - 3 * 86400 and len(pack) < LOGFIX_MOST_FILES:
                    pack.append(p)
        behind = logfix_gzip(pack) if pack else False
        return {'gone': gone, 'gone_bytes': room, 'packed': len(pack), 'keep': keep,
                'behind': behind}
    if do == 'dayfix':
        return logfix_dayfix(r)
    if do == 'prune':
        return logfix_prune(r)
    raise Refused('cover, pack, age or dayfix')


# ---- A log written a file a day: out of logrotate, aged by a cron of its own
# (1.10.316). logrotate rotates each day's file once and never sees it again:
# its copies are never let go of and never packed. Root takes the folder's
# own line out of the logrotate file that names it - only a line that names
# that folder and nothing else; a pattern for several folders is left as it
# is and refused - checks with logrotate that nothing it did not say before
# is wrong and that no file takes the folder any more, puts it all back if
# not, and writes /etc/cron.daily/isemon-day-logs: every day, in each of its
# folders, the day files and copies older than two days packed and those
# older than the days kept let go of. Written here from the names and the
# numbers alone; run once, behind, at once.
CRON_DAILY = os.environ.get('ISEMON_CRON_DAILY', '/etc/cron.daily')
DAYLOGS_NAME = 'isemon-day-logs'
DAYLOGS_MARK = '# Written by isemon (Settings - Disk and logs): logs written a file a day.'
DAY_NAME_RE = re.compile(r'(19|20)\d\d-?[01]\d-?[0-3]\d')


def daylogs_ours():
    """isemon's cron file as it is: (its text or None, {folder: days})."""
    path = os.path.join(CRON_DAILY, DAYLOGS_NAME)
    try:
        st = os.lstat(path)
    except FileNotFoundError:
        return None, {}
    if not stat.S_ISREG(st.st_mode):
        raise Refused('%s is not a plain file - not touched' % path)
    with open(path, encoding='utf-8', errors='replace') as f:
        text = f.read(262144)
    if DAYLOGS_MARK not in text:
        raise Refused('%s is there and was not written by isemon - not touched' % path)
    got = {}
    inside = False
    for line in text.splitlines():
        if line.strip() == "FOLDERS='":
            inside = True
            continue
        if inside and line.strip() == "'":
            break
        if inside:
            bits = line.split()
            if len(bits) == 2 and LOGFIX_FOLDER_RE.match(bits[0]) and bits[1].isdigit():
                got[bits[0]] = int(bits[1])
    return text, got


def daylogs_text(folders):
    lines = ['#!/bin/sh', '# /etc/cron.daily/%s' % DAYLOGS_NAME, DAYLOGS_MARK, '#',
             '# Folders under %s whose logs are written a file a day (a date in the' % REMOTE_LOGS,
             '# name). logrotate rotates such a file once and never sees it again, so its',
             '# copies were never let go of nor packed; these folders are taken out of',
             '# logrotate and aged here instead, every day: the day files and their copies',
             '# older than two days packed, those older than the days kept let go of. Only',
             '# files with a date in their name, straight in each folder, never a link.',
             '# isemon adds a folder here when asked; a line taken away by hand stays away.',
             '',
             "ROOT='%s'" % REMOTE_LOGS,
             "DAY='.*/[^/]*(19|20)[0-9]{2}-?[01][0-9]-?[0-3][0-9][^/]*'",
             "FOLDERS='"]
    lines += ['%s %d' % (n, k) for n, k in sorted(folders.items())]
    lines += ["'",
              'echo "$FOLDERS" | while read -r name keep; do',
              '    [ -n "$name" ] && [ -n "$keep" ] || continue',
              '    d="$ROOT/$name"',
              '    [ -d "$d" ] && [ ! -L "$d" ] || continue',
              '    find "$d" -maxdepth 1 -type f -regextype posix-extended -regex "$DAY" \\',
              '        -mmin +$((keep * 1440)) -delete 2>/dev/null',
              '    find "$d" -maxdepth 1 -type f -regextype posix-extended -regex "$DAY" \\',
              "        ! -name '*.gz' -mmin +2880 -exec nice -n 19 gzip -6 {} + 2>/dev/null",
              'done',
              'exit 0']
    return '\n'.join(lines) + '\n'


def daylogs_write(text):
    path = os.path.join(CRON_DAILY, DAYLOGS_NAME)
    tmp = os.path.join(CRON_DAILY, '.%s.%d' % (DAYLOGS_NAME, os.getpid()))
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o755)
    try:
        os.write(fd, text.encode('utf-8'))
        os.fchmod(fd, 0o755)
        os.fsync(fd)
    finally:
        os.close(fd)
    os.rename(tmp, path)


def logfix_untake(folder):
    """{file: (before, after)} of the logrotate files with that folder's own
    line taken out - refused where a pattern for several folders takes it,
    or where its line is all its stanza has."""
    confs = logfix_confs()
    probe = os.path.join(REMOTE_LOGS, folder, 'isemon-probe.log')
    live = logfix_live(folder) + [probe]
    own = re.compile(r'^\s*"?%s/\*\.log"?\s*$' % re.escape(os.path.join(REMOTE_LOGS, folder)))
    out = {}
    for f, text in confs.items():
        pats = logfix_patterns(text)
        hits = [p for p in pats if any(logfix_glob(p, x) for x in live)]
        if not hits:
            continue
        if not f.startswith(LOGROTATE_D.rstrip('/') + '/'):
            raise Refused('%s is taken by %s, which is not under %s - not changed from here'
                          % (folder, f, LOGROTATE_D))
        if any(p != os.path.join(REMOTE_LOGS, folder, '*.log') for p in hits):
            raise Refused('%s is taken in %s by a pattern for more than it (%s) - it cannot be '
                          'taken out of that alone; change that file by hand'
                          % (folder, f, ', '.join(p for p in hits
                                                  if p != os.path.join(REMOTE_LOGS, folder,
                                                                       '*.log'))[:120]))
        lines = text.splitlines(True)
        kept = [ln for ln in lines if not own.match(ln.split('#', 1)[0])]
        if len(kept) == len(lines):
            raise Refused('%s names %s on a line with something else - change it by hand'
                          % (f, folder))
        after = ''.join(kept)
        if not logfix_stanzas_have_patterns(after):
            raise Refused('%s is all a stanza of %s has - change that file by hand' % (folder, f))
        out[f] = (text, after)
    return out


def logfix_stanzas_have_patterns(text):
    """Whether every stanza of a logrotate file still names a log."""
    pending, script = 0, False
    for raw in text.splitlines():
        line = raw.strip() if script else raw.split('#', 1)[0].strip()
        if not line:
            continue
        if script:
            if line.split()[0] == 'endscript':
                script = False
            continue
        if line.split()[0] in ('postrotate', 'prerotate', 'firstaction', 'lastaction',
                               'preremove'):
            script = True
            continue
        if '{' in line:
            pending += len(line.split('{', 1)[0].split())
            if not pending:
                return False
            pending = 0
        elif line.startswith('/') or line.startswith('"'):
            pending += len(line.split())
    return True


def logfix_dayfix(r):
    folders = logfix_folders(r.get('folders'))
    try:
        keep = int(r.get('keep') or 30)
    except (TypeError, ValueError):
        keep = 30
    if keep < 7 or keep > 3650:
        raise Refused('kept for 7 days at the least')
    for n in folders:
        if not any(DAY_NAME_RE.search(os.path.basename(x)) for x in logfix_live(n)):
            raise Refused('%s has no log named by the day' % n)
    was_cron, had = daylogs_ours()
    changes = {}
    for n in folders:
        for f, (before, after) in logfix_untake(n).items():
            if f in changes:
                after2 = logfix_untake_text(changes[f][1], n)
                changes[f] = (changes[f][0], after2)
            else:
                changes[f] = (before, after)
    before_check = logfix_check()
    written = []
    try:
        for f, (_b, after) in changes.items():
            logfix_write_file(f, after)
            written.append(f)
        new = sorted(logfix_check() - before_check)
        confs = logfix_confs()
        still = []
        for n in folders:
            for x, by in logfix_takers(logfix_live(n), confs).items():
                if by:
                    still.append('%s: %s' % (x, ', '.join(by)))
        if new or still:
            raise Refused('logrotate said this was wrong, so it was all put back as it was: '
                          + ' | '.join(new + ['still taken - ' + s for s in still[:4]])[:600])
        want = dict(had)
        want.update({n: keep for n in folders})
        daylogs_write(daylogs_text(want))
    except BaseException:
        for f in written:
            logfix_write_file(f, changes[f][0])
        raise
    # ...and once now, behind.
    script = os.path.join(CRON_DAILY, DAYLOGS_NAME)
    behind = False
    if shutil.which('systemd-run') and not NO_SERVICES and os.path.isdir('/run/systemd/system'):
        got = subprocess.run(['systemd-run', '--unit', 'isemon-day-logs-%d' % int(time.time()),
                              '--collect', '--quiet', '--property', 'IOSchedulingClass=idle',
                              '--property', 'Nice=19', '/bin/sh', script],
                             capture_output=True, text=True, timeout=30)
        behind = got.returncode == 0
    if not behind:
        subprocess.run(['/bin/sh', script], capture_output=True, text=True, timeout=1500)
    return {'folders': folders, 'keep': keep, 'out_of': sorted(changes),
            'cron': script, 'behind': behind}


def logfix_untake_text(text, folder):
    own = re.compile(r'^\s*"?%s/\*\.log"?\s*$' % re.escape(os.path.join(REMOTE_LOGS, folder)))
    lines = text.splitlines(True)
    after = ''.join(ln for ln in lines if not own.match(ln.split('#', 1)[0]))
    if not logfix_stanzas_have_patterns(after):
        raise Refused('%s is all a stanza has - change that file by hand' % folder)
    return after


def logfix_write_file(path, text):
    """A logrotate file of the site's own written over, as it is made: beside
    it and renamed, its owner and mode kept."""
    st = os.lstat(path)
    if not stat.S_ISREG(st.st_mode):
        raise Refused('%s is not a plain file' % path)
    folder = os.path.dirname(path)
    tmp = os.path.join(folder, '.%s.isemon.%d' % (os.path.basename(path), os.getpid()))
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        os.write(fd, text.encode('utf-8'))
        os.fchmod(fd, stat.S_IMODE(st.st_mode))
        try:
            os.fchown(fd, st.st_uid, st.st_gid)
        except OSError:
            pass
        os.fsync(fd)
    finally:
        os.close(fd)
    os.rename(tmp, path)


# ---- isemon's own rotation no longer wanted (1.10.317) ------------------------
# What root's helper wrote itself - /etc/logrotate.d/remote-isemon and
# /etc/cron.daily/isemon-day-logs, each with isemon's mark - for a folder that
# is gone from the logs' root, or that another (somebody's own) file takes now:
# that folder's line out of isemon's file, the file away where nothing is
# left. Only those two files, only with the mark; anything somebody made by
# hand is never touched - it is what isemon's own gives way to.
def logfix_prune_plan():
    """(remote-isemon: (text, keep, gone, keep_folders), day-logs: (text, days,
    gone)) as root sees them now."""
    mine = os.path.join(LOGROTATE_D, LOGFIX_NAME)
    # A file of that name without isemon's mark is somebody's own: passed
    # over, never touched, rather than the whole question refused.
    try:
        text, had = logfix_ours()
    except Refused:
        text, had = None, []
    confs = logfix_confs()
    others = {f: t for f, t in confs.items() if f != mine}
    lr_gone, lr_keep = [], []
    for n in had:
        base = os.path.join(REMOTE_LOGS, n)
        if not os.path.isdir(base) or os.path.islink(base):
            lr_gone.append((n, 'gone'))
            continue
        probe = logfix_live(n) + [os.path.join(base, 'isemon-probe.log')]
        by = sorted(set(f for v in logfix_takers(probe, others).values() for f in v))
        if by:
            lr_gone.append((n, 'taken by ' + ', '.join(by)))
        else:
            lr_keep.append(n)
    keep = 30
    if text:
        m = re.search(r'^\s*rotate\s+(\d+)\s*$', text, re.M)
        keep = int(m.group(1)) if m else 30
    try:
        ctext, days = daylogs_ours()
    except Refused:
        ctext, days = None, {}
    dl_gone = []
    for n in sorted(days):
        base = os.path.join(REMOTE_LOGS, n)
        if not os.path.isdir(base) or os.path.islink(base):
            dl_gone.append((n, 'gone'))
            continue
        probe = logfix_live(n) + [os.path.join(base, 'isemon-probe.log')]
        by = sorted(set(f for v in logfix_takers(probe, confs).values() for f in v))
        if by:
            dl_gone.append((n, 'taken by ' + ', '.join(by)))
    return (text, keep, lr_gone, lr_keep), (ctext, days, dl_gone)


def logfix_prune(r):
    (text, keep, lr_gone, lr_keep), (ctext, days, dl_gone) = logfix_prune_plan()
    mine = os.path.join(LOGROTATE_D, LOGFIX_NAME)
    cron = os.path.join(CRON_DAILY, DAYLOGS_NAME)
    done = []
    if lr_gone and text is not None:
        before = logfix_check()
        if lr_keep:
            logfix_write(logfix_text(lr_keep, keep))
        else:
            os.unlink(mine)
        new = sorted(logfix_check() - before)
        if new:
            logfix_write(text)
            raise Refused('logrotate said this was wrong, so %s was put back as it was: %s'
                          % (mine, ' | '.join(new)[:500]))
        done += ['%s: %s (%s)' % (os.path.basename(mine), n, why) for n, why in lr_gone]
    if dl_gone and ctext is not None:
        left = {n: k for n, k in days.items() if n not in dict(dl_gone)}
        if left:
            daylogs_write(daylogs_text(left))
        else:
            os.unlink(cron)
        done += ['%s: %s (%s)' % (DAYLOGS_NAME, n, why) for n, why in dl_gone]
    return {'done': done, 'removed': {'remote-isemon': not lr_keep and bool(lr_gone),
                                      'day-logs': bool(dl_gone) and not
                                      [n for n in days if n not in dict(dl_gone)]}}


def logfix_part():
    try:
        raw = read_req(LOGFIX_ASK, 65536)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        drop_entry(LOGFIX_ASK)
        return
    drop_entry(LOGFIX_ASK)
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        try:
            r = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise Refused('the request does not read')
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        out['data'] = logfix_do(r)
        out['ok'] = True
    except Refused as e:
        out['said'] = str(e)[:700]
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    write_here(LOGFIX_FILE, json.dumps(out))


# ---- this machine's network, its name, and switching it off (1.10.228) -----------
# After otp's otp_web.py. Asked in net.ask: what the network is now (read), a
# new one put in NetworkManager with the host name and /etc/hosts (apply), or
# a reboot or a power-off (power). Going back to the old network after a
# change that was not kept is an apply like any other, of the settings the
# daemon kept from before. Every value checked here again: addresses by
# ipaddress, names by NET_NAME_RE, the connection by the list NetworkManager
# gives. Without NetworkManager nothing is changed: the network is set by hand.
NET_ASK = 'net.ask'
NET_FILE = 'net.json'
NMCLI = os.environ.get('ISEMON_NMCLI', 'nmcli')
HOSTNAMECTL = os.environ.get('ISEMON_HOSTNAMECTL', 'hostnamectl')
HOSTS_FILE = os.environ.get('ISEMON_HOSTS_FILE', '/etc/hosts')
POWER_CMD = os.environ.get('ISEMON_POWER_CMD', '')        # tests: a file to write instead
# The console at login (1.10.230): root's choice, switched from Settings -
# About as `isemon --console-at-login on|off` switches it.
CONSOLE_FLAG = os.environ.get('ISEMON_CONSOLE_FLAG', '/etc/isemon-console-login')
CONSOLE_PROFILE = os.environ.get('ISEMON_CONSOLE_PROFILE', '/etc/profile.d/zz-isemon-console.sh')


def console_set(on):
    """/etc/isemon-console-login written beside it and put in its place: a
    link or a pipe found there is replaced, never followed."""
    tmp = '%s.%d.tmp' % (CONSOLE_FLAG, os.getpid())
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    try:
        os.write(fd, b'on\n' if on else b'off\n')
        os.fchmod(fd, 0o644)
    finally:
        os.close(fd)
    try:
        os.rename(tmp, CONSOLE_FLAG)
    except OSError:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    said = ['the console at login: %s' % ('on' if on else 'off')]
    if not os.path.isfile(CONSOLE_PROFILE):
        said.append('%s is not there - ./install.sh --upgrade puts it in' % CONSOLE_PROFILE)
    return {'said': said, 'on': bool(on)}
IP_CMD = os.environ.get('ISEMON_IP', 'ip')
RESOLV_FILE = os.environ.get('ISEMON_RESOLV', '/etc/resolv.conf')
SYSCTL_IPV6 = os.environ.get('ISEMON_SYSCTL_IPV6', '/etc/sysctl.d/90-isemon-ipv6.conf')
NET_NAME_RE = re.compile(r'^(?=.{1,253}$)([A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)'
                         r'(\.[A-Za-z0-9]([A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*$')
NM_FIELDS = ['ipv4.method', 'ipv4.addresses', 'ipv4.gateway', 'ipv4.dns', 'ipv4.dns-search',
             'ipv6.method', 'ipv6.addresses', 'ipv6.gateway', 'ipv6.dns']
# All that a change sets, read before it and put back as it was when the
# change is not kept (1.10.234).
NM_BEFORE = NM_FIELDS + ['ipv4.ignore-auto-dns', 'ipv6.dns-search', 'ipv6.ignore-auto-dns']
NM_METHODS = {'ipv4.method': ('auto', 'manual', 'disabled', 'link-local', 'shared'),
              'ipv6.method': ('auto', 'dhcp', 'manual', 'ignore', 'disabled', 'link-local',
                              'shared')}


def net_run(cmd, what, ok=(0,)):
    """A program run with its arguments as a list - never a shell - and its
    own last words when it says no."""
    try:
        got = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except FileNotFoundError:
        raise Refused('%s: %s is not on this machine' % (what, cmd[0]))
    except subprocess.TimeoutExpired:
        raise Refused('%s did not answer in a minute' % what)
    if got.returncode not in ok:
        lines = [x.strip() for x in (got.stderr or got.stdout or '').splitlines() if x.strip()]
        raise Refused('%s: %s' % (what, (lines[-1] if lines else 'it said no')[:240]))
    return got.stdout


def net_iface(text):
    """An address with its prefix (192.0.2.10/24) - and nothing else."""
    text = str(text or '').strip()
    if not ADDR_RE.match(text) or '/' not in text:
        raise ValueError('not an address with its prefix')
    return ipaddress.ip_interface(text)


def nm_fields(con, fields):
    out = net_run([NMCLI, '-t', '-g', ','.join(fields), 'connection', 'show', con],
                  'nmcli connection show')
    vals = out.rstrip('\n').split('\n')
    got = {}
    for k, v in zip(fields, vals + [''] * (len(fields) - len(vals))):
        got[k] = v.replace('\\:', ':').strip()
    return got


def nm_list(text):
    return [x.strip() for x in re.split(r'[,\s]+', text or '') if x.strip() and x.strip() != '--']


def net_read():
    """The network as it is: what the kernel has (ip), what NetworkManager is
    told (nmcli), the host name. Nothing is changed for it."""
    out = {'nm': bool(shutil.which(NMCLI)), 'devices': [], 'con': '', 'dev': '', 'conf': {},
           'live': {'addrs4': [], 'addrs6': [], 'gw4': '', 'gw6': '', 'dns': []}}
    try:
        with open('/proc/sys/net/ipv6/conf/all/disable_ipv6') as f:
            out['ipv6_kernel'] = f.read().strip() == '0'
    except OSError:
        out['ipv6_kernel'] = False
    try:
        for line in net_run([IP_CMD, '-o', 'addr', 'show'], 'ip addr').splitlines():
            f = line.split()
            if len(f) < 4 or f[1] == 'lo':
                continue
            try:
                ifc = ipaddress.ip_interface(f[3])
            except ValueError:
                continue
            if ifc.ip.is_loopback or ifc.ip.is_link_local:
                continue
            (out['live']['addrs4'] if ifc.version == 4 else out['live']['addrs6']).append(
                {'addr': str(ifc), 'dev': f[1].split('@')[0]})
        for fam, key in (('-4', 'gw4'), ('-6', 'gw6')):
            r = net_run([IP_CMD, fam, 'route', 'show', 'default'], 'ip route', ok=(0, 1, 2))
            m = re.search(r'default via (\S+) dev (\S+)', r)
            if m:
                out['live'][key] = m.group(1)
                if key == 'gw4':
                    out['dev'] = m.group(2)
    except Refused:
        pass
    try:
        with open(RESOLV_FILE) as f:
            out['live']['dns'] = [l.split()[1] for l in f if l.startswith('nameserver ')
                                  and len(l.split()) > 1][:6]
    except OSError:
        pass
    try:
        out['hostname'] = net_run([HOSTNAMECTL, '--static'], 'hostnamectl').strip() or \
            os.uname().nodename
    except (Refused, OSError):
        out['hostname'] = os.uname().nodename
    if not out['nm']:
        return out
    try:
        for line in net_run([NMCLI, '-t', '-f', 'DEVICE,TYPE,STATE,CONNECTION', 'device'],
                            'nmcli device').splitlines():
            f = line.replace('\\:', '\x00').split(':')
            f = [x.replace('\x00', ':') for x in f]
            if len(f) >= 4 and f[1] in ('ethernet', 'bond', 'vlan', 'bridge', 'team', 'wifi'):
                out['devices'].append({'dev': f[0], 'type': f[1], 'state': f[2], 'con': f[3]})
    except Refused as e:
        out['nm_said'] = str(e)
    dev = out['dev'] or next((d['dev'] for d in out['devices'] if d['con']), '')
    con = next((d['con'] for d in out['devices'] if d['dev'] == dev and d['con']), '')
    out['dev'], out['con'] = dev, con
    if con:
        try:
            g = nm_fields(con, NM_FIELDS)
            out['conf'] = {'ipv4_method': g['ipv4.method'],
                           'ipv4_addresses': nm_list(g['ipv4.addresses']),
                           'ipv4_gateway': g['ipv4.gateway'] if g['ipv4.gateway'] != '--' else '',
                           'ipv4_dns': nm_list(g['ipv4.dns']),
                           'ipv4_search': nm_list(g['ipv4.dns-search']),
                           'ipv6_method': g['ipv6.method'],
                           'ipv6_addresses': nm_list(g['ipv6.addresses']),
                           'ipv6_gateway': g['ipv6.gateway'] if g['ipv6.gateway'] != '--' else '',
                           'ipv6_dns': nm_list(g['ipv6.dns'])}
        except Refused as e:
            out['nm_said'] = str(e)
    return out


def net_checked(r):
    """An apply request, every value in its one shape."""
    out = {'con': str(r.get('con') or ''), 'reboot_in': 0}
    if not out['con'] or len(out['con']) > 120 or any(c in out['con'] for c in '\n\r\x00'):
        raise Refused('which connection?')
    v4 = r.get('ipv4') if isinstance(r.get('ipv4'), dict) else {}
    try:
        a4 = net_iface(v4.get('addr'))
    except ValueError:
        raise Refused('the IPv4 address is an address with its prefix (192.0.2.10/24)')
    if a4.version != 4:
        raise Refused('the IPv4 address is an address with its prefix (192.0.2.10/24)')
    out['addr4'] = str(a4)
    gw = str(v4.get('gw') or '').strip()
    if gw:
        try:
            g = plain(gw, 'address')
        except ValueError:
            raise Refused('the gateway is one IPv4 address')
        if g.version != 4 or g not in a4.network:
            raise Refused('the gateway %s is not in %s' % (g, a4.network))
        out['gw4'] = str(g)
    else:
        out['gw4'] = ''
    v6 = r.get('ipv6') if isinstance(r.get('ipv6'), dict) else {}
    dns = []
    for d in list(v4.get('dns') or [])[:4] + list(v6.get('dns') or [])[:4]:
        try:
            dns.append(str(plain(d, 'address')))
        except ValueError:
            raise Refused('%r is not the address of a DNS server' % str(d)[:60])
    out['dns4'] = [d for d in dns if ':' not in d]
    out['dns6'] = [d for d in dns if ':' in d]
    search = []
    for s_ in list(v4.get('search') or [])[:6]:
        if not NET_NAME_RE.match(str(s_)):
            raise Refused('%r is not a domain' % str(s_)[:60])
        search.append(str(s_))
    out['search'] = search
    mode = str(v6.get('mode') or 'off')
    if mode not in ('off', 'auto', 'manual', 'keep'):
        raise Refused('IPv6 is off, auto, manual or keep')
    out['mode6'] = mode
    if mode == 'manual':
        try:
            a6 = net_iface(v6.get('addr'))
        except ValueError:
            raise Refused('the IPv6 address is an address with its prefix (2001:db8::10/64)')
        if a6.version != 6 or a6.ip.is_link_local:
            raise Refused('the IPv6 address is a global one with its prefix (2001:db8::10/64)')
        out['addr6'] = str(a6)
        g6 = str(v6.get('gw') or '').strip()
        if g6:
            try:
                gg = plain(g6, 'address')
            except ValueError:
                raise Refused('the IPv6 gateway is one IPv6 address')
            if gg.version != 6:
                raise Refused('the IPv6 gateway is one IPv6 address')
            out['gw6'] = str(gg)
        else:
            out['gw6'] = ''
    host = str(r.get('hostname') or '').strip().rstrip('.').lower()
    # Going back, the old name may be one word, as it may have been.
    if host and (not NET_NAME_RE.match(host) or ('.' not in host and r.get('rollback') is not True)):
        raise Refused('the host name is the whole name: isemon.example.cz')
    out['hostname'] = host
    olds = []
    for o in list(r.get('old') or [])[:8]:
        try:
            olds.append(str(plain(o, 'address')))
        except ValueError:
            pass
    out['old'] = olds
    old_host = str(r.get('old_hostname') or '').strip().lower()
    out['old_hostname'] = old_host if NET_NAME_RE.match(old_host or 'x') else ''
    out['exact'] = nm_exact(r.get('exact')) if r.get('exact') else {}
    try:
        out['reboot_in'] = max(0, min(600, int(r.get('reboot_in') or 0)))
    except (TypeError, ValueError):
        out['reboot_in'] = 0
    return out


def nm_exact(e):
    """What NetworkManager had before a change (NM_BEFORE), to be put back
    as it was: each value checked for what it is."""
    if not isinstance(e, dict):
        raise Refused('what is put back is a list of settings')
    out = {}
    for k in NM_BEFORE:
        if k not in e and k not in NM_METHODS:
            continue                    # not read before the change: left as it is
        v = str(e.get(k) if e.get(k) is not None else '').strip()
        if v == '--':
            v = ''
        if len(v) > 600 or any(c in v for c in '\n\r\x00'):
            raise Refused('%s is not one line' % k)
        if k in NM_METHODS:
            if v not in NM_METHODS[k]:
                raise Refused('%s cannot be %r' % (k, v[:40]))
        elif k.endswith('.addresses'):
            try:
                items = [net_iface(x) for x in nm_list(v)]
            except ValueError:
                raise Refused('%s are addresses with their prefix' % k)
            if any(x.version != (4 if k.startswith('ipv4') else 6) for x in items):
                raise Refused('%s are addresses with their prefix' % k)
            v = ','.join(str(x) for x in items)
        elif k.endswith('.gateway') or k.endswith('.dns'):
            try:
                items = [plain(x, 'address') for x in nm_list(v)]
            except ValueError:
                raise Refused('%s is not addresses' % k)
            if k.endswith('.gateway') and len(items) > 1:
                raise Refused('%s is one address' % k)
            v = ','.join(str(x) for x in items)
        elif k.endswith('.dns-search'):
            items = nm_list(v)
            if any(not NET_NAME_RE.match(x) for x in items):
                raise Refused('%s is not domains' % k)
            v = ','.join(items)
        elif k.endswith('.ignore-auto-dns'):
            if v not in ('', 'yes', 'no'):
                raise Refused('%s is yes or no' % k)
        out[k] = v
    return out


def hosts_lines(text, n):
    """/etc/hosts with this machine's old and new names taken out of the lines
    that are this machine's - those at its old or new addresses, those that
    name it in full, those isemon wrote - and its new ones put in. Other names
    on those lines stay; localhost lines, and other machines' lines, as they are."""
    short = n['hostname'].split('.')[0] if n['hostname'] else ''
    full = set(x for x in (n['hostname'], n['old_hostname']) if x)
    drop_names = set(x for x in (n['hostname'], short, n['old_hostname'],
                                 n['old_hostname'].split('.')[0]) if x)
    mine = set(n['old']) | {n['addr4'].split('/')[0]}
    if n.get('addr6'):
        mine.add(n['addr6'].split('/')[0])
    out = []
    for line in text.splitlines():
        body, hash_, note = line.partition('#')
        f = body.split()
        if f and not f[0].startswith(('127.', '::1')):
            if 'written by isemon' in note:
                continue
            if f[0] in mine or any(x.lower() in full for x in f[1:]):
                names = [x for x in f[1:] if x.lower() not in drop_names]
                if not names:
                    continue
                if len(names) != len(f) - 1:
                    line = ' '.join([f[0]] + names) + ((' ' + hash_ + note) if hash_ else '')
        out.append(line)
    if n['hostname']:
        out.append('%s %s %s    # this machine - written by isemon' % (
            n['addr4'].split('/')[0], n['hostname'], short))
        if n.get('addr6'):
            out.append('%s %s %s    # this machine - written by isemon' % (
                n['addr6'].split('/')[0], n['hostname'], short))
    return '\n'.join(out) + '\n'


def power_after(what, secs):
    """A reboot or a power-off a few seconds from now - after this helper
    has written its answer and the page has had it."""
    if what not in ('reboot', 'poweroff'):
        raise Refused('reboot or poweroff')
    secs = max(3, min(600, int(secs or 5)))
    if POWER_CMD:
        with open(POWER_CMD, 'a') as f:
            f.write('%s %d %s\n' % (what, secs, time.time()))
        return '%s in %d s (written to %s)' % (what, secs, POWER_CMD)
    if NO_SERVICES:
        return '%s in %d s (not here: tests)' % (what, secs)
    net_run(['systemd-run', '--on-active=%ds' % secs, '--unit',
             'isemon-%s-%d' % (what, int(time.time())), '/usr/bin/systemctl', what],
            'systemd-run %s' % what)
    return '%s in %d s' % (what, secs)


def net_apply(n):
    if not shutil.which(NMCLI):
        raise Refused('NetworkManager (nmcli) is not on this machine: set the network by hand')
    cons = [l.replace('\\:', ':') for l in net_run([NMCLI, '-t', '-g', 'NAME', 'connection',
                                                    'show'], 'nmcli connection show').splitlines()]
    if n['con'] not in cons:
        raise Refused('there is no connection %r here' % n['con'])
    said = []
    # What NetworkManager had, handed back: kept by the daemon, so that the
    # old network can be asked for again.
    before = nm_fields(n['con'], NM_BEFORE)
    ex = n.get('exact') or {}
    if ex:
        # Going back: every setting the change set, as it was before it.
        args = [NMCLI, 'connection', 'modify', n['con']]
        for k in NM_BEFORE:
            if k in ex:
                args += [k, ex[k]]
    else:
        args = [NMCLI, 'connection', 'modify', n['con'],
                'ipv4.method', 'manual', 'ipv4.addresses', n['addr4'],
                'ipv4.gateway', n['gw4'], 'ipv4.dns', ','.join(n['dns4']),
                'ipv4.dns-search', ','.join(n['search']), 'ipv4.ignore-auto-dns', 'yes']
        if n['mode6'] == 'off':
            args += ['ipv6.method', 'disabled', 'ipv6.addresses', '', 'ipv6.gateway', '',
                     'ipv6.dns', '']
        elif n['mode6'] == 'auto':
            args += ['ipv6.method', 'auto', 'ipv6.addresses', '', 'ipv6.gateway', '',
                     'ipv6.dns', ','.join(n['dns6'])]
        elif n['mode6'] == 'manual':
            args += ['ipv6.method', 'manual', 'ipv6.addresses', n['addr6'],
                     'ipv6.gateway', n['gw6'], 'ipv6.dns', ','.join(n['dns6'])]
    net_run(args, 'nmcli connection modify')
    undo = []
    try:
        return net_apply_rest(n, ex, said, before, undo)
    except BaseException:
        # ...and what it had changed after the profile, too (1.10.306).
        for one in reversed(undo):
            try:
                one()
            except Exception:                       # noqa: BLE001
                pass
        # What comes after the profile went wrong (1.10.305): the profile is
        # put back as it was, or it held the new address with nobody told -
        # to come up at the next boot, on no trial and with no way back.
        back = [NMCLI, 'connection', 'modify', n['con']]
        for k in NM_BEFORE:
            if k in before:
                back += [k, before[k]]
        try:
            net_run(back, 'nmcli connection modify (back)')
        except Exception:                           # noqa: BLE001
            pass
        raise


def net_apply_rest(n, ex, said, before, undo):
    said.append('NetworkManager: %s - %s via %s, DNS %s%s' % (
        n['con'], n['addr4'], n['gw4'] or 'no gateway', ', '.join(n['dns4']) or 'none',
        {'off': ', IPv6 off', 'auto': ', IPv6 automatic',
         'manual': ', IPv6 %s' % n.get('addr6'), 'keep': ''}[n['mode6']]))
    if ex:
        on6 = ex['ipv6.method'] not in ('disabled', 'ignore')
    else:
        on6 = {'off': False, 'auto': True, 'manual': True}.get(n['mode6'])
    if on6:
        # IPv6 switched off in the kernel by an earlier hand: on again.
        write_root(SYSCTL_IPV6, '# written by isemon (isemon_web.py) - Settings, Network\n'
                   'net.ipv6.conf.all.disable_ipv6 = 0\nnet.ipv6.conf.default.'
                   'disable_ipv6 = 0\n', 0o644)
    elif on6 is False:
        # Off again: isemon's own file away, so the kernel is as it was
        # before IPv6 was switched on here.
        try:
            with open(SYSCTL_IPV6) as f:
                ours = f.read(200).startswith('# written by isemon')
        except OSError:
            ours = False
        if ours:
            os.unlink(SYSCTL_IPV6)
    if n['hostname']:
        was_name = socket.gethostname()
        net_run([HOSTNAMECTL, 'set-hostname', n['hostname']], 'hostnamectl set-hostname')
        undo.append(lambda: net_run([HOSTNAMECTL, 'set-hostname', was_name],
                                    'hostnamectl set-hostname (back)'))
        said.append('host name: %s' % n['hostname'])
    try:
        with open(HOSTS_FILE) as f:
            had = f.read()
    except OSError:
        had = '127.0.0.1 localhost localhost.localdomain\n::1 localhost localhost.localdomain\n'
    new = hosts_lines(had, n)
    if new != had:
        # What it was before isemon's first change, kept: a later change - or
        # going back - never writes over it.
        if not os.path.lexists(HOSTS_FILE + '.isemon-before'):
            try:
                write_root(HOSTS_FILE + '.isemon-before', had, 0o644)
            except OSError:
                pass
        write_root(HOSTS_FILE, new, 0o644)
        undo.append(lambda: write_root(HOSTS_FILE, had, 0o644))
        said.append('%s: this machine\'s lines' % HOSTS_FILE)
    if n['reboot_in']:
        said.append(power_after('reboot', n['reboot_in']))
    return {'said': said, 'before': before}


def net_part():
    d = web_fd()
    try:
        raw = read_req(NET_ASK, 65536)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        # A link or a folder in its place: taken away, never followed, so
        # the path unit does not start this again and again.
        try:
            os.unlink(NET_ASK, dir_fd=d)
        except OSError:
            try:
                os.rename(NET_ASK, '.refused-%s-%d' % (NET_ASK, int(time.time())),
                          src_dir_fd=d, dst_dir_fd=d)
            except OSError:
                pass
        return
    try:
        os.unlink(NET_ASK, dir_fd=d)
    except OSError:
        pass
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        r = json.loads(raw.decode('utf-8'))
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        what = r.get('do')
        if what != 'read' and ask_stale(r):
            raise Refused('that was asked too long ago - ask again on the page if it is still '
                          'wanted')
        if what == 'read':
            out['data'] = net_read()
        elif what == 'apply':
            out['data'] = net_apply(net_checked(r))
        elif what == 'power':
            how = r.get('how')
            if how not in ('reboot', 'poweroff'):
                raise Refused('reboot or poweroff')
            try:
                secs = int(r.get('in') or 5)
            except (TypeError, ValueError):
                secs = 5
            out['data'] = {'said': [power_after(how, secs)]}
        elif what == 'console':
            if not isinstance(r.get('on'), bool):
                raise Refused('the console at login is on or off')
            out['data'] = console_set(r['on'])
        else:
            raise Refused('read, apply, power or console')
        out['ok'] = True
    except Refused as e:
        out['said'] = str(e)[:400]
    except Exception as e:                              # noqa: BLE001
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    write_here(NET_FILE, json.dumps(out))


# ---- updates of the operating system (1.10.239; after otp's otp_web.py 1.0.158) ----
# Asked in osup.ask, answered at once in osup.ans: a look for updates (check)
# or the update of every package (upgrade). The work itself - minutes of dnf
# or apt - runs as a unit of its own (systemd-run), so this oneshot service
# ends and the other asks are served meanwhile, one at a time under a lock of
# its own that is never a link. How far it is and its last lines go into
# osup.json, every second or so: the daemon reads them from there, and keeps
# in the database only how it ended. An ask older than a few minutes is not
# done: one left behind is never started later by surprise.
OSUP_ASK = 'osup.ask'
OSUP_ANS = 'osup.ans'
OSUP_FILE = 'osup.json'
OSUP_LOCK = os.environ.get('ISEMON_OSUP_LOCK', '/run/isemon-osup.lock')
OSUP_PM = os.environ.get('ISEMON_OSUP_PM', '')      # tests: a fake package manager
OSUP_ASK_LIVE_S = 300
# The proxy dnf and apt go through (1.10.268; otp 1.0.166, Settings → Proxy):
# handed over in osup.ask, kept here for the work, root's alone (0600), read
# by the work into its own environment - never on a command line - and
# taken away when the work is over.
OSUP_PROXY = os.environ.get('ISEMON_OSUP_PROXY', '/run/isemon-osup-proxy.json')


def osup_proxy_checked(r):
    """The proxy of an ask: ('', '') for none; refused unless http(s)://."""
    url = str(r.get('proxy') or '').strip()
    if url and (not re.match(r'^https?://[^\s/]+/?\Z', url) or any(
            c in url for c in '"\'\\`$;<>|&')):
        raise Refused('the proxy is not an http:// address')
    no = ','.join(w for w in re.split(r'[\s,;]+', re.sub(r'[^A-Za-z0-9.*:/\[\],;\s_-]', '',
                                                          str(r.get('proxy_no') or ''))) if w)
    return url, no[:2000]


def osup_proxy_drop():
    try:
        os.unlink(OSUP_PROXY)
    except FileNotFoundError:
        pass
    except OSError:
        pass


def osup_proxy_keep(url, no):
    """Written for the work about to start, or taken away when there is none."""
    if not url:
        osup_proxy_drop()
        return
    fd = os.open(OSUP_PROXY + '.new', os.O_WRONLY | os.O_CREAT | os.O_TRUNC | os.O_NOFOLLOW,
                 0o600)
    with os.fdopen(fd, 'w') as f:
        os.fchmod(f.fileno(), 0o600)
        f.write(json.dumps({'url': url, 'no': no}))
    os.replace(OSUP_PROXY + '.new', OSUP_PROXY)


def osup_proxy_env(env):
    """The work's own environment given the proxy, as dnf and apt read it."""
    try:
        st = os.lstat(OSUP_PROXY)
        if not stat.S_ISREG(st.st_mode) or st.st_uid != os.getuid():
            return env
        with open(OSUP_PROXY) as f:
            got = json.loads(f.read(8192) or '{}')
    except (OSError, ValueError):
        return env
    if isinstance(got, dict) and got.get('url'):
        for k in ('http_proxy', 'https_proxy', 'HTTP_PROXY', 'HTTPS_PROXY'):
            env[k] = str(got['url'])
        if got.get('no'):
            env['no_proxy'] = env['NO_PROXY'] = str(got['no'])
    return env


def osup_pm():
    if OSUP_PM:
        return 'fake'
    if shutil.which('dnf'):
        return 'dnf'
    if shutil.which('apt-get'):
        return 'apt'
    return ''


def osup_lock_fd():
    """The lock file, opened without following a link - and only a file."""
    fd = os.open(OSUP_LOCK, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    if not stat.S_ISREG(os.fstat(fd).st_mode):
        os.close(fd)
        raise Refused('%s is not a file' % OSUP_LOCK)
    return fd


def osup_running():
    import fcntl
    try:
        fd = osup_lock_fd()
    except (OSError, Refused):
        return True                     # a link or a folder there: nothing is started
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(fd, fcntl.LOCK_UN)
        return False
    except OSError:
        return True
    finally:
        os.close(fd)


def osup_launch(ident, kind, security=False, proxy=('', '')):
    if not ident:
        raise Refused('the ask has no id')
    if osup_running():
        raise Refused('an update or a look for updates is going on already')
    if not osup_pm():
        raise Refused('neither dnf nor apt-get is on this machine')
    # The proxy for this work alone (1.10.268): kept only once nothing else
    # runs, so a work going on keeps the one it began with.
    osup_proxy_keep(*proxy)
    try:
        _osup_start(ident, kind, security)
    except BaseException:
        osup_proxy_drop()
        raise


def _osup_start(ident, kind, security):
    me = os.path.abspath(__file__)
    argv = [sys.executable, '-I', me, '--os-job', ident, kind] + (['security'] if security else [])
    if shutil.which('systemd-run') and not NO_SERVICES and os.path.isdir('/run/systemd/system'):
        got = subprocess.run(['systemd-run', '--unit', 'isemon-os-%s-%s' % (kind, ident[:12]),
                              '--collect', '--quiet', '--property', 'TimeoutStopSec=30min'] + argv,
                             capture_output=True, text=True, timeout=30)
        if got.returncode != 0:
            raise Refused('systemd-run: %s' % (got.stderr or got.stdout).strip()[-200:])
        return
    subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, start_new_session=True, close_fds=True)


def osup_part():
    try:
        raw = read_req(OSUP_ASK, 4096)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        drop_entry(OSUP_ASK)            # a link or a folder in its place: never followed
        return
    drop_entry(OSUP_ASK)
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        try:
            r = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise Refused('the request does not read')
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        kind = r.get('kind')
        if r.get('do') != 'run' or kind not in ('check', 'upgrade'):
            raise Refused('run: check or upgrade')
        try:
            asked = float(r.get('at'))
        except (TypeError, ValueError):
            raise Refused('the ask does not say when it was made')
        if not abs(time.time() - asked) < OSUP_ASK_LIVE_S:
            raise Refused('an old ask, not done: ask again')
        if r.get('security') not in (None, True, False, 0, 1):
            raise Refused('security: true or false')
        # Only the security updates (1.10.257, after otp 1.0.164): an upgrade only.
        security = bool(r.get('security')) and kind == 'upgrade'
        osup_launch(out['id'], kind, security, osup_proxy_checked(r))
        out['ok'] = True
        out['data'] = {'started': kind, 'pm': osup_pm(), 'security': security}
    except Refused as e:
        out['said'] = str(e)[:400]
    except Exception as e:                              # noqa: BLE001
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    write_here(OSUP_ANS, json.dumps(out))


# The packages a restart is needed for once they are updated, as dnf
# needs-restarting -r and Debian's reboot-required name them (otp 1.0.159).
REBOOT_PKGS = {'kernel', 'kernel-core', 'kernel-rt', 'kernel-rt-core', 'kernel-modules',
               'kernel-uek', 'glibc', 'linux-firmware', 'systemd', 'dbus', 'dbus-broker',
               'dbus-daemon', 'microcode_ctl', 'zlib', 'zlib-ng-compat', 'libc6', 'linux-base',
               'intel-microcode', 'amd64-microcode'}


def reboot_for(packages):
    """Which of the packages waiting want a restart once updated."""
    out = []
    for p in packages:
        name = str(p).split()[0] if str(p).split() else ''
        if re.search(r'\.(x86_64|aarch64|noarch|i686|ppc64le|s390x)$', name):
            name = name.rsplit('.', 1)[0]
        if name in REBOOT_PKGS or name.startswith(('linux-image', 'kernel-core-', 'linux-modules')):
            out.append(name)
    return sorted(set(out))


def reboot_now(pm, env, say=None):
    """Whether this machine waits for a restart already."""
    if pm == 'fake':
        return subprocess.run([OSUP_PM, 'needs-restart'], stdout=subprocess.DEVNULL,
                              timeout=300).returncode == 1
    if pm == 'dnf':
        nr = subprocess.run(['dnf', 'needs-restarting', '-r'], capture_output=True,
                            text=True, env=env, timeout=300)
        # 1 is also what dnf says for a command it does not have (no
        # dnf-plugins-core): a restart only when it says so in words.
        need = nr.returncode == 1 and 'reboot' in (nr.stdout or '').lower()
        if need and say:
            say(nr.stdout.strip().splitlines()[0])
        return need
    return os.path.exists('/var/run/reboot-required')


def osup_job(ident, kind, security=False):
    """The work itself, as root, in a process of its own."""
    import fcntl
    try:
        fd = osup_lock_fd()
    except (OSError, Refused):
        osup_proxy_drop()
        return 1
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(fd)
        return 1
    state = {'id': ident, 'kind': kind, 'state': 'running', 'pct': 1, 'lines': [],
             'began': time.time(), 'at': time.time(), 'packages': [], 'reboot': False,
             'pm': osup_pm(), 'phase': 'starting'}
    last = [0.0]

    def put(force=False):
        state['at'] = time.time()
        if force or time.time() - last[0] > 0.8:
            last[0] = time.time()
            state['lines'] = state['lines'][-400:]
            write_here(OSUP_FILE, json.dumps(state))

    def say(line):
        line = line.rstrip()
        if line:
            state['lines'].append(line[:300])
        put()

    env = {'PATH': '/usr/sbin:/usr/bin:/sbin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
           'DEBIAN_FRONTEND': 'noninteractive', 'HOME': '/root'}
    # Settings → Proxy (1.10.268): read once, then the file is gone - the
    # address with who signs in lives on only in this work's environment
    # (root's alone to read, /proc/PID/environ).
    osup_proxy_env(env)
    osup_proxy_drop()
    if env.get('https_proxy'):
        state['proxy'] = True

    def stream(cmd, on_line=None, ok=(0,)):
        say('$ ' + ' '.join(cmd))
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=env,
                             stdin=subprocess.DEVNULL, text=True, bufsize=1, errors='replace')
        for ln in p.stdout:
            say(ln)
            if on_line:
                on_line(ln)
        rc = p.wait()
        if rc not in ok:
            raise Refused('%s ended with %d' % (os.path.basename(cmd[0]), rc))
        return rc

    pm = state['pm']
    try:
        put(True)
        if kind == 'check':
            state['phase'] = 'asking for what is new'
            pk = []
            if pm == 'fake':
                stream([OSUP_PM, 'check'], lambda ln: pk.append(ln.strip())
                       if ln.strip() and not ln.startswith('#') else None)
                state['security'] = len([p for p in pk if p.endswith(' security')])
                pk = [p[:-len(' security')] if p.endswith(' security') else p for p in pk]
            elif pm == 'dnf':
                rc_out = []
                stream(['dnf', '-q', '--refresh', 'check-update'], rc_out.append, ok=(0, 100))
                for ln in rc_out:
                    parts = ln.split()
                    if len(parts) >= 3 and '.' in parts[0] and not ln.startswith(' '):
                        pk.append('%s %s' % (parts[0], parts[1]))
                state['security'] = 0
                sec = subprocess.run(['dnf', '-q', 'updateinfo', 'list', '--security'],
                                     capture_output=True, text=True, env=env, timeout=300)
                state['security'] = len([x for x in sec.stdout.splitlines() if x.strip()])
            else:
                stream(['apt-get', 'update'])
                got = subprocess.run(['apt', 'list', '--upgradable'], capture_output=True,
                                     text=True, env=env, timeout=300)
                for ln in got.stdout.splitlines():
                    if '/' in ln and '[upgradable' in ln:
                        name = ln.split('/', 1)[0]
                        ver = ln.split()[1] if len(ln.split()) > 1 else ''
                        pk.append('%s %s' % (name, ver))
            state['packages'] = pk[:1000]
            state['count'] = len(pk)
            # Whether the update will need a restart, told before it is made.
            state['phase'] = 'whether a restart is needed'
            state['reboot_why'] = reboot_for(pk)
            state['reboot_after'] = bool(state['reboot_why'])
            try:
                state['reboot_now'] = reboot_now(pm, env)
            except (OSError, subprocess.SubprocessError):
                state['reboot_now'] = False
            if state['reboot_now']:
                say('a restart is needed already, before any update')
            if state['reboot_why']:
                say('a restart will be needed after the update: %s'
                    % ', '.join(state['reboot_why']))
            state['pct'] = 100
        else:
            seen = {'total': 0, 'done': 0}

            def count(ln):
                m = re.search(r'\b(\d+)/(\d+)\s*$', ln)
                if pm in ('dnf', 'fake') and m and re.search(
                        r'(Upgrading|Installing|Cleanup|Verifying|Running scriptlet|Erasing|'
                        r'Reinstalling|Downgrading|Obsoleting)\s*:', ln):
                    total = int(m.group(2)) * 2          # each one upgraded and then verified
                    seen['total'] = max(seen['total'], total)
                    seen['done'] = min(seen['total'], seen['done'] + 1)
                    state['phase'] = 'putting the packages in'
                if pm in ('dnf', 'fake') and ln.startswith('Downloading Packages'):
                    state['phase'] = 'downloading'
                    state['pct'] = max(state['pct'], 8)
                if pm == 'apt':
                    m2 = re.match(r'^(\d+) upgraded, (\d+) newly installed', ln)
                    if m2:
                        seen['total'] = (int(m2.group(1)) + int(m2.group(2))) * 2
                    if ln.startswith(('Unpacking ', 'Setting up ')):
                        seen['done'] += 1
                        state['phase'] = 'putting the packages in'
                    if ln.startswith('Get:'):
                        state['phase'] = 'downloading'
                        state['pct'] = max(state['pct'], 8)
                if seen['total']:
                    state['pct'] = max(state['pct'], min(97, 10 + int(87 * seen['done'] /
                                                                      seen['total'])))
            state['phase'] = 'asking for what is new'
            # Only the security updates where asked (1.10.257, after otp
            # 1.0.164): dnf's own --security, unattended-upgrade on apt (it
            # takes the security sources only, as Debian and Ubuntu set it up).
            state['security_only'] = bool(security)
            if pm == 'fake':
                stream([OSUP_PM, 'upgrade'] + (['security'] if security else []), count)
            elif pm == 'dnf':
                stream(['dnf', '-y', '--refresh', 'upgrade'] + (['--security'] if security else []),
                       count)
            elif security:
                if not shutil.which('unattended-upgrade'):
                    raise Refused('only the security updates: unattended-upgrade is not on this '
                                  'machine (apt install unattended-upgrades)')
                stream(['apt-get', 'update'])
                state['pct'] = max(state['pct'], 5)
                stream(['unattended-upgrade', '-v'], count)
            else:
                stream(['apt-get', 'update'])
                state['pct'] = max(state['pct'], 5)
                stream(['apt-get', '-y', '-o', 'Dpkg::Options::=--force-confdef', '-o',
                        'Dpkg::Options::=--force-confold', 'upgrade'], count)
            state['phase'] = 'whether a restart is needed'
            state['reboot'] = reboot_now(pm, env, say)
            state['pct'] = 100
        state['state'] = 'done'
        state['phase'] = 'done'
    except Refused as e:
        state.update(state='failed', said=str(e)[:300])
    except Exception as e:                              # noqa: BLE001
        state.update(state='failed', said='it broke: %s' % str(e)[:300])
    finally:
        try:
            put(True)
        finally:
            os.close(fd)
    return 0


# ---- the otp logs over TLS (1.10.245; for otp's Settings → isemon → Encrypted sending) ----
# Asked in otptls.ask: how it is (read), the receiver put in with a
# certificate given (apply: ca, cert, key - from the file otp made, or
# pasted), one made here by an authority of this machine's own (make), the
# nodes or the port changed with the certificate as it is (set), or taken
# away (off); answered in otptls.json. What is written is root's alone:
# /etc/pki/rsyslog/otp/ (0750; the keys 0600) and one rsyslog file,
# /etc/rsyslog.d/10-otp-tls.conf, written here whole - never a file taken
# from otp's zip as it is: the nodes' names and the mode are read from it on
# the daemon's side and checked again here. rsyslog is asked (rsyslogd -N1)
# before it is restarted, and every file is put back as it was when it says
# no or does not listen after. The plain input on 514 is never touched: a
# node not switched over yet goes on sending there.
OTPTLS_ASK = 'otptls.ask'
OTPTLS_FILE = 'otptls.json'
# 99-: read after every file that loads imtcp (1.10.246). rsyslog reads
# rsyslog.d in order, and an input of a module not loaded yet is refused
# ("input module name 'imtcp' is unknown", and every TLS parameter "not
# known") - 10-otp-tls.conf, the name otp's README gives it, came before the
# 10-remote-logs.conf of a site that loads imtcp there. One by that name -
# isemon 1.10.245's, or one put in by hand - is taken away when this one is
# written: two inputs on one port and rsyslog refuses both.
OTPTLS_CONF = os.environ.get('ISEMON_OTPTLS_CONF', '/etc/rsyslog.d/99-otp-tls.conf')
OTPTLS_OLD = os.environ.get('ISEMON_OTPTLS_OLD', '/etc/rsyslog.d/10-otp-tls.conf')
OTPTLS_DIR = os.environ.get('ISEMON_OTPTLS_DIR', '/etc/pki/rsyslog/otp')
RSYSLOGD = os.environ.get('ISEMON_RSYSLOGD', 'rsyslogd')
RSYSLOG_MODDIRS = os.environ.get('ISEMON_RSYSLOG_MODDIR', '/usr/lib64/rsyslog:/usr/lib/rsyslog:'
                                 '/usr/lib/x86_64-linux-gnu/rsyslog:/usr/lib/aarch64-linux-gnu/rsyslog')
OTPTLS_MARK = '# isemon: the otp logs over TLS'
OTPTLS_FRESH_S = 600
OTPTLS_NAME_RE = re.compile(r'^(?=.{1,253}\Z)(\*\.)?[A-Za-z0-9]([A-Za-z0-9_-]{0,62})'
                            r'(\.[A-Za-z0-9]([A-Za-z0-9_-]{0,62}))*\.?\Z')
OTPTLS_DRIVERS = {'gtls': ('lmnsd_gtls.so', 'rsyslog-gnutls'),
                  'ossl': ('lmnsd_ossl.so', 'rsyslog-openssl')}
# The words of the files written, the otp logs' (as they always were) - and,
# while acmetls_part runs, the acme logs' (1.10.287): the same receiver for
# acme's nodes, with a file, a folder and a port of its own.
TLS_P = {'who': 'otp', 'pane': 'The OTP logs', 'input': 'otp-tls', 'ca_cn': 'the otp logs',
         'filed': ['# What arrives here is filed by the same rule as what arrives plain',
                   '# (11-otp.conf): /var/log/remote/<host>/totp.cgi.log and radius-detail.log.']}
# acme's: read after otp's (99-tls- after 99-otp-), so that whichever of the
# two loads imtcp, the one read first does (`tls_loads_fix`).
ACMETLS_CONF = os.environ.get('ISEMON_ACMETLS_CONF', os.path.join(
    os.path.dirname(OTPTLS_CONF), '99-tls-acme.conf'))
ACMETLS_OLD = os.environ.get('ISEMON_ACMETLS_OLD', os.path.join(
    os.path.dirname(OTPTLS_OLD), '10-acme-tls.conf'))
ACMETLS_DIR = os.environ.get('ISEMON_ACMETLS_DIR', os.path.join(
    os.path.dirname(OTPTLS_DIR), 'acme'))
ACMETLS_P = {'who': 'acme', 'pane': 'The acme logs', 'input': 'acme-tls',
             'ca_cn': 'the acme logs',
             'filed': ['# What arrives here is filed by the same rule as what arrives plain',
                       '# (11-acme.conf): /var/log/remote/<HOST>/acme-certs.log, acme.log and',
                       '# acme-jobs.log.']}
TLS_SIBLINGS = []          # the other receiver's file, while acme's is the one asked


def otptls_path(name):
    return os.path.join(OTPTLS_DIR, name)


def tls_siblings():
    """The other receiver's file: acme's while otp's is asked, otp's while
    acme's is (1.10.287)."""
    return TLS_SIBLINGS or [ACMETLS_CONF]


IMTCP_LOAD = 'module(load="imtcp")'


def rsyslog_check():
    """rsyslogd -N1 on what is written: refused - and put back - when it says no."""
    if NO_SERVICES and not os.environ.get('ISEMON_RSYSLOGD'):
        return
    chk = subprocess.run([RSYSLOGD, '-N1'], capture_output=True, text=True, timeout=120)
    if chk.returncode != 0:
        bad = [l for l in (chk.stderr + chk.stdout).splitlines()
               if re.search(r'error|warn', l, re.I)][:3]
        raise Refused('rsyslog does not take it, so nothing was changed: %s' % (
            ' | '.join(bad) or 'rsyslogd -N1 says why'))


TLS_MARKS = ('# isemon: the otp logs over TLS', '# isemon: the acme logs over TLS')


def tls_loads_fix(said):
    """otp's receiver and acme's, both isemon's files: imtcp loaded by the
    one rsyslog reads first, and by neither where another file of rsyslog's
    loads it - rsyslog refuses a module loaded twice, and an input before its
    module. Nothing is done while the one just written is the only one
    there: it was written right. The other one, left alone by this one taken
    away, may have to load it now (1.10.287)."""
    files = [f for f in [OTPTLS_CONF] + tls_siblings() if os.path.isfile(f)]
    if not files or files == [OTPTLS_CONF]:
        return False
    changed = False
    files.sort(key=lambda f: os.path.basename(f))
    real = tuple(os.path.realpath(f) for f in files)
    outside = False
    for path in rsyslog_conf_files():
        if os.path.realpath(path) in real:
            continue
        text = rsyslog_text(path)
        if re.search(r'module\s*\(\s*load\s*=\s*"imtcp"', text) or \
                re.search(r'(?m)^\s*\$ModLoad\s+imtcp\b', text):
            outside = True
    for i, path in enumerate(files):
        with open(path, encoding='utf-8', errors='replace') as f:
            text = f.read(65536)
        # isemon's by its own mark at the start of a line of its head, not by
        # the words anywhere in it (1.10.294).
        if not any(l.startswith(TLS_MARKS) for l in text.split('\n')[:4]):
            continue                    # not isemon's: never written over
        lines = text.split('\n')
        has = IMTCP_LOAD in lines
        want = not outside and i == 0
        if has == want:
            continue
        if want:
            at = next((n for n, l in enumerate(lines) if l.startswith('input(')), len(lines))
            lines.insert(at, IMTCP_LOAD)
        else:
            lines = [l for l in lines if l != IMTCP_LOAD]
        write_root(path, '\n'.join(lines), 0o644)
        changed = True
        said.append('%s %s imtcp' % (path, 'loads' if want else 'no longer loads'))
    return changed


def rsyslog_conf_files():
    files = []
    for one in RSYSLOG_FILES.split(':'):
        if os.path.isdir(one):
            files += sorted(os.path.join(one, n) for n in os.listdir(one) if n.endswith('.conf'))
        elif os.path.isfile(one):
            files.append(one)
    return files


def rsyslog_text(path):
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            text = f.read(1 << 20)
    except OSError:
        return ''
    return '\n'.join(l for l in text.split('\n') if not l.strip().startswith('#'))


def otptls_others():
    """What the rest of rsyslog's files already say: whether imtcp is loaded,
    whether the default TLS files are set, and the ports listened on."""
    mine = (os.path.realpath(OTPTLS_CONF), os.path.realpath(OTPTLS_OLD))
    # The other receiver of isemon's (1.10.287) loads imtcp or not as
    # `tls_loads_fix` says: never a reason for this one not to.
    sibling = tuple(os.path.realpath(x) for x in tls_siblings())
    out = {'imtcp': [], 'global': [], 'ports': []}
    for path in rsyslog_conf_files():
        if os.path.realpath(path) in mine:
            continue
        text = rsyslog_text(path)
        if (re.search(r'module\s*\(\s*load\s*=\s*"imtcp"', text) or
                re.search(r'(?m)^\s*\$ModLoad\s+imtcp\b', text)) and \
                os.path.realpath(path) not in sibling:
            out['imtcp'].append(path)
        if re.search(r'DefaultNetstreamDriver(CAFile|CertFile|KeyFile)', text):
            out['global'].append(path)
    for p in rsyslog_ports():
        if os.path.realpath(os.path.join(os.path.dirname(OTPTLS_CONF), p['file'])) not in mine:
            out['ports'].append(p)
    return out


def rsyslog_version():
    """(8, 2310) of `rsyslogd -v`, or None."""
    try:
        got = subprocess.run([RSYSLOGD, '-v'], capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.TimeoutExpired):
        return None
    m = re.search(r'rsyslogd\s+(\d+)\.(\d+)', got.stdout or '')
    return (int(m.group(1)), int(m.group(2))) if m else None


def otptls_driver():
    """The stream driver there is here: gtls (rsyslog-gnutls, what otp's
    README names) or ossl (rsyslog-openssl, which install.sh puts in)."""
    dirs = [d for d in RSYSLOG_MODDIRS.split(':') if d]
    for name, (lib, _) in OTPTLS_DRIVERS.items():
        if any(os.path.exists(os.path.join(d, lib)) for d in dirs):
            return name
    return ''


def otptls_driver_get(said):
    got = otptls_driver()
    if got or NO_SERVICES:
        return got or 'gtls'
    for pm, args in (('dnf', ['install', '-y']), ('apt-get', ['install', '-y'])):
        if shutil.which(pm):
            try:
                r = subprocess.run([pm] + args + ['rsyslog-gnutls'],
                                   capture_output=True, text=True, timeout=600)
            except (OSError, subprocess.TimeoutExpired):
                break
            if r.returncode == 0:
                said.append('rsyslog-gnutls installed')
            break
    got = otptls_driver()
    if not got:
        raise Refused('rsyslog has no TLS driver here: install rsyslog-gnutls (or '
                      'rsyslog-openssl) and try again')
    return got


def otptls_names(text, what, most=64):
    names = [n.strip().rstrip('.') for n in re.split(r'[\s,;]+', str(text or '')) if n.strip()]
    if len(names) > most:
        raise Refused('%s: %d at most' % (what, most))
    for n in names:
        try:
            plain(n, 'address')
            continue
        except ValueError:
            pass
        if not OTPTLS_NAME_RE.match(n):
            raise Refused('%s: %r is not a name' % (what, n[:80]))
    return list(dict.fromkeys(names))


def otptls_port(v):
    try:
        port = int(v or 6514)
    except (TypeError, ValueError):
        raise Refused('the port is a number')
    if not 1 <= port <= 65535 or port == 514:
        raise Refused('the port is 1 to 65535, and not 514 - that one is the plain logs\'')
    return port


def cert_facts(pem):
    """What a certificate says of itself."""
    out = openssl(['x509', '-noout', '-nameopt', 'RFC2253', '-subject', '-issuer', '-enddate',
                   '-startdate', '-fingerprint', '-sha256', '-ext', 'subjectAltName'],
                  'the certificate', pem)
    f = {'subject': '', 'issuer': '', 'until': '', 'from': '', 'fp': '', 'names': []}
    for line in out.splitlines():
        line = line.strip()
        for key, word in (('subject', 'subject='), ('issuer', 'issuer='), ('until', 'notAfter='),
                          ('from', 'notBefore='), ('fp', 'sha256 Fingerprint=')):
            if line.startswith(word):
                f[key] = line[len(word):].strip()
        if line.startswith(('DNS:', 'IP Address:', 'IP:')):
            f['names'] += [x.strip().split(':', 1)[1] for x in line.split(',') if ':' in x]
    try:
        import calendar
        f['until_t'] = calendar.timegm(time.strptime(f['until'].replace(' GMT', ''),
                                                     '%b %d %H:%M:%S %Y'))
    except ValueError:
        f['until_t'] = 0
    cn = re.search(r'(?:^|,)CN=([^,]+)', f['subject'])
    if cn and cn.group(1) not in f['names']:
        f['cn'] = cn.group(1)
    return f


def pem_certs(text):
    return [m.group(0) + '\n' for m in re.finditer(
        r'-----BEGIN CERTIFICATE-----[A-Za-z0-9+/=\s]+?-----END CERTIFICATE-----', text or '')]


def otptls_state():
    try:
        with open(otptls_path('.isemon.json')) as f:
            got = json.load(f)
        return got if isinstance(got, dict) else {}
    except (OSError, ValueError):
        return {}


def otptls_conf_now(path=None):
    """The file there now: whether it is isemon's, and what it says - the
    one by the old name when the new one is not there."""
    if path is None:
        got = otptls_conf_now(OTPTLS_CONF)
        if not got.get('there') and os.path.lexists(OTPTLS_OLD):
            got = dict(otptls_conf_now(OTPTLS_OLD), old=OTPTLS_OLD)
        return got
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            text = f.read(65536)
    except FileNotFoundError:
        return {'there': False}
    except OSError as e:
        return {'there': True, 'said': str(e)[:200]}
    body = '\n'.join(l for l in text.split('\n') if not l.strip().startswith('#'))
    port = re.search(r'port\s*=\s*"([0-9]{1,5})"', body)
    auth = re.search(r'AuthMode\s*=\s*"([a-z0-9/]+)"', body, re.I)
    drv = re.search(r'StreamDriver\.Name\s*=\s*"([a-z]+)"', body, re.I)
    peers = re.search(r'PermittedPeer\s*=\s*\[([^\]]*)\]', body, re.I) or \
        re.search(r'PermittedPeer\s*=\s*"([^"]*)"', body, re.I)
    return {'there': True, 'mine': OTPTLS_MARK in text,
            'port': int(port.group(1)) if port else 0,
            'auth': auth.group(1) if auth else '', 'driver': drv.group(1) if drv else '',
            'peers': re.findall(r'"([^"]+)"', peers.group(0)) if peers else []}


def listening(port):
    if NO_SERVICES or not shutil.which('ss'):
        return None
    got = subprocess.run(['ss', '-Hltnp', 'sport = :%d' % port], capture_output=True, text=True)
    return bool(got.stdout.strip()) if got.returncode == 0 else None


def port_holders(port):
    """The programs that listen on a TCP port here, by name (`ss -p`) - None
    where that cannot be known (1.10.294)."""
    if NO_SERVICES or not shutil.which('ss'):
        return None
    got = subprocess.run(['ss', '-Hltnp', 'sport = :%d' % port], capture_output=True, text=True)
    if got.returncode != 0:
        return None
    return sorted(set(re.findall(r'\(\("([^"]+)"', got.stdout))) or \
        (['something'] if got.stdout.strip() else [])


TLS_WORDS = r'gtls|gnutls|ossl|openssl|tls|certificate|permitted|peer|netstream|imtcp|6514'
TLS_BAD = (r'error|fail|not permitted|unknown ca|untrusted|expired|not yet valid|denied|refus|'
           r'could not|cannot|invalid|unable|abort|alert|bad |mismatch')
# A node that hangs up without a goodbye - otp's "Try it", a node restarted -
# is said by GnuTLS as an error -110 and the session closed: no trouble.
TLS_BENIGN = (r'error -110|broken connection|premature termination|non-properly terminated|'
              r'will be closed due to error')


def rsyslog_since():
    """When rsyslog was started last, as seconds since 1970 - or None."""
    try:
        got = subprocess.run(['systemctl', 'show', 'rsyslog', '-p', 'ActiveEnterTimestamp',
                              '--timestamp=unix', '--value'], capture_output=True, text=True,
                             timeout=20)
        m = re.match(r'^@(\d+)', got.stdout.strip())
        return int(m.group(1)) if m else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def rsyslog_trouble(minutes=30, problems=True):
    """What rsyslog said about TLS that went wrong - since it was started
    last, so that a set-up refused before it, or rsyslog's own words when it
    starts, are not taken for trouble now (1.10.248). problems=False: every
    line about TLS (why a restart did not listen)."""
    if NO_SERVICES or not shutil.which('journalctl'):
        return []
    since = '-%dmin' % minutes
    began = rsyslog_since() if problems else None
    if began and began > time.time() - minutes * 60:
        since = '@%d' % began
    got = subprocess.run(['journalctl', '-u', 'rsyslog', '--since', since,
                          '--no-pager', '-o', 'short-iso', '-n', '400'],
                         capture_output=True, text=True, timeout=30)
    hit = [l for l in got.stdout.splitlines() if re.search(TLS_WORDS, l, re.I)
           and not l.startswith('-- ') and (not problems or (re.search(TLS_BAD, l, re.I) and not re.search(TLS_BENIGN, l, re.I)))]
    return [l[:300] for l in hit[-8:]]


def fw_port_open(port):
    """Whether firewalld lets the port in (None: not firewalld)."""
    if fw_backend() != 'firewalld':
        return None
    got = subprocess.run(['firewall-cmd', '--query-port=%d/tcp' % port], capture_output=True)
    return got.returncode == 0


def otptls_read():
    conf = otptls_conf_now()
    st = otptls_state()
    out = {'conf': conf, 'file': conf.get('old') or OTPTLS_CONF, 'dir': OTPTLS_DIR, 'version': '',
           'driver_there': otptls_driver(), 'how': st.get('how') or '',
           'fw': fw_backend(), 'others': []}
    v = rsyslog_version()
    out['version'] = '%d.%d' % v if v else ''
    try:
        out['others'] = [p for p in otptls_others()['ports']]
    except Exception:                                   # noqa: BLE001
        pass
    for key, name in (('cert', 'isemon.crt'), ('ca', 'ca.pem'), ('own_ca', 'isemon-ca.crt')):
        try:
            with open(otptls_path(name)) as f:
                pem = f.read(400000)
            certs = pem_certs(pem)
            if key == 'ca':
                out['ca'] = [cert_facts(c) for c in certs[:6]]
            else:
                out[key] = cert_facts(certs[0]) if certs else {}
                if key == 'own_ca':
                    out['own_ca']['pem'] = certs[0] if certs else ''
        except (OSError, Refused):
            pass
    if conf.get('there') and conf.get('port'):
        out['listening'] = listening(conf['port'])
        out['fw_open'] = fw_port_open(conf['port'])
    out['trouble'] = rsyslog_trouble()
    # Whatever is left in the folder - from a set-up refused half way, say -
    # so that Remove… has something to take away (1.10.247).
    try:
        out['left'] = sorted(n for n in os.listdir(OTPTLS_DIR) if n != '.isemon.json')[:20] \
            if os.path.isdir(OTPTLS_DIR) and not os.path.islink(OTPTLS_DIR) else []
    except OSError:
        out['left'] = []
    return out


def otptls_text(port, auth, peers, driver, per_input, load):
    lines = [
        '# %s' % OTPTLS_CONF,
        OTPTLS_MARK + ' - written by isemon (Settings → %s →' % TLS_P['pane'],
        '# Encrypted receiving). Changed there, not here: a hand edit is written over',
        '# the next time it is set there. The plain input on 514 is not this file\'s:',
        '# a node that still sends plain goes on arriving there.',
        '#',
        ] + TLS_P['filed'] + [
        '']
    files = ('CAFile', otptls_path('ca.pem')), ('CertFile', otptls_path('isemon.crt')), \
        ('KeyFile', otptls_path('isemon.key'))
    if not per_input:
        lines += ['global('] + ['  DefaultNetstreamDriver%s="%s"' % f for f in files] + [')']
    if load:
        lines.append('module(load="imtcp")')
    inp = ['input(type="imtcp" port="%d" name="%s"' % (port, TLS_P['input']),
           '      StreamDriver.Name="%s"' % driver,
           '      StreamDriver.Mode="1"',
           '      StreamDriver.AuthMode="%s"' % auth]
    if per_input:
        inp += ['      StreamDriver.%s="%s"' % f for f in files]
    if auth == 'x509/name':
        inp.append('      PermittedPeer=[%s]' % ', '.join('"%s"' % p for p in peers))
    inp[-1] += ')'
    return '\n'.join(lines + inp) + '\n'


def otptls_ext(names):
    alt = []
    for n in names:
        try:
            plain(n, 'address')
            alt.append('IP:' + n)
        except ValueError:
            alt.append('DNS:' + n)
    return ('basicConstraints=critical,CA:FALSE\nkeyUsage=critical,digitalSignature,'
            'keyEncipherment\nextendedKeyUsage=serverAuth,clientAuth\nsubjectAltName=%s\n'
            % ','.join(alt))


def otptls_make(names, work):
    """A certificate for these names from this machine's own authority - made
    once, in OTPTLS_DIR, and kept: one made again is trusted by otp as it is.
    Returns (cert, key, the authority's certificate)."""
    ca_key, ca_crt = otptls_path('isemon-ca.key'), otptls_path('isemon-ca.crt')
    os.makedirs(OTPTLS_DIR, mode=0o750, exist_ok=True)
    if not (os.path.exists(ca_key) and os.path.exists(ca_crt)):
        host = re.sub(r'[^A-Za-z0-9.-]', '', os.uname()[1])[:60] or 'isemon'
        tk, tc = os.path.join(work, 'ca.key'), os.path.join(work, 'ca.crt')
        openssl(['req', '-x509', '-newkey', 'rsa:3072', '-nodes', '-sha256', '-days', '3650',
                 '-subj', '/CN=isemon %s - %s' % (host, TLS_P['ca_cn']), '-keyout', tk,
                 '-out', tc,
                 '-addext', 'basicConstraints=critical,CA:TRUE,pathlen:0',
                 '-addext', 'keyUsage=critical,keyCertSign,cRLSign'], 'the authority')
        with open(tk) as f:
            write_root(ca_key, f.read(), 0o600)
        with open(tc) as f:
            write_root(ca_crt, f.read(), 0o644)
    k, csr, crt, ext = (os.path.join(work, n) for n in ('s.key', 's.csr', 's.crt', 's.ext'))
    with open(ext, 'w') as f:
        f.write(otptls_ext(names))
    openssl(['req', '-new', '-newkey', 'rsa:3072', '-nodes', '-sha256', '-subj',
             '/CN=%s' % names[0], '-keyout', k, '-out', csr], 'the key')
    openssl(['x509', '-req', '-in', csr, '-CA', ca_crt, '-CAkey', ca_key, '-CAcreateserial',
             '-CAserial', os.path.join(work, 'serial'), '-days', '825', '-sha256',
             '-extfile', ext, '-out', crt], 'the certificate')
    with open(crt) as f:
        cert = f.read()
    with open(k) as f:
        key = f.read()
    with open(ca_crt) as f:
        own = f.read()
    return cert, key, own


def otptls_restart(port, said):
    if NO_SERVICES:
        return
    got = subprocess.run(['systemctl', 'restart', 'rsyslog'], capture_output=True, text=True,
                         timeout=120)
    if got.returncode != 0:
        raise Refused('rsyslog would not restart: %s' % (got.stderr or got.stdout).strip()[-300:])
    if port:
        end = time.time() + 12
        while time.time() < end:
            # rsyslog itself, not whatever else may listen there (1.10.294).
            who = port_holders(port)
            if who is None or 'rsyslogd' in who:
                said.append('rsyslog listens on %d/tcp' % port)
                return
            time.sleep(0.5)
        raise Refused('rsyslog restarted but does not listen on %d/tcp: %s' % (
            port, ' | '.join(rsyslog_trouble(2, problems=False)[-3:]) or
            'journalctl -u rsyslog says why'))


def otptls_firewalld(port, add, st, said):
    if fw_backend() != 'firewalld':
        return
    if add:
        if fw_port_open(port):
            return
        for extra in ([], ['--permanent']):
            subprocess.run(['firewall-cmd'] + extra + ['--add-port=%d/tcp' % port],
                           capture_output=True)
        st['fw_added'] = port
        said.append('firewalld lets %d/tcp in' % port)
    elif st.get('fw_added'):
        for extra in ([], ['--permanent']):
            subprocess.run(['firewall-cmd'] + extra + ['--remove-port=%d/tcp' % int(
                st['fw_added'])], capture_output=True)
        said.append('firewalld no longer lets %d/tcp in' % int(st['fw_added']))
        st.pop('fw_added', None)


def otptls_selinux(port, said):
    if port == 6514 or NO_SERVICES or not shutil.which('semanage'):
        return
    got = subprocess.run(['getenforce'], capture_output=True, text=True) \
        if shutil.which('getenforce') else None
    if got is None or got.stdout.strip() == 'Disabled':
        return
    r = subprocess.run(['semanage', 'port', '-a', '-t', 'syslog_tls_port_t', '-p', 'tcp',
                        str(port)], capture_output=True, text=True, timeout=120)
    if r.returncode == 0:
        said.append('SELinux lets rsyslog listen on %d/tcp' % port)
        return
    # Already a port of the policy's: rsyslog's, or another service's - and
    # that one is never taken away from it (1.10.294; it used to be, `-m`).
    got = subprocess.run(['semanage', 'port', '-l'], capture_output=True, text=True, timeout=120)
    # rsyslog's already, by any line: nothing to do. Another service's by a
    # port of its own (not a range such as ephemeral_port_t's, which a port
    # of ours is labelled over): refused (1.10.296).
    own = None
    for line in (got.stdout or '').splitlines():
        parts = line.split()
        if len(parts) < 3 or parts[1] != 'tcp':
            continue
        for one in ' '.join(parts[2:]).split(','):
            lo, _, hi = one.strip().partition('-')
            if not lo.isdigit() or not int(lo) <= port <= int(hi or lo):
                continue
            if parts[0] in ('syslog_tls_port_t', 'syslogd_port_t'):
                return
            if not hi or int(hi) == int(lo):
                own = parts[0]
    if own:
        raise Refused('SELinux keeps %d/tcp for another service (%s): choose another port'
                      % (port, own))


def otptls_apply(r):
    """The receiver put in - or changed (set), or taken away (off)."""
    do = r.get('do')
    said = []
    v = rsyslog_version()
    if do not in ('off', 'remove') and not NO_SERVICES and v is None:
        raise Refused('rsyslog is not installed here (dnf install rsyslog)')
    if do not in ('off', 'remove') and v is not None and v < (8, 2106):
        raise Refused('rsyslog %d.%d cannot have an encrypted input beside the plain one: '
                      '8.2106 or later is needed (AlmaLinux / RHEL 9)' % v)
    per_input = v is None or v >= (8, 2108)
    st = otptls_state()
    now = otptls_conf_now()
    paths = [OTPTLS_CONF, OTPTLS_OLD, otptls_path('ca.pem'), otptls_path('isemon.crt'),
             otptls_path('isemon.key'), otptls_path('.isemon.json')] + \
        [f for f in tls_siblings() if os.path.isfile(f)]
    snap = snapshot(paths)
    old_port = now.get('port') if now.get('there') else 0
    # One set up by hand before: kept beside, once, never loaded again.
    for path in (OTPTLS_CONF, OTPTLS_OLD):
        had = otptls_conf_now(path)
        if had.get('there') and not had.get('mine') and \
                not os.path.exists(path + '.isemon-before'):
            shutil.copy2(path, path + '.isemon-before')
            said.append('the file there before is kept as %s.isemon-before' % path)
    restarted = False
    try:
        # The one by the old name goes, whatever is asked (put back when
        # rsyslog says no).
        try:
            os.unlink(OTPTLS_OLD)
            said.append('%s taken away - %s takes its place' % (OTPTLS_OLD, OTPTLS_CONF))
        except FileNotFoundError:
            pass
        if do in ('off', 'remove'):
            # Off: the certificate and its key stay, to be switched on again.
            # Removed (1.10.246): they go too, and the authority made here.
            try:
                os.unlink(OTPTLS_CONF)
            except FileNotFoundError:
                pass
            # The other receiver's file changed with it: rsyslog asked first,
            # as when one is put in (1.10.294).
            if tls_loads_fix(said):
                rsyslog_check()
            otptls_restart(0, said)
            restarted = True
            otptls_firewalld(old_port, False, st, said)
            said.append('the encrypted input is taken away; the plain one is as it was')
            if do == 'off':
                st.update(on=False, at=time.time())
                if os.path.isdir(OTPTLS_DIR):
                    write_root(otptls_path('.isemon.json'), json.dumps(st), 0o600)
                return said
            gone = []
            if os.path.isdir(OTPTLS_DIR) and not os.path.islink(OTPTLS_DIR):
                for name in sorted(os.listdir(OTPTLS_DIR)):
                    if name in ('isemon.key', 'isemon.crt', 'ca.pem', 'isemon-ca.key',
                                'isemon-ca.crt', 'isemon-ca.srl', '.isemon.json'):
                        try:
                            os.unlink(otptls_path(name))
                            gone.append(name)
                        except OSError:
                            pass
                try:
                    os.rmdir(OTPTLS_DIR)
                except OSError:
                    pass
            if gone:
                said.append('the certificate, its key and the authorities taken away (%s)'
                            % OTPTLS_DIR)
            return said
        port = otptls_port(r.get('port'))
        mutual = bool(r.get('mutual'))
        peers = otptls_names(r.get('peers'), 'the nodes') if mutual else []
        auth = 'x509/name' if peers else ('x509/certvalid' if mutual else 'anon')
        others = otptls_others()
        if any(int(p['port']) == port and p['proto'] == 'tcp' for p in others['ports']):
            raise Refused('rsyslog listens on %d/tcp already (%s): choose another port' % (
                port, ', '.join(sorted({p['file'] for p in others['ports']
                                        if int(p['port']) == port}))))
        # ...nor one another program listens on (1.10.294): rsyslog could not
        # have it, and the firewall and SELinux would be opened for that
        # program instead.
        holders = port_holders(port) if port != old_port else None
        if holders:
            raise Refused('%d/tcp is taken here already (%s): choose another port'
                          % (port, ', '.join(holders)[:120]))
        if not per_input and others['global']:
            raise Refused('rsyslog %d.%d takes the TLS files once for all of it, and %s sets '
                          'them already: rsyslog 8.2108 or later takes them per input' % (
                              v + (', '.join(others['global']),)))
        os.makedirs(OTPTLS_DIR, mode=0o750, exist_ok=True)
        os.chmod(OTPTLS_DIR, 0o750)
        with tempfile.TemporaryDirectory(prefix='isemon-otptls-') as work:
            if do == 'make':
                names = otptls_names(r.get('names'), 'the names of this machine', 20)
                if not names:
                    raise Refused('the names the nodes reach this machine by: one at least')
                cert, key, own = otptls_make(names, work)
                trust = pem_certs(str(r.get('otp_ca') or ''))
                if mutual and not trust:
                    raise Refused('mutual TLS: %s\'s authority (its ca.pem) is needed, to '
                                  % TLS_P['who'] +
                                  'know the nodes by')
                ca = ''.join(trust) + own
                st.update(how='made', names=names, otp_ca=bool(trust))
                said.append('a certificate made for %s, by this machine\'s own authority'
                            % ', '.join(names))
            elif do == 'apply':
                got = pem_set(r.get('cert'), r.get('key'), r.get('chain'))
                if not got:
                    raise Refused('the certificate and its key')
                cert, key = got['cert'] + got['chain'], got['key']
                ca_text = str(r.get('ca') or '')
                if ca_text.strip() and not CERT_RE.match(ca_text.strip()):
                    raise Refused('the authority is not PEM (-----BEGIN CERTIFICATE-----)')
                ca = ''.join(pem_certs(ca_text)) or ''.join(pem_certs(got['chain'])) or \
                    pem_certs(cert)[0]
                if mutual and not pem_certs(ca_text):
                    raise Refused('mutual TLS: %s\'s authority (its ca.pem) is needed, to '
                                  % TLS_P['who'] +
                                  'know the nodes by')
                st.update(how=str(r.get('how') or 'given')[:20], names=[],
                          otp_ca=bool(pem_certs(ca_text)))
            elif do == 'set':
                if not (os.path.exists(otptls_path('isemon.crt')) and
                        os.path.exists(otptls_path('isemon.key'))):
                    raise Refused('there is no certificate here yet: set it up first')
                cert = key = ca = None
                extra = pem_certs(str(r.get('otp_ca') or ''))
                if extra:
                    with open(otptls_path('ca.pem')) as f:
                        have = pem_certs(f.read())
                    ca = ''.join(have + [c for c in extra if c not in have])
                    st['otp_ca'] = True
                if mutual and not st.get('otp_ca', True):
                    raise Refused('mutual TLS: %s\'s authority (its ca.pem) is needed, to '
                                  % TLS_P['who'] +
                                  'know the nodes by - the certificate here was set up without '
                                  'it')
            else:
                raise Refused('read, apply, make, set, off or remove')
            if cert is not None:
                cert_facts(pem_certs(cert)[0])
                write_root(otptls_path('isemon.key'), key, 0o600)
                write_root(otptls_path('isemon.crt'), cert, 0o644)
            if ca is not None:
                write_root(otptls_path('ca.pem'), ca, 0o644)
        driver = otptls_driver_get(said)
        text = otptls_text(port, auth, peers, driver, per_input, not others['imtcp'])
        write_root(OTPTLS_CONF, text, 0o644)
        tls_loads_fix(said)
        if shutil.which('restorecon') and not NO_SERVICES:
            subprocess.run(['restorecon', '-R', os.path.dirname(OTPTLS_DIR)], capture_output=True)
        rsyslog_check()
        otptls_selinux(port, said)
        restarted = True
        otptls_restart(port, said)
        if old_port and old_port != port:
            otptls_firewalld(old_port, False, st, said)
        otptls_firewalld(port, True, st, said)
        st.update(on=True, port=port, auth=auth, peers=peers, at=time.time())
        write_root(otptls_path('.isemon.json'), json.dumps(st), 0o600)
        said.append('rsyslog takes the %s logs over TLS on %d/tcp (%s)' % (
            TLS_P['who'], port, {
                'anon': 'it checks no node', 'x509/certvalid': 'from any node with a '
                'certificate of %s\'s authority' % TLS_P['who'],
                'x509/name': 'from %s' % ', '.join(peers)}[auth]))
        return said
    except BaseException:
        put_back(snap)
        if restarted:
            try:
                otptls_restart(0, [])
            except Exception:                           # noqa: BLE001
                pass
        raise


def otptls_part():
    try:
        raw = read_req(OTPTLS_ASK, 262144)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        drop_entry(OTPTLS_ASK)            # a link or a folder in its place: never followed
        return
    drop_entry(OTPTLS_ASK)
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        try:
            r = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise Refused('the request does not read')
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        if r.get('do') != 'read':
            try:
                at = float(r.get('at') or 0)
            except (TypeError, ValueError):
                at = 0.0
            if not math.isfinite(at) or abs(time.time() - at) > OTPTLS_FRESH_S:
                raise Refused('that was asked too long ago - ask again on the page')
            out['said'] = otptls_apply(r)
        out['data'] = otptls_read()
        out['ok'] = True
    except Refused as e:
        out['said'] = str(e)[:600]
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    if not out['ok']:
        try:
            out['data'] = otptls_read()
        except Exception:                               # noqa: BLE001
            pass
    write_here(OTPTLS_FILE, json.dumps(out))


def acmetls_part():
    """The acme logs over TLS (1.10.287): otp's receiver, done again with
    acme's file, folder, words and requests (acmetls.ask, acmetls.json) - the
    two side by side, each on a port of its own."""
    global OTPTLS_ASK, OTPTLS_FILE, OTPTLS_CONF, OTPTLS_OLD, OTPTLS_DIR, OTPTLS_MARK, TLS_P
    was = (OTPTLS_ASK, OTPTLS_FILE, OTPTLS_CONF, OTPTLS_OLD, OTPTLS_DIR, OTPTLS_MARK, TLS_P)
    TLS_SIBLINGS[:] = [OTPTLS_CONF]
    OTPTLS_ASK, OTPTLS_FILE = 'acmetls.ask', 'acmetls.json'
    OTPTLS_CONF, OTPTLS_OLD, OTPTLS_DIR = ACMETLS_CONF, ACMETLS_OLD, ACMETLS_DIR
    OTPTLS_MARK, TLS_P = '# isemon: the acme logs over TLS', ACMETLS_P
    try:
        otptls_part()
    finally:
        OTPTLS_ASK, OTPTLS_FILE, OTPTLS_CONF, OTPTLS_OLD, OTPTLS_DIR, OTPTLS_MARK, TLS_P = was
        TLS_SIBLINGS[:] = []


def status_read():
    """What this helper wrote last. It lies in the folder the isemon account
    owns, so nothing of it is trusted: what is used again (the DH choice) is
    checked again."""
    try:
        got = json.loads(read_req('status.json').decode('utf-8'))
    except (OSError, ValueError, Refused):
        return {}
    if not isinstance(got, dict):
        return {}
    if got.get('dh') not in DH_CHOICES:
        got['dh'] = 'none'
    return got



# ---- SELinux (1.10.319) -----------------------------------------------------------
# Settings → SELinux: how SELinux is on this machine, what isemon needs of it
# (its module, the labels of its files, a boolean, the ports of the programs
# around it) and what it refused - and, asked, the steps on the way to
# enforcing: made ready (permissive at the next start), what isemon needs put
# in, enforcing, permissive again. Nothing changes unless somebody asks: a
# machine with SELinux disabled stays so. isemon's own programs run
# unconfined (unconfined_service_t); what matters are the confined ones around
# it - nginx and php-fpm (httpd_t) reading the API token and asking the daemon,
# rsyslog (syslogd_t) on its ports, logrotate, the database server.
# Nothing of the request is trusted: booleans and port types from the lists
# below only, every port a number, and a port is only ever added to a type
# (semanage port -a) - never taken from the service it belongs to (-m).
SELINUX_ASK, SELINUX_FILE = 'selinux.ask', 'selinux.json'
ROOT_STATE_DIR = os.environ.get('ISEMON_ROOT_STATE', '/var/lib/isemon-root')
SE_CONFIG = os.environ.get('ISEMON_SELINUX_CONFIG', '/etc/selinux/config')
SE_RELABEL = os.environ.get('ISEMON_SELINUX_RELABEL', '/.autorelabel')
SE_CMDLINE = os.environ.get('ISEMON_SELINUX_CMDLINE', '/proc/cmdline')
SE_MODULE = 'isemon_server'
SE_CIL = os.environ.get('ISEMON_SELINUX_CIL', '/usr/local/lib/isemon/isemon_server.cil')
# What isemon's files should be labelled; the label is the third field of the context.
SE_LABELS = (('/run/isemon', 'httpd_var_run_t', 'the folder of the API token'),
             ('/run/isemon/api-token', 'httpd_var_run_t', 'the API token the pages read'),
             ('/var/www/isemon', 'httpd_sys_content_t', 'the pages'))
# A newer policy calls the web server's run files httpd_runtime_t: the same.
SE_SAME = {'httpd_var_run_t': ('httpd_runtime_t',)}
SE_BOOLEANS = ('httpd_can_network_connect',)
SE_PORT_TYPES = ('postgresql_port_t', 'mysqld_port_t', 'syslogd_port_t', 'syslog_tls_port_t',
                 'http_port_t')
# The programs whose refusals are isemon's business.
SE_DOMAINS = ('httpd_t', 'syslogd_t', 'logrotate_t', 'postgresql_t', 'mysqld_t',
              'unconfined_service_t', 'init_t', 'chronyd_t', 'system_cronjob_t')
# The ports rsyslog may listen on as the policy ships it - nothing asked for them.
SE_SYSLOG_OWN = {('udp', 514), ('tcp', 514), ('udp', 601), ('tcp', 601), ('udp', 20514),
                 ('tcp', 20514), ('udp', 6514), ('tcp', 6514), ('udp', 10514), ('tcp', 10514)}
SE_APPLIED = 'selinux-applied'      # when isemon's needs were last put in


def _se_run(cmd, timeout=120, light=False, data=None):
    if not shutil.which(cmd[0]):
        return None
    if light:
        # The heavy ones (semanage loads the whole policy, ausearch reads the
        # audit log since the start) at the lowest priority, behind the daemon.
        if shutil.which('ionice'):
            cmd = ['ionice', '-c', '3'] + cmd
        if shutil.which('nice'):
            cmd = ['nice', '-n', '19'] + cmd
    try:
        return subprocess.run(cmd, input=data, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError):
        return None


def _read_or(path, most=1048576):
    try:
        with open(path, encoding='utf-8', errors='replace') as f:
            return f.read(most)
    except OSError:
        return None


def root_state_write(name, text):
    """A note of root's own, in root's own folder - never the isemon account's,
    which could write a time ahead there and hide every refusal."""
    os.makedirs(ROOT_STATE_DIR, mode=0o700, exist_ok=True)
    os.chmod(ROOT_STATE_DIR, 0o700)
    path = os.path.join(ROOT_STATE_DIR, name)
    fd, tmp = tempfile.mkstemp(prefix='.isemon-', dir=ROOT_STATE_DIR)
    try:
        with os.fdopen(fd, 'w') as f:
            f.write(text)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def se_applied_at():
    try:
        fd = os.open(os.path.join(ROOT_STATE_DIR, SE_APPLIED), os.O_RDONLY | os.O_NOFOLLOW |
                     os.O_NONBLOCK)
        with os.fdopen(fd) as f:
            return float((json.loads(f.read(4096)) or {}).get('at') or 0)
    except (OSError, TypeError, ValueError, AttributeError):
        return 0.0


def se_auditd():
    """Whether what SELinux refuses is written down at all: auditd running."""
    fake = os.environ.get('ISEMON_SELINUX_AUDITD')          # tests
    if fake:
        return fake == 'active'
    got = _se_run(['systemctl', 'is-active', 'auditd'], 20)
    return got is None or (got.stdout or '').strip() == 'active'


def se_mode():
    got = _se_run(['getenforce'], 20)
    if got is None:
        return 'absent'                 # no SELinux on this machine at all (Debian, Ubuntu)
    return (got.stdout or '').strip() or 'Disabled'


def se_config():
    text = _read_or(SE_CONFIG) or ''
    out = {}
    for line in text.splitlines():
        m = re.match(r'^\s*(SELINUX|SELINUXTYPE)\s*=\s*([A-Za-z0-9_-]+)\s*$', line)
        if m:
            out[m.group(1)] = m.group(2)
    return {'mode': out.get('SELINUX', ''), 'type': out.get('SELINUXTYPE', ''),
            'there': bool(text)}


def se_config_set(mode):
    """SELINUX= in /etc/selinux/config, the rest of the file as it is."""
    if mode not in ('permissive', 'enforcing'):
        raise Refused('permissive or enforcing')
    text = _read_or(SE_CONFIG)
    if text is None:
        raise Refused('%s is not there - is the SELinux policy installed? '
                      '(dnf install selinux-policy-targeted)' % SE_CONFIG)
    if re.search(r'(?m)^\s*SELINUX\s*=', text):
        new = re.sub(r'(?m)^(\s*)SELINUX\s*=.*$', r'\g<1>SELINUX=%s' % mode, text)
    else:
        new = text.rstrip('\n') + '\nSELINUX=%s\n' % mode
    if new != text:
        st = os.stat(SE_CONFIG)
        write_root(SE_CONFIG, new, stat.S_IMODE(st.st_mode))
        return True
    return False


def se_cmdline_off():
    """selinux=0 on the kernel's command line: the config alone does not switch it on."""
    return bool(re.search(r'(?:^|\s)selinux=0(?:\s|$)', _read_or(SE_CMDLINE) or ''))


def se_label(path):
    fake = os.environ.get('ISEMON_SELINUX_LABELS')         # tests: {path: label}
    if fake:
        try:
            with open(fake) as f:
                return (json.load(f) or {}).get(path)
        except (OSError, ValueError):
            return None
    try:
        raw = os.getxattr(path, 'security.selinux', follow_symlinks=False)
    except (OSError, AttributeError):
        return None
    parts = raw.decode('utf-8', 'replace').rstrip('\0').split(':')
    return parts[2] if len(parts) >= 3 else None


def se_module_in():
    got = _se_run(['semodule', '-l'], 120, light=True)
    if got is None or got.returncode != 0:
        return None
    return any(line.split()[:1] == [SE_MODULE] for line in got.stdout.splitlines())


def se_bool(name):
    got = _se_run(['getsebool', name], 20)
    if got is None or got.returncode != 0:
        return None
    return bool(re.search(r'-->\s*on\s*$', got.stdout.strip()))


def se_ports():
    """semanage port -l: {(type, proto): [(lo, hi), ...]}; None without semanage."""
    got = _se_run(['semanage', 'port', '-l'], 120, light=True)
    if got is None or got.returncode != 0:
        return None
    out = {}
    for line in got.stdout.splitlines():
        m = re.match(r'^(\S+_port_t)\s+(tcp|udp|sctp|dccp)\s+(.+)$', line.strip())
        if not m:
            continue
        spans = []
        for p in m.group(3).split(','):
            a, _, b = p.strip().partition('-')
            try:
                spans.append((int(a), int(b or a)))
            except ValueError:
                continue
        out.setdefault((m.group(1), m.group(2)), []).extend(spans)
    return out


def se_port_has(ports, kind, proto, port):
    return any(lo <= port <= hi for lo, hi in (ports or {}).get((kind, proto), []))


def se_rsyslog_needs():
    """The ports rsyslog listens on here that its policy does not give it -
    read by root off rsyslog's own files, nothing the daemon said. An input in
    a TLS file (isemon's otp and acme ones) is syslog_tls_port_t, the rest
    syslogd_port_t."""
    out = []
    try:
        ports = rsyslog_ports()
    except Exception:                                   # noqa: BLE001
        return out
    for p in ports:
        try:
            n = int(p['port'])
        except (TypeError, ValueError, KeyError):
            continue
        if (p['proto'], n) in SE_SYSLOG_OWN:
            continue
        tls = 'tls' in str(p.get('file') or '').lower()
        out.append({'port': n, 'proto': 'tcp' if tls else p['proto'],
                    'type': 'syslog_tls_port_t' if tls else 'syslogd_port_t',
                    'why': 'rsyslog receives %s on it (%s)' % (
                        'logs over TLS' if tls else 'logs', str(p.get('file') or '')[:60]),
                    'own': True})
    return out


def se_denials(since=0.0):
    """What SELinux refused since the machine started - or since isemon's needs
    were last put in (what was refused before that is what they put right) -
    for the programs isemon works with."""
    got = _se_run(['ausearch', '-m', 'AVC,USER_AVC', '-ts', 'boot'], 120, light=True)
    if got is None:
        return {'tool': False, 'total': 0, 'groups': [], 'since': since}
    groups, lines, total = {}, {}, 0
    # The program each refusal came from (1.10.320): the event's SYSCALL line
    # says it (exe=), the AVC line only the thread's name - which Python
    # gives as "Thread-351 (...)", hex-encoded for its space.
    exes = {}
    for line in (got.stdout or '').splitlines():
        if line.startswith('type=SYSCALL'):
            mid = re.search(r'msg=audit\(([0-9.]+:\d+)\)', line)
            exe = re.search(r'\bexe=(\S+)', line)
            if mid and exe:
                exes[mid.group(1)] = se_audit_word(exe.group(1))
    for line in (got.stdout or '').splitlines():
        if 'avc:' not in line or 'denied' not in line:
            continue
        when = re.search(r'msg=audit\((\d+)(?:\.\d+)?:', line)
        if since and when and int(when.group(1)) < since:
            continue
        perms = re.search(r'denied\s+\{([^}]*)\}', line)
        sc = re.search(r'scontext=(\S+)', line)
        tc = re.search(r'tcontext=(\S+)', line)
        cl = re.search(r'tclass=(\S+)', line)
        comm = re.search(r'comm=(\S+)', line)
        name = re.search(r'\bname=(\S+)', line)
        if not (perms and sc and tc and cl):
            continue
        st = (sc.group(1).split(':') + ['', '', ''])[2]
        tt = (tc.group(1).split(':') + ['', '', ''])[2]
        mid = re.search(r'msg=audit\(([0-9.]+:\d+)\)', line)
        exe = exes.get(mid.group(1)) if mid else ''
        what = ' '.join(x for x in (se_audit_word(comm.group(1)) if comm else '',
                                    se_audit_word(name.group(1)) if name else '', exe or '') if x)
        if st not in SE_DOMAINS and 'isemon' not in line:
            continue
        total += 1
        key = (st, tt, cl.group(1), perms.group(1).strip())
        lines[key] = line
        g = groups.setdefault(key, {'source': st, 'target': tt, 'class': cl.group(1),
                                    'perms': perms.group(1).strip(), 'count': 0, 'what': ''})
        g['count'] += 1
        g['what'] = what.replace('"', '')[:120] or g['what']
    # Refused once, allowed now: a module or a boolean that came after it
    # settles it - not counted.
    settled = 0
    for key in se_allowed_now(lines):
        settled += groups[key]['count']
        total -= groups.pop(key)['count']
    out = sorted(groups.values(), key=lambda g: -g['count'])[:30]
    return {'tool': True, 'total': total, 'groups': out, 'since': since, 'settled': settled}


def se_audit_word(v):
    """A value of an audit line as it reads: "quoted" as it is, else hex
    (the kernel writes a value with a space or a quote in it so) decoded."""
    v = str(v or '')
    if len(v) >= 2 and v[0] == v[-1] == '"':
        return v[1:-1]
    if len(v) % 2 == 0 and re.match(r'^[0-9A-F]+\Z', v):
        try:
            return bytes.fromhex(v).decode('utf-8', 'replace').replace('\0', ' ').strip()
        except ValueError:
            return v
    return v


def se_allowed_now(lines):
    """Which of the refusals (one line of each kind) the policy loaded now
    allows, as audit2why tells: "would be allowed by active policy"."""
    if not lines:
        return []
    by_id = {}
    for key, line in lines.items():
        m = re.search(r'msg=audit\(([0-9.]+:\d+)\)', line)
        if m:
            by_id[m.group(1)] = key
    if not by_id:
        return []
    got = _se_run(['audit2why'], 300, light=True,
                  data=''.join(lines[k] + '\n' for k in by_id.values()))
    if got is None or got.returncode != 0:
        return []
    now, cur = set(), None
    for line in (got.stdout or '').splitlines():
        m = re.search(r'msg=audit\(([0-9.]+:\d+)\)', line)
        if m and 'avc:' in line:
            cur = by_id.get(m.group(1))
            continue
        if cur is not None and 'would be allowed by active policy' in line:
            now.add(cur)
    return sorted(now)


def se_want_checked(r, left_out=None):
    """What the daemon says isemon needs: booleans and ports, checked against
    what may be. A port of a type this helper does not set is said and left
    out, never the whole request refused over it."""
    bools = []
    for b in (r.get('booleans') or [])[:8]:
        if not isinstance(b, dict) or b.get('name') not in SE_BOOLEANS:
            raise Refused('a boolean isemon does not set')
        bools.append({'name': b['name'], 'why': str(b.get('why') or '')[:120]})
    ports = []
    for p in (r.get('ports') or [])[:16]:
        if left_out is not None and isinstance(p, dict) and p.get('proto') in ('tcp', 'udp') and \
                p.get('type') not in SE_PORT_TYPES and \
                re.match(r'^[a-z][a-z0-9_]{0,40}_port_t\Z', str(p.get('type') or '')):
            left_out.append('port %s/%s (%s) left out: this helper does not set %s - '
                            './install.sh --upgrade puts in one that does'
                            % (str(p.get('port'))[:6], p['proto'], str(p.get('why') or '')[:80],
                               p['type']))
            continue
        if not isinstance(p, dict) or p.get('type') not in SE_PORT_TYPES or \
                p.get('proto') not in ('tcp', 'udp'):
            raise Refused('a port type isemon does not set')
        try:
            n = int(p.get('port'))
        except (TypeError, ValueError):
            raise Refused('a port is a number')
        if not 1 <= n <= 65535:
            raise Refused('a port is 1 to 65535')
        ports.append({'port': n, 'proto': p['proto'], 'type': p['type'],
                      'why': str(p.get('why') or '')[:120]})
    seen = {(p['port'], p['proto']) for p in ports}
    for p in se_rsyslog_needs():
        if (p['port'], p['proto']) not in seen:
            seen.add((p['port'], p['proto']))
            ports.append(p)
    return bools, ports


def se_label_ok(got, want):
    return got == want or got in SE_SAME.get(want, ())


def se_check(r):
    left = []
    bools, ports = se_want_checked(r, left)
    mode = se_mode()
    conf = se_config()
    out = {'mode': mode, 'config': conf['mode'], 'policy': conf['type'],
           'relabel_pending': os.path.exists(SE_RELABEL), 'cmdline_off': se_cmdline_off(),
           'tools': {'semanage': bool(shutil.which('semanage')),
                     'ausearch': bool(shutil.which('ausearch')),
                     'semodule': bool(shutil.which('semodule'))},
           'module': None, 'labels': [], 'booleans': [], 'ports': [],
           'denials': {'tool': False, 'total': 0, 'groups': []}, 'problems': [],
           'left_out': left}
    if mode == 'absent':
        out['ready'] = False
        return out
    on = mode in ('Enforcing', 'Permissive')
    out['module'] = se_module_in()
    for path, want, why in SE_LABELS:
        if not os.path.exists(path):
            continue
        got = se_label(path) if on else None
        out['labels'].append({'path': path, 'label': got, 'want': want, 'why': why,
                              'ok': se_label_ok(got, want) if on else None})
    for b in bools:
        out['booleans'].append(dict(b, on=se_bool(b['name']) if on else None))
    known = se_ports() if on else None
    for p in ports:
        out['ports'].append(dict(p, labelled=(se_port_has(known, p['type'], p['proto'], p['port'])
                                             if known is not None else None)))
    if on:
        out['denials'] = se_denials(se_applied_at())
        out['auditd'] = se_auditd()
    probs = out['problems']
    if on:
        if out['module'] is False:
            probs.append('isemon\'s module (%s) is not installed' % SE_MODULE)
        probs.extend('%s is labelled %s, not %s (%s)' % (x['path'], x['label'] or '?', x['want'],
                                                         x['why'])
                     for x in out['labels'] if x['ok'] is False)
        probs.extend('the boolean %s is off (%s)' % (x['name'], x['why'])
                     for x in out['booleans'] if x['on'] is False)
        probs.extend('port %d/%s is not labelled %s (%s)' % (x['port'], x['proto'], x['type'],
                                                             x['why'])
                     for x in out['ports'] if x['labelled'] is False)
        if known is None and ports:
            probs.append('semanage is not on this machine - the ports cannot be checked '
                         '(dnf install policycoreutils-python-utils)')
        if out['denials']['total']:
            probs.append(('SELinux refused %d thing(s) since isemon\'s needs were put in'
                          if out['denials'].get('since') else
                          'SELinux refused %d thing(s) since the machine started')
                         % out['denials']['total'])
        if not out.get('auditd', True):
            probs.append('auditd does not run - what SELinux refuses is not written down '
                         '(systemctl enable --now auditd)')
        if not out['denials']['tool']:
            probs.append('ausearch is not on this machine - what SELinux refused cannot be '
                         'read (dnf install audit)')
    out['ready'] = (mode == 'Permissive' and not probs)
    return out


def se_apply(bools, ports, said, mark=True):
    """isemon's module, labels, booleans and ports - on a machine where SELinux
    is on. `mark`: when anything was changed, what SELinux refused before no
    longer counts."""
    changed = False
    inpol = _read_or(SE_CIL + '.in-policy')
    if os.path.exists(SE_CIL) and shutil.which('semodule') and (
            se_module_in() is not True or inpol != _read_or(SE_CIL)):
        got = _se_run(['semodule', '-i', SE_CIL], 300)
        if got is None or got.returncode != 0:
            raise Refused('semodule -i %s: %s' % (SE_CIL, ((got.stderr or got.stdout)
                                                           if got else '').strip()[-200:]))
        said.append('isemon\'s module installed')
        changed = True
        try:
            shutil.copyfile(SE_CIL, SE_CIL + '.in-policy')
        except OSError:
            pass
    for b in bools:
        if se_bool(b['name']) is False:
            got = _se_run(['setsebool', '-P', b['name'], 'on'], 300)
            if got is None or got.returncode != 0:
                raise Refused('setsebool -P %s on: %s' % (b['name'], ((got.stderr or '') if got
                                                                      else '').strip()[-200:]))
            said.append('%s on' % b['name'])
            changed = True
    known = se_ports()
    for p in ports:
        if known is None:
            raise Refused('semanage is not on this machine (dnf install '
                          'policycoreutils-python-utils)')
        if se_port_has(known, p['type'], p['proto'], p['port']):
            continue
        got = _se_run(['semanage', 'port', '-a', '-t', p['type'], '-p', p['proto'],
                       str(p['port'])], 300)
        if got is not None and got.returncode != 0 and 'already defined' in (got.stderr or ''):
            # Never taken from the service it belongs to: -m labelled it for
            # isemon, and that service could not bind it at its next start.
            raise Refused('port %d/%s is another service\'s in the SELinux policy - choose '
                          'another port for it (%s)' % (p['port'], p['proto'], p['why']))
        if got is None or got.returncode != 0:
            raise Refused('semanage port %d/%s: %s' % (p['port'], p['proto'], ((got.stderr or '')
                                                       if got else '').strip()[-200:]))
        said.append('port %d/%s labelled %s' % (p['port'], p['proto'], p['type']))
        changed = True
    if shutil.which('restorecon') and not NO_SERVICES:
        got = _se_run(['restorecon', '-R', '-v'] + [x for x in ('/run/isemon', '/var/www/isemon')
                                                  if os.path.exists(x)], 300)
        if got is not None and 'elabel' in (got.stdout or '') + (got.stderr or ''):
            said.append('isemon\'s files labelled again')
            changed = True
    # From now on what is refused counts again: what was refused before is
    # what this put right. Only when something changed, and never on the way
    # to enforcing.
    if mark and changed:
        root_state_write(SE_APPLIED, json.dumps({'at': time.time()}))


def se_do(r):
    do = r.get('do')
    left = []
    bools, ports = se_want_checked(r, left)
    said = list(left)
    if do == 'check':
        return se_check(r)
    if do == 'report':
        data = se_report_bytes(r, 'isemon-selinux-report')
        write_here_bytes(SE_REPORT_FILE, data)
        return {'report': SE_REPORT_FILE, 'bytes': len(data), 'at': time.time()}
    mode = se_mode()
    if mode == 'absent':
        raise Refused('there is no SELinux on this machine')
    if do == 'prepare':
        if mode == 'Enforcing':
            raise Refused('SELinux is enforcing already')
        if se_config_set('permissive'):
            said.append('%s: SELINUX=permissive' % SE_CONFIG)
        if mode == 'Disabled':
            # Every file labelled at the next start, before anything runs
            # (minutes); the boolean and the ports are put in once it is
            # permissive ("Put in what isemon needs").
            with open(SE_RELABEL, 'a'):
                pass
            said.append('the files are labelled at the next start of the machine')
            if se_cmdline_off() and shutil.which('grubby'):
                got = _se_run(['grubby', '--update-kernel', 'ALL', '--remove-args', 'selinux'], 120)
                if got is None or got.returncode != 0:
                    raise Refused('grubby: %s' % ((got.stderr or '') if got else '')[-200:])
                said.append('selinux=0 taken off the kernel\'s command line')
            elif se_cmdline_off():
                said.append('the kernel\'s command line has selinux=0: take it away '
                            '(grubby --update-kernel ALL --remove-args selinux)')
            if os.path.exists(SE_CIL) and shutil.which('semodule'):
                got = _se_run(['semodule', '-i', SE_CIL], 300)    # may not work while disabled
                if got is not None and got.returncode == 0:
                    said.append('isemon\'s module installed')
            said.append('restart the machine - it comes up permissive: nothing is refused yet, '
                        'what would be is written down')
        else:
            se_apply(bools, ports, said)
    elif do == 'enforce':
        if mode != 'Permissive':
            raise Refused('SELinux is %s - it goes to enforcing from permissive only'
                          % mode.lower())
        se_apply(bools, ports, said, mark=False)
        c = se_check(r)
        if c['problems']:
            raise Refused('not yet: ' + '; '.join(c['problems'][:4]))
        got = _se_run(['setenforce', '1'], 60)
        if got is None or got.returncode != 0:
            raise Refused('setenforce 1: %s' % ((got.stderr or '') if got else '')[-200:])
        se_config_set('enforcing')
        said.append('SELinux is enforcing, and stays so after a restart')
    elif do == 'permissive':
        if mode == 'Disabled':
            raise Refused('SELinux is disabled - "prepare" makes it permissive')
        if mode == 'Enforcing':
            got = _se_run(['setenforce', '0'], 60)
            if got is None or got.returncode != 0:
                raise Refused('setenforce 0: %s' % ((got.stderr or '') if got else '')[-200:])
        se_config_set('permissive')
        said.append('SELinux is permissive, and stays so after a restart')
    else:
        raise Refused('check, prepare, enforce, permissive or report')
    out = se_check(r)
    out['said'] = said
    return out


# ---- what SELinux says here, gathered for whoever writes isemon's module -------
SE_REPORT_FILE = 'selinux-report.tar.gz'
SE_REPORT_MOST = 2 * 1024 * 1024        # each part at most, before it is packed
SE_REPORT_PATHS = ('/run/isemon', '/run/isemon/api-token', '/var/lib/isemon', '/var/lib/isemon/web',
                   '/etc/isemon', '/etc/isemon/config.json', '/var/www/isemon', '/usr/local/lib/isemon',
                   '/var/log/isemon', '/var/log/remote', '/etc/nginx/certs', '/etc/nginx/conf.d',
                   '/etc/rsyslog.d', '/etc/pki/rsyslog', '/run/php-fpm', '/var/lib/pgsql',
                   '/var/lib/mysql', '/etc/logrotate.d', '/etc/cron.daily')
SE_REPORT_COMMS = ('python', 'isemon', 'nginx', 'php-fpm', 'rsyslogd', 'postgres', 'postmaster',
                   'mariadbd', 'mysqld', 'auditd', 'logrotate', 'chronyd')
SE_REPORT_PORT_TYPES = ('http_port_t', 'http_cache_port_t', 'postgresql_port_t', 'mysqld_port_t',
                        'syslogd_port_t', 'syslog_tls_port_t', 'rsh_port_t', 'unreserved_port_t')


def _se_cut(text):
    b = text.encode('utf-8', 'replace')
    if len(b) <= SE_REPORT_MOST:
        return text
    # The newest lines kept: the end of the audit log is what came last.
    return '(the first %d bytes left out - too long)\n' % (len(b) - SE_REPORT_MOST) + \
        b[-SE_REPORT_MOST:].decode('utf-8', 'replace')


def _se_out(cmd, timeout=120, data=None, light=True):
    """A command's words for the report - what it said, or why it said nothing."""
    if not shutil.which(cmd[0]):
        return '(%s is not on this machine)\n' % cmd[0]
    if light:
        if shutil.which('ionice'):
            cmd = ['ionice', '-c', '3'] + cmd
        if shutil.which('nice'):
            cmd = ['nice', '-n', '19'] + cmd
    try:
        got = subprocess.run(cmd, input=data, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError) as e:
        return '(%s: %s)\n' % (' '.join(cmd), e)
    return _se_cut((got.stdout or '') + (('\n--- stderr ---\n' + got.stderr)
                                         if (got.stderr or '').strip() else ''))


def se_report_parts(r):
    """Every part of the report: {name: text}. Read only - nothing is changed."""
    parts = {}
    parts['check.json'] = json.dumps(se_check(r), indent=1, sort_keys=True)
    parts['isemon.json'] = json.dumps({'facts': r.get('facts') if isinstance(r.get('facts'), dict)
                                       else {},
                                       'want': {'booleans': r.get('booleans') or [],
                                                'ports': r.get('ports') or []}},
                                      indent=1, sort_keys=True)[:65536]
    kinds = 'AVC,USER_AVC,SELINUX_ERR,USER_SELINUX_ERR'
    raw = _se_out(['ausearch', '-m', kinds, '-ts', 'boot'], 300)
    parts['avc-raw.txt'] = raw
    parts['avc.txt'] = _se_out(['ausearch', '-m', kinds, '-ts', 'boot', '-i'], 300)
    if raw.startswith('('):
        parts['audit2why.txt'] = parts['audit2allow.te'] = raw
    else:
        parts['audit2why.txt'] = _se_out(['audit2why'], 300, data=raw)
        parts['audit2allow.te'] = _se_out(['audit2allow', '-m', 'isemon_local'], 300, data=raw)
    sysw = []
    for name, cmd in (('os-release', ['cat', '/etc/os-release']), ('kernel', ['uname', '-a']),
                      ('started', ['uptime', '-s']), ('getenforce', ['getenforce']),
                      ('sestatus', ['sestatus', '-v']),
                      ('packages', ['rpm', '-q', 'selinux-policy', 'selinux-policy-targeted',
                                    'policycoreutils', 'policycoreutils-python-utils',
                                    'libselinux-utils', 'audit', 'nginx', 'php-fpm', 'rsyslog',
                                    'postgresql-server', 'mariadb-server', 'logrotate']),
                      ('kernel command line', ['cat', SE_CMDLINE]),
                      ('selinux config', ['cat', SE_CONFIG]),
                      ('auditd', ['systemctl', 'is-active', 'auditd'])):
        sysw.append('==== %s\n%s' % (name, _se_out(cmd, 60, light=False)))
    parts['system.txt'] = '\n'.join(sysw)
    lab = []
    for p in SE_REPORT_PATHS:
        if os.path.lexists(p):
            lab.append(_se_out(['ls', '-Zd', p], 20, light=False).rstrip())
            if os.path.isdir(p) and not os.path.islink(p) and p not in ('/var/log/remote',):
                lab.append(_se_out(['ls', '-Za', p], 20, light=False).rstrip())
            lab.append('  policy says: ' + _se_out(['matchpathcon', p], 20, light=False).strip())
    parts['labels.txt'] = '\n'.join(lab) + '\n'
    ps = _se_out(['ps', '-eZo', 'label,user,pid,comm,args'], 60, light=False)
    keep = [x for x in ps.splitlines() if x.startswith('LABEL') or
            any(c in x for c in SE_REPORT_COMMS)]
    # Arguments cut to 200: what runs, not every word it was given.
    parts['processes.txt'] = '\n'.join(x[:200] for x in keep) + '\n'
    ports = _se_out(['semanage', 'port', '-l'], 300)
    parts['ports.txt'] = '==== labelled\n' + '\n'.join(
        x for x in ports.splitlines() if x.split()[:1] and x.split()[0] in SE_REPORT_PORT_TYPES) + \
        '\n\n==== listening\n' + _se_out(['ss', '-lntupZ'], 60, light=False)
    bools = _se_out(['getsebool', '-a'], 60, light=False)
    parts['booleans.txt'] = '\n'.join(x for x in bools.splitlines() if re.match(
        r'^(httpd_|logging_|nis_enabled|daemons_|domain_can|postgresql_|mysql_|logrotate_)',
        x)) + '\n'
    mods = _se_out(['semodule', '-l'], 300)
    parts['modules.txt'] = '==== isemon\n' + '\n'.join(
        x for x in mods.splitlines() if 'isemon' in x.lower()) + \
        '\n\n==== %s\n%s\n==== in the policy\n%s\n' % (
            SE_CIL, _read_or(SE_CIL) or '(not there)',
            _read_or(SE_CIL + '.in-policy') or '(none put in yet)')
    parts['README.txt'] = (
        'isemon - what SELinux says on this machine, for whoever writes isemon\'s module\n'
        '(isemon_server). Made %s. Nothing was changed to make it.\n\n'
        'check.json      the card: mode, module, labels, booleans, ports, refusals\n'
        'avc*.txt        what SELinux refused since the machine started (raw and readable)\n'
        'audit2why.txt   why; audit2allow.te: what would allow it - a hint, not to be loaded\n'
        'labels.txt      the labels of isemon\'s files and what the policy says they should be\n'
        'processes.txt   the domains the programs run in; ports.txt, booleans.txt, modules.txt\n'
        'system.txt      the system, the policy and the packages; isemon.json: what isemon uses\n\n'
        'No password, key or token of isemon is in it. The audit log holds the command lines of\n'
        'the programs refused something: isemon never puts a secret on one - other programs on\n'
        'this machine may. Look through avc*.txt before sending it on.\n'
        % time.strftime('%Y-%m-%d %H:%M:%S'))
    return parts


def se_report_bytes(r, top):
    import io
    import tarfile
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode='w:gz') as tf:
        for name, text in se_report_parts(r).items():
            data = text.encode('utf-8', 'replace')
            info = tarfile.TarInfo('%s/%s' % (top, name))
            info.size = len(data)
            info.mtime = int(time.time())
            info.mode = 0o600
            tf.addfile(info, io.BytesIO(data))
    return buf.getvalue()


def write_here_bytes(name, data):
    """write_here for bytes: in the folder opened at the start, never by its
    path - the isemon account owns the folder above it."""
    d = web_fd()
    tmp = '.%s.%d' % (name, os.getpid())
    try:
        os.unlink(tmp, dir_fd=d)
    except OSError:
        pass
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o640, dir_fd=d)
    with os.fdopen(fd, 'wb') as f:
        f.write(data)
        try:
            import grp
            os.fchown(f.fileno(), 0, grp.getgrnam(SERVICE_GROUP).gr_gid)
        except (KeyError, OSError):
            pass
    os.replace(tmp, name, src_dir_fd=d, dst_dir_fd=d)


def selinux_part():
    try:
        raw = read_req(SELINUX_ASK, 16384)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        drop_entry(SELINUX_ASK)             # a link or a folder in its place: never followed
        return
    drop_entry(SELINUX_ASK)
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        try:
            r = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise Refused('the request does not read')
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        if r.get('do') not in ('check', 'report'):
            # A step changes the machine: one asked long ago is not done.
            try:
                at = float(r.get('at') or 0)
            except (TypeError, ValueError):
                at = 0.0
            if not math.isfinite(at) or abs(time.time() - at) > 600:
                raise Refused('that was asked too long ago - ask again on the page')
        out['data'] = se_do(r)
        out['ok'] = True
    except Refused as e:
        out['said'] = str(e)[:400]
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    write_here(SELINUX_FILE, json.dumps(out))


# ---- the system's trusted roots (1.10.319) ----------------------------------------
# Certificate authorities of one's own put into the trust of the whole system -
# curl, dnf, LDAPS to a domain controller, mail, isemon's own connections:
# every program that uses the system's trust. Only by the system's own way of
# adding to it, never by touching the distribution's bundle: a file in the
# folder of local additions, then its own tool -
#   RHEL / AlmaLinux / Rocky: /etc/pki/ca-trust/source/anchors/*.pem, update-ca-trust extract
#   Debian / Ubuntu:          /usr/local/share/ca-certificates/*.crt, update-ca-certificates
# Both merge that folder with the distribution's list every time they run -
# also when an update of the ca-certificates package runs them - so the
# distribution's list keeps coming with the system's updates and these stay
# beside it. isemon's files are named isemon-<sha256 16>.pem (.crt): isemon
# lists, writes and removes only those; anything else in the folder was put
# there by somebody else and is only shown. What is asked is always the whole
# set wanted (`sync`). Every certificate is read by openssl here again.
OSROOTS_ASK = 'osroots.ask'
OSROOTS_FILE = 'osroots.json'
OSROOTS_MAX = 50                    # isemon's certificates at most
OSROOTS_PEM_MAX = 16384             # one certificate, as PEM
OSROOTS_NAME_RE = re.compile(r'^isemon-[0-9a-f]{16}\.(pem|crt)\Z')
OSROOTS_BLOCK_RE = re.compile(r'-----BEGIN CERTIFICATE-----([A-Za-z0-9+/=\s]*?)-----END CERTIFICATE-----')
OSROOTS_FLAVOURS = {
    'rhel': {'dir': '/etc/pki/ca-trust/source/anchors', 'ext': '.pem',
             'tool': ['update-ca-trust', 'extract'],
             'bundle': '/etc/pki/ca-trust/extracted/pem/tls-ca-bundle.pem',
             'pkg': ['rpm', '-q', 'ca-certificates']},
    'debian': {'dir': '/usr/local/share/ca-certificates', 'ext': '.crt',
               'tool': ['update-ca-certificates'],
               'bundle': '/etc/ssl/certs/ca-certificates.crt',
               'pkg': ['dpkg-query', '-W', '-f=ca-certificates-${Version}', 'ca-certificates']}}


def osroots_where():
    """Which way this system adds to its trust - each part overridable for the
    tests, by the environment of the unit (root's alone)."""
    fl = os.environ.get('ISEMON_OSROOTS_FLAVOUR', '')
    if fl not in OSROOTS_FLAVOURS:
        fl = ''
        if os.path.isdir('/etc/pki/ca-trust/source') or shutil.which('update-ca-trust'):
            fl = 'rhel'
        elif os.path.isdir('/usr/local/share/ca-certificates') or \
                shutil.which('update-ca-certificates'):
            fl = 'debian'
    if not fl:
        return None
    w = dict(OSROOTS_FLAVOURS[fl], flavour=fl)
    w['dir'] = os.environ.get('ISEMON_OSROOTS_DIR') or w['dir']
    w['bundle'] = os.environ.get('ISEMON_OSROOTS_BUNDLE') or w['bundle']
    if os.environ.get('ISEMON_OSROOTS_EXTRACT'):
        w['tool'] = os.environ['ISEMON_OSROOTS_EXTRACT'].split()
    if 'ISEMON_OSROOTS_PKG' in os.environ:
        w['pkg'] = os.environ['ISEMON_OSROOTS_PKG'].split()
    return w


def osroots_blocks(text):
    """Each certificate of a text as (pem, der) - nothing but certificates: a
    private key, or a text with no certificate in it, refused whole."""
    import base64
    text = str(text or '')
    if re.search(r'PRIVATE KEY|BEGIN ENCRYPTED|BEGIN PKCS7|BEGIN TRUSTED CERTIFICATE', text):
        raise Refused('no private key and nothing but certificates (-----BEGIN CERTIFICATE-----)')
    out = []
    for body in OSROOTS_BLOCK_RE.findall(text):
        try:
            der = base64.b64decode(re.sub(r'\s+', '', body), validate=True)
        except ValueError:
            raise Refused('a certificate that is not base64')
        if not der or len(der) > OSROOTS_PEM_MAX * 3 // 4:
            raise Refused('a certificate of %d bytes - one is a few kB at most' % len(der))
        enc = base64.b64encode(der).decode('ascii')
        out.append(('-----BEGIN CERTIFICATE-----\n%s\n-----END CERTIFICATE-----\n' % '\n'.join(
            enc[i:i + 64] for i in range(0, len(enc), 64)), der))
    if not out:
        raise Refused('no certificate in it (-----BEGIN CERTIFICATE-----)')
    return out


def _osroots_time(s):
    import calendar
    try:
        return calendar.timegm(time.strptime(re.sub(r'\s+', ' ', s.strip()), '%b %d %H:%M:%S %Y %Z'))
    except ValueError:
        return 0


def osroots_facts(pem, der):
    """What one certificate is, as openssl reads it - and what stands against
    it (`refused`) or is to be known (`warn`). The same words as the daemon's
    osr_facts."""
    import hashlib
    txt = openssl(['x509', '-noout', '-text', '-nameopt', 'RFC2253'],
                  'not a certificate openssl reads', data=pem)

    def one(rx):
        m = re.search(rx, txt, re.M)
        return m.group(1).strip() if m else ''
    f = {'fp': hashlib.sha256(der).hexdigest(), 'subject': one(r'^\s*Subject: ?(.*)$')[:400],
         'issuer': one(r'^\s*Issuer: ?(.*)$')[:400],
         'not_before': _osroots_time(one(r'Not Before\s*: (.*)$')),
         'not_after': _osroots_time(one(r'Not After\s*: (.*)$')),
         'sig': one(r'Signature Algorithm: (\S+)')[:60]}
    cn = re.search(r'(?:^|,)CN=((?:\\.|[^,])*)', f['subject'])
    f['cn'] = (cn.group(1) if cn else f['subject'])[:200]
    alg = one(r'Public Key Algorithm: (\S+)')
    bits = one(r'Public-Key: \((\d+) bit\)')
    curve = one(r'NIST CURVE: (\S+)') or one(r'ASN1 OID: (\S+)')
    f['key'] = ('RSA %s' % bits) if alg == 'rsaEncryption' else \
        ('EC %s' % (curve or bits)) if alg == 'id-ecPublicKey' else \
        (alg.replace('ED25519', 'Ed25519').replace('ED448', 'Ed448')[:40] if alg else '?')
    f['bits'] = int(bits) if bits.isdigit() else 0
    bc = re.search(r'X509v3 Basic Constraints:.*\n\s*(CA:(TRUE|FALSE))', txt)
    f['ca'] = bool(bc and bc.group(2) == 'TRUE')
    ku = re.search(r'X509v3 Key Usage:.*\n\s*(.*)', txt)
    f['ku_sign'] = None if not ku else ('Certificate Sign' in ku.group(1))
    f['root'] = f['subject'] == f['issuer']
    f['kind'] = 'root' if f['root'] else 'intermediate'
    refused, warn = [], []
    now = time.time()
    if not bc:
        refused.append('it says nothing of being an authority (no basicConstraints CA:TRUE) - '
                       'only a certificate authority goes here')
    elif not f['ca']:
        refused.append('it is not a certificate authority (CA:FALSE) - a server\'s own certificate '
                       'does not go here')
    if f['ku_sign'] is False:
        refused.append('its key usage does not let it sign certificates (no keyCertSign)')
    if f['not_after'] and f['not_after'] < now:
        warn.append('it ran out on %s - nothing it signed is trusted' % time.strftime(
            '%Y-%m-%d', time.gmtime(f['not_after'])))
    if f['not_before'] and f['not_before'] > now + 300:
        warn.append('it is valid only from %s' % time.strftime('%Y-%m-%d', time.gmtime(f['not_before'])))
    if not f['root'] and re.match(r'(?i)(sha1|md5|md2)', f['sig']):
        warn.append('it is signed with %s - the system\'s crypto policy (DEFAULT) refuses it, and '
                    'every chain through it' % f['sig'])
    if f['key'].startswith('RSA') and 0 < f['bits'] < 2048:
        warn.append('its key has %d bits - the system\'s crypto policy (DEFAULT) refuses fewer '
                    'than 2048' % f['bits'])
    f['refused'], f['warn'] = refused, warn
    return f


def osroots_dir_ok(d, make=False):
    """The folder of local additions: a folder of root's, never a link."""
    try:
        st = os.lstat(d)
    except FileNotFoundError:
        if not make:
            return False
        os.makedirs(d, 0o755, exist_ok=True)
        st = os.lstat(d)
    if not stat.S_ISDIR(st.st_mode):
        raise Refused('%s is not a folder (a link?) - nothing is written there' % d)
    if (st.st_uid != 0 and not NO_SERVICES) or st.st_mode & 0o022:
        raise Refused('%s is not root\'s alone (owner %d, mode %o) - nothing is written there'
                      % (d, st.st_uid, stat.S_IMODE(st.st_mode)))
    return True


def _osroots_read(path, most=1048576):
    """A plain file's bytes - None for a link (never followed), a folder, a pipe."""
    import errno
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except OSError as e:
        if e.errno in (errno.ELOOP, errno.EISDIR, errno.ENXIO):
            return None
        raise
    try:
        if not stat.S_ISREG(os.fstat(fd).st_mode):
            return None
        data = os.read(fd, most + 1)
    finally:
        os.close(fd)
    return data[:most]


def osroots_files(d):
    """[(relative name, path)] of the folder - one level of subfolders too (Debian reads them)."""
    out = []
    try:
        top = sorted(os.listdir(d))
    except OSError:
        return out
    for n in top[:500]:
        p = os.path.join(d, n)
        if os.path.isdir(p) and not os.path.islink(p):
            try:
                out += [(n + '/' + m, os.path.join(p, m)) for m in sorted(os.listdir(p))[:200]]
            except OSError:
                pass
        else:
            out.append((n, p))
    return out


def osroots_cert_of_file(path):
    """The certificates of a file somebody else put there - PEM or DER - with their facts."""
    raw = _osroots_read(path)
    if raw is None:
        return None
    text = raw.decode('ascii', 'replace')
    if '-----BEGIN CERTIFICATE-----' not in text:
        try:
            got = subprocess.run(['openssl', 'x509', '-inform', 'DER'], input=raw,
                                 capture_output=True, timeout=30)
            if got.returncode != 0:
                return []
            text = got.stdout.decode('ascii', 'replace')
        except (OSError, subprocess.SubprocessError):
            return []
    out = []
    try:
        blocks = osroots_blocks('\n'.join(m.group(0) for m in OSROOTS_BLOCK_RE.finditer(text)))
    except Refused:
        return []
    for pem, der in blocks[:20]:
        try:
            f = osroots_facts(pem, der)
            out.append({k: f[k] for k in ('fp', 'cn', 'subject', 'issuer', 'not_before',
                                          'not_after', 'key', 'kind', 'ca')})
        except Refused:
            continue
    return out


def osroots_bundle(w):
    """The system's own list as its tool made it last: how many, how large,
    when - and the package that brings it, so it is seen that the system's
    updates keep it coming."""
    out = {'path': w['bundle'], 'count': 0, 'bytes': 0, 'at': 0}
    try:
        st = os.stat(w['bundle'])
        out.update(bytes=st.st_size, at=st.st_mtime)
        with open(w['bundle'], 'rb') as f:
            out['count'] = f.read(64 * 1048576).count(b'-----BEGIN CERTIFICATE-----')
    except OSError:
        out['missing'] = True
    pkg = ''
    if w.get('pkg') and shutil.which(w['pkg'][0]):
        try:
            got = subprocess.run(w['pkg'], capture_output=True, text=True, timeout=30)
            if got.returncode == 0 and got.stdout.strip():
                pkg = got.stdout.strip().splitlines()[0][:120]
        except (OSError, subprocess.SubprocessError):
            pkg = ''
    out['package'] = pkg
    return out


def _osroots_in_bundle(w, ders):
    """Which of these the tool put into the system's list: their base64 found in it."""
    import base64
    import hashlib
    try:
        with open(w['bundle'], 'rb') as f:
            flat = re.sub(rb'\s+', b'', f.read(64 * 1048576))
    except OSError:
        return {}
    return {hashlib.sha256(d).hexdigest(): base64.b64encode(d) in flat for d in ders}


def osroots_read(w):
    """isemon's own, the others', the system's list."""
    ours, others = [], []
    if w and os.path.isdir(w['dir']):
        for rel, p in osroots_files(w['dir']):
            if OSROOTS_NAME_RE.match(rel):
                raw = _osroots_read(p, 65536)
                if raw is None:
                    others.append({'file': rel, 'certs': [], 'link': os.path.islink(p)})
                    continue
                try:
                    (pem, der), = osroots_blocks(raw.decode('ascii', 'replace'))
                    f = osroots_facts(pem, der)
                    f.pop('refused', None)
                    f.update(file=rel, der=der)
                    ours.append(f)
                except (Refused, ValueError):
                    ours.append({'file': rel, 'broken': True})
            else:
                if os.path.islink(p):
                    try:
                        to = os.readlink(p)[:300]
                    except OSError:
                        to = '?'
                    others.append({'file': rel, 'link': to, 'certs': []})
                    continue
                # Up to 60 files of others' read (each openssl run takes its time); the rest named.
                read_others = sum(1 for o in others if o.get('certs'))
                others.append({'file': rel, 'certs': (osroots_cert_of_file(p) or [])
                               if read_others < 60 else []})
    inb = _osroots_in_bundle(w, [f['der'] for f in ours if f.get('der')]) if w else {}
    for f in ours:
        f.pop('der', None)
        if f.get('fp'):
            f['in_bundle'] = inb.get(f['fp'])
    return {'ours': ours, 'others': others[:200], 'system': osroots_bundle(w) if w else {},
            'flavour': (w or {}).get('flavour', ''), 'dir': (w or {}).get('dir', ''),
            'tool': ' '.join((w or {}).get('tool') or []),
            'tool_there': bool(w and shutil.which(w['tool'][0]))}


def _osroots_put(d, name, pem):
    """Written beside it under a name of its own and renamed into place: root's, 0644."""
    fd, tmp = tempfile.mkstemp(prefix='.isemon-', dir=d)
    try:
        os.fchmod(fd, 0o644)
        try:
            os.fchown(fd, 0, 0)
        except OSError:
            pass
        with os.fdopen(fd, 'w') as f:
            fd = None
            f.write(pem)
        os.replace(tmp, os.path.join(d, name))
    except BaseException:
        if fd is not None:
            os.close(fd)
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def osroots_sync(w, certs, force=False):
    """The folder made to hold exactly the certificates wanted of isemon's - the
    others' left as they are - and the system's tool run when anything
    changed. (said, refused [{fp, cn, why}])."""
    if not w:
        raise Refused('this system has neither update-ca-trust (RHEL, AlmaLinux, Rocky) nor '
                      'update-ca-certificates (Debian, Ubuntu)')
    if not isinstance(certs, list) or len(certs) > OSROOTS_MAX:
        raise Refused('the certificates wanted: a list of %d at most' % OSROOTS_MAX)
    want, refused = {}, []
    for c in certs:
        if not isinstance(c, str) or len(c) > OSROOTS_PEM_MAX:
            raise Refused('each certificate as PEM text of %d bytes at most' % OSROOTS_PEM_MAX)
        blocks = osroots_blocks(c)
        if len(blocks) != 1:
            raise Refused('one certificate in each')
        pem, der = blocks[0]
        f = osroots_facts(pem, der)
        if f['refused']:
            refused.append({'fp': f['fp'], 'cn': f['cn'], 'why': '; '.join(f['refused'])})
            continue
        want['isemon-%s%s' % (f['fp'][:16], w['ext'])] = pem
    osroots_dir_ok(w['dir'], make=bool(want))
    said, changed = [], False
    have = {rel: p for rel, p in osroots_files(w['dir']) if OSROOTS_NAME_RE.match(rel)} \
        if os.path.isdir(w['dir']) else {}
    for name, pem in sorted(want.items()):
        p = have.get(name)
        if p is not None:
            raw = _osroots_read(p, 65536)
            if raw is not None and raw.decode('ascii', 'replace') == pem and not os.path.islink(p):
                continue
            os.unlink(p)            # changed by somebody, or a link: put back as it is wanted
        _osroots_put(w['dir'], name, pem)
        said.append('added %s' % name)
        changed = True
        if shutil.which('restorecon') and os.path.isdir('/sys/fs/selinux') and not NO_SERVICES:
            subprocess.run(['restorecon', '-F', os.path.join(w['dir'], name)], capture_output=True)
    for name, p in sorted(have.items()):
        if name not in want:
            os.unlink(p)
            said.append('removed %s' % name)
            changed = True
    if changed or force:
        if not shutil.which(w['tool'][0]):
            raise Refused('%s is not on this machine - the files are in %s, the system\'s list is '
                          'not made again until it runs' % (w['tool'][0], w['dir']))
        got = subprocess.run(w['tool'], capture_output=True, text=True, timeout=300)
        if got.returncode != 0:
            raise Refused('%s ended with %d: %s' % (' '.join(w['tool']), got.returncode,
                                                    ((got.stderr or got.stdout).strip() or '-')[-300:]))
        said.append('%s run' % ' '.join(w['tool']))
    return said, refused


def osroots_do(r):
    w = osroots_where()
    do = r.get('do')
    if do == 'list':
        return dict(osroots_read(w), said=[], refused=[])
    if do == 'sync':
        said, refused = osroots_sync(w, r.get('certs'), bool(r.get('force')))
        return dict(osroots_read(w), said=said, refused=refused)
    raise Refused('list or sync')


def osroots_part():
    try:
        raw = read_req(OSROOTS_ASK, OSROOTS_MAX * OSROOTS_PEM_MAX * 2 + 65536)
    except FileNotFoundError:
        return
    except (Refused, OSError):
        drop_entry(OSROOTS_ASK)
        return
    drop_entry(OSROOTS_ASK)
    out = {'at': time.time(), 'ok': False, 'id': ''}
    try:
        try:
            r = json.loads(raw.decode('utf-8'))
        except ValueError:
            raise Refused('the request does not read')
        if not isinstance(r, dict):
            raise Refused('the request is not an object')
        out['id'] = re.sub(r'[^A-Za-z0-9]', '', str(r.get('id') or ''))[:40]
        out['data'] = osroots_do(r)
        out['ok'] = True
    except Refused as e:
        out['said'] = str(e)[:400]
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out['said'] = 'it went wrong: %s' % str(e)[:300]
    write_here(OSROOTS_FILE, json.dumps(out))



def serve():
    d = web_fd()
    try:
        look_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: looking: %s' % e, file=sys.stderr)
    try:
        ntp_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: the time: %s' % e, file=sys.stderr)
    try:
        net_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: the network: %s' % e, file=sys.stderr)
    try:
        sshkeys_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: root\'s SSH keys: %s' % e, file=sys.stderr)
    try:
        logfix_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: logrotate for the logs: %s' % e, file=sys.stderr)
    try:
        osup_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: the updates of the system: %s' % e, file=sys.stderr)
    try:
        otptls_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: the otp logs over TLS: %s' % e, file=sys.stderr)
    try:
        acmetls_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: the acme logs over TLS: %s' % e, file=sys.stderr)
    try:
        selinux_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: SELinux: %s' % e, file=sys.stderr)
    try:
        osroots_part()
    except Exception as e:                              # noqa: BLE001
        print('isemon_web.py: the system\'s trusted roots: %s' % e, file=sys.stderr)
    # One left by a run that was stopped half way (1.10.238) - a reboot, a
    # timeout during DH: taken away and said, or the daemon would wait on it
    # for ever and never ask again.
    if drop_entry('request.taken'):
        write_here('status.json', json.dumps(dict(status_read(), at=time.time(), state='failed',
                                                  said=['it was stopped half way (the machine '
                                                        'or the service restarted): asked '
                                                        'again'])))
    try:
        os.replace('request.json', 'request.taken', src_dir_fd=d, dst_dir_fd=d)
    except FileNotFoundError:
        return 0
    except OSError:
        drop_entry('request.json')              # a folder in its place
        return 0
    last = status_read()
    out = {'at': time.time(), 'dh': last.get('dh') or 'none'}
    try:
        try:
            raw = json.loads(read_req('request.taken').decode('utf-8'))
        except ValueError as e:
            raise Refused('the request does not read: %s' % e)
        if isinstance(raw, dict):
            out.update(id=re.sub(r'[^A-Za-z0-9]', '', str(raw.get('id') or ''))[:32],
                       hash=re.sub(r'[^0-9a-f]', '', str(raw.get('hash') or ''))[:64])
        PROGRESS['id'] = str(out.get('id') or '')
        progress('checking what was asked', 1)
        r = checked(raw)
        out.update(id=r['id'], hash=r['hash'])
        fw_can(r['fw'])
        said_n, dh = nginx_part(r, last)
        out['dh'] = dh
        try:
            said_f, fw = fw_part(r['fw'])
        except Refused as e:
            # nginx's half is in force by now: said, beside why the
            # firewall's half is not, rather than as if nothing were.
            raise Refused('; '.join([s for s in said_n if s] + [str(e)]))
        out.update(state='done', said=[s for s in said_n + said_f if s], fw=fw)
    except Refused as e:
        out.update(state='failed', said=[str(e)])
    except Exception as e:                              # noqa: BLE001 - said, never lost
        out.update(state='failed', said=['it broke: %s' % e])
    finally:
        for name in ('request.taken', 'progress.json'):
            drop_entry(name)
    write_here('status.json', json.dumps(out))
    try:
        write_here(LOOK_FILE, json.dumps(look()))
    except Exception:                                   # noqa: BLE001
        pass
    return 0


def main(argv):
    if argv[:1] == ['--status']:
        print(json.dumps({'status': status_read(), 'look': look()}, indent=1))
        return 0
    if os.geteuid() != 0 and not NO_SERVICES:
        print('isemon_web.py: root only', file=sys.stderr)
        return 2
    # The update of the system, started by osup_part as a unit of its own.
    if argv[:1] == ['--os-job'] and len(argv) >= 3 and argv[2] in ('check', 'upgrade'):
        return osup_job(re.sub(r'[^A-Za-z0-9]', '', argv[1])[:40], argv[2],
                        argv[3:4] == ['security'])
    return serve()


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
